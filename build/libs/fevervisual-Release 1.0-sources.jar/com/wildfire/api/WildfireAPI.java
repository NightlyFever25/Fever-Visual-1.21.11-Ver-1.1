package com.wildfire.api;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.FemaleGender;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_1792;

public final class WildfireAPI {
   private static final Map<class_1792, IGenderArmor> GENDER_ARMORS = new HashMap<>();

   private WildfireAPI() {
      throw new UnsupportedOperationException("Utility class");
   }

   public static void addGenderArmor(class_1792 item, IGenderArmor genderArmor) {
      if (item != null && genderArmor != null) {
         GENDER_ARMORS.put(item, genderArmor);
      }
   }

   public static Map<class_1792, IGenderArmor> getGenderArmors() {
      return GENDER_ARMORS;
   }

   public static float getPlayerSize(class_1657 player) {
      if (player == null || FeverVisual.getInstance().getModuleManager() == null) {
         return 0.0F;
      }

      FemaleGender module = FeverVisual.getInstance().getModuleManager().getModuleSafe(FemaleGender.class);
      if (module == null || !module.isEnabled()) {
         return 0.0F;
      }

      return module.getSizeFor(player);
   }
}
