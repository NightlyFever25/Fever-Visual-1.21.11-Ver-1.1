
package com.holdmylua.source.model;

import com.holdmylua.source.model.interfaces.Poses;
import com.holdmylua.source.model.parents.AbstractPose;
import net.minecraft.class_4587;

public class PoseY
extends AbstractPose
implements Poses {
    float amount;

    public PoseY(float amount) {
        this.amount = amount;
    }

    @Override
    public void applyPose(class_4587 matrices) {
        matrices.method_46416(0.0f, this.amount, 0.0f);
    }
}

