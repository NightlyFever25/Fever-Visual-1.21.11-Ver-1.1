
package com.holdmylua.source.model;

import com.holdmylua.source.model.interfaces.Poses;
import com.holdmylua.source.model.parents.AbstractPose;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public class RotationY
extends AbstractPose
implements Poses {
    private float x;
    private float y;
    private float z;
    private float amount;

    public RotationY(float amount, float x, float y, float z) {
        this.amount = amount;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public void applyPose(class_4587 matrices) {
        matrices.method_49278((Quaternionfc)class_7833.field_40716.rotationDegrees(this.amount), this.x, this.y, this.z);
    }
}

