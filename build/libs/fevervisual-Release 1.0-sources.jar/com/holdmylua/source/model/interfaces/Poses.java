
package com.holdmylua.source.model.interfaces;

import net.minecraft.class_4587;

public interface Poses {
    public void applyPose(class_4587 var1);
}

