
package com.holdmylua.source.patricles.scripting;

import com.holdmylua.source.annotation.Safe;
import net.minecraft.class_2960;

public class Texture {
    @Safe
    public class_2960 of(String namespace, String path) {
        return class_2960.method_60655((String)namespace, (String)path);
    }
}

