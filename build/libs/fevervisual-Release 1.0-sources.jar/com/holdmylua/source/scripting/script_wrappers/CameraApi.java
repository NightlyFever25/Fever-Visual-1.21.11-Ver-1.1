
package com.holdmylua.source.scripting.script_wrappers;

import com.holdmylua.source.access.CameraAccessor;
import com.holdmylua.source.annotation.Safe;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public class CameraApi {
    @Safe
    public void setCamPos(double x, double y, double z) {
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        if (camera instanceof CameraAccessor) {
            CameraAccessor camera2 = (CameraAccessor)camera;
            camera2.hMI5_0$setPosValues((float)x, (float)y, (float)z);
        }
    }

    @Safe
    public void setCamRot(double x, double y, double z) {
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        if (camera instanceof CameraAccessor) {
            CameraAccessor camera2 = (CameraAccessor)camera;
            camera2.hMI5_0$setRotationValues((float)x, (float)y, (float)z);
        }
    }
}
