package fever.visual.minecraft;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.game.SoundEvent;
import fever.visual.systems.modules.modules.visuals.NoRender;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class SoundSystemMixinProtection {
   public static void playSound(class_1113 sound, CallbackInfoReturnable<class_1140.class_11518> cir) {
      NoRender NoRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
      if (NoRender.isEnabled()
         && NoRender.getBeacon().isSelected()
         && (
            sound.method_4775().equals(class_3417.field_14703.comp_3319())
               || sound.method_4775().equals(class_3417.field_15045.comp_3319())
               || sound.method_4775().equals(class_3417.field_14891.comp_3319())
               || sound.method_4775().equals(class_3417.field_19344.comp_3319())
         )) {
         cir.setReturnValue(class_1140.class_11518.field_60956);
      }

      if (NoRender.isEnabled()
         && NoRender.getWeatherSound().isSelected()
         && (
            sound.method_4775().equals(class_3417.field_14946.comp_3319())
               || sound.method_4775().equals(class_3417.field_15020.comp_3319())
               || sound.method_4775().equals(class_3417.field_14865.comp_3319())
         )) {
         cir.setReturnValue(class_1140.class_11518.field_60956);
      }

      if (NoRender.isEnabled()
         && NoRender.getPhantoms().isSelected()
         && (
            sound.method_4775().equals(class_3417.field_14957.comp_3319())
               || sound.method_4775().equals(class_3417.field_14813.comp_3319())
               || sound.method_4775().equals(class_3417.field_14729.comp_3319())
               || sound.method_4775().equals(class_3417.field_14869.comp_3319())
               || sound.method_4775().equals(class_3417.field_14974.comp_3319())
               || sound.method_4775().equals(class_3417.field_15149.comp_3319())
               || sound.method_4775().equals(class_3417.field_15238.comp_3319())
         )) {
         cir.setReturnValue(class_1140.class_11518.field_60956);
      }

      FeverVisual.getInstance().getEventManager().triggerEvent(new SoundEvent(sound));
   }
}
