package fever.visual.ui.hud.impl;

import fever.visual.FeverVisual;
import fever.visual.framework.base.UIContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.framework.objects.MouseButton;
import fever.visual.systems.localization.Localizator;
import fever.visual.systems.modules.modules.visuals.Interface;
import fever.visual.systems.modules.modules.visuals.NoRender;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.ui.hud.HudElement;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.PlatformUtility;
import fever.visual.utility.gui.GuiUtility;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9022;
import net.minecraft.class_9025;

public class CustomScoreboard extends HudElement {
    private static final float PANEL_MARGIN = 3.0f;
    private static final int MAX_ENTRIES = 15;
    private static final long LINES_REFRESH_MS = 120L;
    private static final float TITLE_FONT_SIZE = 8.0f;
    private static final float LINE_FONT_SIZE = 7.0f;
    private static final float TITLE_AREA_HEIGHT = 18.0f;
    private static final float LINE_HEIGHT = 10.0f;
    private static final float CONTENT_PADDING = 9.0f;
    private static final class_2561 EMPTY_SCOREBOARD_TEXT = class_2561.method_43470("Scoreboard");
    private static final ColorRGBA SCORE_TEXT_COLOR = new ColorRGBA(255.0f, 94.0f, 94.0f);
    private static final Comparator<class_9011> ENTRY_ORDER = Comparator
            .comparingInt(class_9011::comp_2128)
            .reversed()
            .thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER);

    private final BooleanSetting scores = new BooleanSetting(this, "hud.custom_scoreboard.scores").enable();
    private List<ScoreboardLine> lines = List.of();
    private class_2561 title = class_2561.method_43473();
    private float titleWidth = 0.0f;
    private float maxContentWidth = 0.0f;
    @Nullable
    private class_266 currentObjective;
    @Nullable
    private class_266 cachedObjective;
    private boolean cachedScores = true;
    private long nextRefreshAtMs = 0L;
    private boolean manuallyPositioned = false;

    public CustomScoreboard() {
        super("hud.custom_scoreboard", "icons/hud/world.png");
    }

    @Override
    public void update(UIContext context) {
        this.currentObjective = this.getCurrentObjective();
        this.refreshLinesIfNeeded(this.currentObjective);

        float screenWidth = context.getScaledWindowWidth();
        float screenHeight = context.getScaledWindowHeight();
        float maxPanelWidth = Math.max(48.0f, screenWidth - PANEL_MARGIN * 2.0f);
        float minPanelWidth = Math.min(96.0f, maxPanelWidth);
        float maxPanelHeight = Math.max(28.0f, screenHeight - PANEL_MARGIN * 2.0f);
        this.width = class_3532.method_15363((float) this.maxContentWidth + CONTENT_PADDING * 2.0f, minPanelWidth, maxPanelWidth);
        this.height = Math.min(24.0f + (float) Math.max(1, this.lines.size()) * LINE_HEIGHT, maxPanelHeight);

        super.update(context);
        if (this.manuallyPositioned || this.isDragging()) {
            this.clampToScreen(context, PANEL_MARGIN);
        } else {
            this.anchorToVanillaSidebar(context, PANEL_MARGIN);
        }
    }

    @Override
    protected void renderComponent(UIContext context) {
        context.drawClientRect(this.x, this.y, this.width, this.height, this.animation.getValue(), this.dragAnim.getValue(), 7.0f);
        context.enableScissor(Math.round(this.x), Math.round(this.y), Math.round(this.x + this.width), Math.round(this.y + this.height));
        try {
            ColorRGBA textColor = Colors.getTextColor();
            Font titleFont = Fonts.MEDIUM.getFont(TITLE_FONT_SIZE);
            Font lineFont = Fonts.REGULAR.getFont(LINE_FONT_SIZE);
            context.drawRect(this.x, this.y + 18.0f, this.width, 4.0f, Colors.getSeparatorColor());
            float titleX = this.x + this.width / 2.0f - this.titleWidth / 2.0f;
            float titleY = this.y + GuiUtility.getMiddleOfBox(titleFont.height(), TITLE_AREA_HEIGHT);
            context.drawText(titleFont, this.title, titleX, titleY);

            if (this.lines.isEmpty()) {
                context.drawText(lineFont, EMPTY_SCOREBOARD_TEXT.getString(), this.x + 7.0f, this.y + 24.0f, textColor.withAlpha(150.0f));
                return;
            }

            float yOffset = this.y + 24.0f;
            for (ScoreboardLine line : this.lines) {
                context.drawText(lineFont, line.name(), this.x + CONTENT_PADDING, yOffset);
                if (line.score() != null && line.scoreWidth() > 0) {
                    context.drawText(
                            lineFont,
                            line.score().getString(),
                            this.x + this.width - CONTENT_PADDING - line.scoreWidth(),
                            yOffset,
                            SCORE_TEXT_COLOR
                    );
                }
                yOffset += LINE_HEIGHT;
            }
        } finally {
            context.disableScissor();
        }
    }

    @Override
    public boolean show() {
        return !this.isVanillaScoreboardRemoved() && (this.currentObjective != null || mc.field_1755 instanceof class_408);
    }

    private void anchorToVanillaSidebar(UIContext context, float margin) {
        float screenWidth = context.getScaledWindowWidth();
        float screenHeight = context.getScaledWindowHeight();
        this.width = Math.min(this.width, Math.max(48.0f, screenWidth - margin * 2.0f));
        this.height = Math.min(this.height, Math.max(28.0f, screenHeight - margin * 2.0f));
        this.x = class_3532.method_15363(screenWidth - this.width - margin, margin, Math.max(margin, screenWidth - this.width - margin));
        this.y = class_3532.method_15363(screenHeight / 2.0f - this.height / 2.0f, margin, Math.max(margin, screenHeight - this.height - margin));
    }

    private void clampToScreen(UIContext context, float margin) {
        float screenWidth = context.getScaledWindowWidth();
        float screenHeight = context.getScaledWindowHeight();
        this.x = class_3532.method_15363(this.x, margin, Math.max(margin, screenWidth - this.width - margin));
        this.y = class_3532.method_15363(this.y, margin, Math.max(margin, screenHeight - this.height - margin));
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        boolean wasDragging = this.isDragging();
        float startX = this.getStartDragX();
        float startY = this.getStartDragY();
        super.onMouseReleased(mouseX, mouseY, button);
        if (wasDragging && (this.x != startX || this.y != startY)) {
            this.manuallyPositioned = true;
        }
    }

    @Override
    public void setX(float x) {
        super.setX(x);
        this.manuallyPositioned = true;
    }

    @Override
    public void setY(float y) {
        super.setY(y);
        this.manuallyPositioned = true;
    }

    public static boolean shouldReplaceVanilla() {
        if (FeverVisual.getInstance().getHud() == null) {
            return false;
        }
        if (!Interface.isHudElementEnabled("hud.custom_scoreboard")) {
            return false;
        }
        CustomScoreboard scoreboard = FeverVisual.getInstance().getHud().getElementByName("hud.custom_scoreboard");
        if (scoreboard == null || scoreboard.isVanillaScoreboardRemoved()) {
            return false;
        }
        if (PlatformUtility.isLabyMod() || PlatformUtility.isLunarClient()) {
            return scoreboard.currentObjective != null || scoreboard.getCurrentObjective() != null || mc.field_1755 instanceof class_408;
        }
        return scoreboard != null && scoreboard.isShowing() && !scoreboard.isVanillaScoreboardRemoved();
    }

    private void refreshLinesIfNeeded(@Nullable class_266 objective) {
        boolean showScores = this.scores.isEnabled();
        long now = class_156.method_658();
        boolean objectiveChanged = this.cachedObjective != objective;
        boolean scoresModeChanged = this.cachedScores != showScores;

        if (now < this.nextRefreshAtMs && !objectiveChanged && !scoresModeChanged) {
            return;
        }

        this.cachedObjective = objective;
        this.cachedScores = showScores;
        this.nextRefreshAtMs = now + LINES_REFRESH_MS;

        this.title = objective != null ? objective.method_1114() : class_2561.method_43470(Localizator.translate(this.name));
        Font titleFont = Fonts.MEDIUM.getFont(TITLE_FONT_SIZE);
        this.titleWidth = titleFont.width(this.title.getString());

        if (objective == null) {
            this.lines = List.of();
            this.maxContentWidth = this.titleWidth;
            return;
        }

        this.lines = this.getLines(objective, showScores);
        float maxWidth = this.titleWidth;
        for (ScoreboardLine line : this.lines) {
            maxWidth = Math.max(maxWidth, line.fullWidth());
        }
        this.maxContentWidth = maxWidth;
    }

    private List<ScoreboardLine> getLines(class_266 objective, boolean showScores) {
        class_269 scoreboard = objective.method_1117();

        List<class_9011> entries = new ArrayList<>(scoreboard.method_1184(objective));
        entries.removeIf(class_9011::method_55385);
        entries.sort(ENTRY_ORDER);

        int linesCount = Math.min(MAX_ENTRIES, entries.size());
        List<ScoreboardLine> result = new ArrayList<>(linesCount);
        for (int i = 0; i < linesCount; i++) {
            result.add(this.getLine(scoreboard, objective, entries.get(i), showScores));
        }

        return result;
    }

    private ScoreboardLine getLine(class_269 scoreboard, class_266 objective, class_9011 entry, boolean showScores) {
        class_268 team = scoreboard.method_1164(entry.comp_2127());
        class_2561 name = this.buildDisplayName(team, entry);
        Font lineFont = Fonts.REGULAR.getFont(LINE_FONT_SIZE);
        float nameWidth = lineFont.width(name.getString());

        class_2561 score = null;
        float scoreWidth = 0.0f;
        float lineWidth = nameWidth;

        if (showScores && this.shouldRenderScore(objective)) {
            class_9022 numberFormat = objective.method_55380(class_9025.field_47567);
            score = entry.method_55386(numberFormat);
            scoreWidth = lineFont.width(score.getString());
            if (scoreWidth > 0) {
                lineWidth += lineFont.width(":") + scoreWidth;
            }
        }

        return new ScoreboardLine(name, score, scoreWidth, lineWidth);
    }

    private class_2561 buildDisplayName(@Nullable class_268 team, class_9011 entry) {
        class_2561 entryName = entry.method_55387();
        if (team == null) {
            return entryName;
        }

        class_2561 decorated = class_268.method_1142(team, entryName);
        if (!decorated.getString().isBlank()) {
            return decorated;
        }

        class_5250 fallback = class_2561.method_43473();
        fallback.method_10852(team.method_1144());
        fallback.method_10852(entryName);
        fallback.method_10852(team.method_1136());
        return fallback;
    }

    private boolean shouldRenderScore(class_266 objective) {
        class_9022 numberFormat = objective.method_55380(class_9025.field_47566);
        return !(numberFormat instanceof class_9025);
    }

    private class_266 getCurrentObjective() {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return null;
        }
        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 objective = null;
        class_268 team = scoreboard.method_1164(mc.field_1724.method_5820());
        if (team != null) {
            class_8646 teamSlot = class_8646.method_52622(team.method_1202());
            if (teamSlot != null) {
                objective = scoreboard.method_1189(teamSlot);
            }
        }
        return objective != null ? objective : scoreboard.method_1189(class_8646.field_45157);
    }

    private boolean isVanillaScoreboardRemoved() {
        NoRender noRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
        return noRender.isEnabled() && noRender.getScoreboard().isSelected();
    }

    private record ScoreboardLine(class_2561 name, @Nullable class_2561 score, float scoreWidth, float fullWidth) {
    }
}
