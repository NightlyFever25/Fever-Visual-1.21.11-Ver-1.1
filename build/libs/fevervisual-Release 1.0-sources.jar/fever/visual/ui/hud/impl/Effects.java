package fever.visual.ui.hud.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import net.minecraft.class_10799;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_329;
import net.minecraft.class_408;
import net.minecraft.class_4081;
import fever.visual.FeverVisual;
import fever.visual.framework.base.UIContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.framework.objects.BorderRadius;
import fever.visual.systems.modules.modules.visuals.Interface;
import fever.visual.systems.notifications.NotificationType;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.theme.Theme;
import fever.visual.ui.components.animated.AnimatedNumber;
import fever.visual.ui.hud.HudList;
import fever.visual.utility.animation.base.Animation;
import fever.visual.utility.animation.base.Easing;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.server.ServerUtility;
import fever.visual.utility.gui.GuiUtility;
import fever.visual.utility.mixins.StatusEffectInstanceAddition;
import fever.visual.utility.render.ScissorUtility;

public class Effects extends HudList {
   private static final float SEPARATOR_HEIGHT = 0.25F;
   private final BooleanSetting alwaysDisplay = new BooleanSetting(this, "hud.always_display");
   int lastSize = -1;
   private final Map<String, class_1293> effects = new TreeMap<>();
   private final Map<class_1291, Boolean> ended = new HashMap<>();
   private final BooleanSetting alert = new BooleanSetting(this, "hud.effects.alert");

   private final ColorSetting beneficialColor = new ColorSetting(this, "hud.effects.beneficial_color")
           .color(new ColorRGBA(100, 255, 100, 255))
           .alpha(false);
   private final ColorSetting harmfulColor = new ColorSetting(this, "hud.effects.harmful_color")
           .color(new ColorRGBA(255, 100, 100, 255))
           .alpha(false);

   public Effects() {
      super("hud.effects", "icons/hud/potion.png");
   }

   @Override
   public void update(UIContext context) {
      this.width = 92.0F;
      this.height = 18.0F;
      Collection<class_1293> original = mc.field_1724.method_6026();

      for (class_1293 eff : original) {
         class_1291 potion = (class_1291)eff.method_5579().comp_349();
         String realName = potion.method_5560().getString();
         if (realName != null && !ServerUtility.isCM()) {
            if (this.effects.containsKey(realName)) {
               this.effects.replace(realName, eff);
               Animation anim = ((StatusEffectInstanceAddition)eff).fevervisual$getAnimPotion();
               if (anim.getValue() == 0.0F) {
                  anim.setValue(1.0F);
               }
            } else {
               this.effects.put(realName, eff);
            }
         }
      }

      if (!this.effects.isEmpty()) {
         this.height += 5.0F;
      }

      for (class_1293 effx : this.effects.values()) {
         Animation anim = ((StatusEffectInstanceAddition)effx).fevervisual$getAnimPotion();
         class_1291 potion = (class_1291)effx.method_5579().comp_349();
         if (this.alert.isEnabled()) {
            String effectName = potion.method_5560().getString() + " " + (effx.method_5578() > 0 ? effx.method_5578() + 1 : "");
            if (!mc.field_1724.method_6059(effx.method_5579())) {
               if (!this.ended.getOrDefault(potion, false) && !potion.method_18792().equals(class_4081.field_18272)) {
                  FeverVisual.getInstance()
                          .getNotificationManager()
                          .addNotificationOther(NotificationType.INFO, "Эффект " + effectName + " закончился", "Действие эффекта завершено");
                  this.ended.put(potion, true);
               }
            } else {
               this.ended.put(potion, false);
            }
         }

         anim.update(original.contains(effx));
         anim.setEasing(Easing.BAKEK);
         this.width = Math.max(Fonts.REGULAR.getFont(7.0F).width(potion.method_5560().getString()) + 60.0F, this.width);
         this.height = this.height + 18.0F * anim.getValue();
      }

      super.update(context);
   }

   @Override
   protected void renderComponent(UIContext context) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         boolean dark = FeverVisual.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
         float glassIntensity = Interface.glass();
         float minimalizm = Interface.minimalizm();
         boolean showGlass = Interface.showGlass();
         boolean showMinimalizm = Interface.showMinimalizm();

         ColorRGBA bgColor = Colors.getBackgroundColor()
                 .withAlpha(255.0F * (dark ? 0.8F - 0.6F * glassIntensity : 0.7F));

         float alpha = 255.0F * this.animation.getValue() * this.visible.getValue();
         if (showMinimalizm) {
            context.drawBlurredRect(
                    this.x, this.y, this.width, this.height,
                    45.0F, 7.0F,
                    BorderRadius.all(6.0F),
                    ColorRGBA.WHITE.withAlpha(alpha * minimalizm)
            );
         }

         if (showGlass) {
            context.drawLiquidGlass(
                    this.x, this.y, this.width, this.height,
                    7.0F,
                    0.08F - 0.07F * this.dragAnim.getValue(),
                    BorderRadius.all(6.0F),
                    ColorRGBA.WHITE.withAlpha(alpha * glassIntensity)
            );
         }

         context.drawSquircle(this.x, this.y, this.width, this.height, 7.0F,
                 BorderRadius.all(6.0F), bgColor.withAlpha(bgColor.getAlpha() * this.animation.getValue()));

         ScissorUtility.push(context.getMatrices(), this.x, this.y, this.width, this.height);

         Font font = Fonts.REGULAR.getFont(7.0F);
         float headerHeight = 18.0F;
         Font headerFont = Fonts.MEDIUM.getFont(8.0F);
         String headerText = "Potions";
         float textWidth = headerFont.width(headerText);
         float textX = this.x + (this.width - textWidth) / 2.0F;
         float textY = this.y + (headerHeight - headerFont.height()) / 2.0F;
         context.drawText(headerFont, headerText, textX, textY, Colors.getTextColor().withAlpha(alpha));

         if (this.height >= 23.0F) {
            context.drawRect(
                    this.x,
                    this.y + headerHeight,
                    this.width,
                    SEPARATOR_HEIGHT,
                    Colors.getTextColor().withAlpha(alpha * 0.10F)
            );
         }

         float offset = 22.0F;
         class_1293 toRemove = null;
         for (class_1293 eff : this.effects.values()) {
            Animation anim = ((StatusEffectInstanceAddition)eff).fevervisual$getAnimPotion();
            if (anim.getValue() == 0.0F) {
               toRemove = eff;
            } else {
               float off = -4.5F + 4.5F * anim.getValue();
               if (offset != 22.0F) {
                  context.drawRect(
                          this.x,
                          this.y + offset + off,
                          this.width,
                          SEPARATOR_HEIGHT,
                          Colors.getTextColor().withAlpha(alpha * 0.015F * anim.getValue())
                  );
               }
               offset += 18.0F * anim.getValue();
            }
         }

         offset = 22.0F;
         for (class_1293 effx : this.effects.values()) {
            Animation anim = ((StatusEffectInstanceAddition)effx).fevervisual$getAnimPotion();
            if (anim.getValue() != 0.0F) {
               float off = -4.5F + 4.5F * anim.getValue();
               context.drawGuiTexture(
                       class_10799.field_56883,
                       class_329.method_71644(effx.method_5579()),
                       Math.round(this.x + 7.0F * anim.getValue()),
                       Math.round(this.y + offset + off + GuiUtility.getMiddleOfBox(8.0F, 18.0F) + 1.0F),
                       8,
                       8,
                       ColorRGBA.WHITE.withAlpha(alpha * anim.getValue()).getRGB()
               );
               offset += 18.0F * anim.getValue();
            }
         }
         offset = 22.0F;

         for (class_1293 effxx : this.effects.values()) {
            Animation anim = ((StatusEffectInstanceAddition)effxx).fevervisual$getAnimPotion();
            AnimatedNumber timeAnimation = ((StatusEffectInstanceAddition)effxx).fevervisual$getTimeAnimation();
            class_1291 potion = (class_1291)effxx.method_5579().comp_349();
            if (anim.getValue() != 0.0F) {
               float off = -4.5F + 4.5F * anim.getValue();
               String effectName = potion.method_5560().getString() + " " + (effxx.method_5578() > 0 ? effxx.method_5578() + 1 : "");
               ColorRGBA effectColor = potion.method_18792() == class_4081.field_18271 ? beneficialColor.getColorSafe() : harmfulColor.getColorSafe();
               boolean isFiniteEffect = !effxx.method_48559()
                       && effxx.method_5584() > 0
                       && effxx.method_5584() < 999999;
               boolean isStaticDuration = effxx.method_48559() || effxx.method_5584() >= 999999;
               boolean isTurtleHelmetEffect = potion.method_5567().contains("water_breathing") && effxx.method_5584() == 200;

               if (isFiniteEffect && !isStaticDuration && !isTurtleHelmetEffect) {
                  int totalSeconds = effxx.method_5584() / 20;
                  int minutes = totalSeconds / 60;
                  int seconds = totalSeconds % 60;
                  String timeStr = String.format("%02d:%02d", minutes, seconds);
                  String minutesAndSeparator = String.format("%02d:", minutes);
                  float timeX = this.x + this.width - 7.0F * anim.getValue();
                  float timeY = this.y + offset + off + GuiUtility.getMiddleOfBox(font.height(), 18.0F);
                  float minutesWidth = font.width(minutesAndSeparator);
                  float totalWidth = font.width(timeStr);
                  context.drawText(font, minutesAndSeparator, timeX - totalWidth, timeY,
                          effectColor.withAlpha(alpha * anim.getValue()));
                  timeAnimation.settings(true, effectColor.withAlpha(alpha * anim.getValue()));
                  timeAnimation.update(seconds);
                  timeAnimation.pos(timeX - totalWidth + minutesWidth, timeY);
                  timeAnimation.render(context);
               } else {
                  String duration = "**:**";
                  float timeX = this.x + this.width - 7.0F * anim.getValue();
                  float timeY = this.y + offset + off + GuiUtility.getMiddleOfBox(font.height(), 18.0F);
                  context.drawRightText(font, duration, timeX, timeY, effectColor.withAlpha((int)(alpha * anim.getValue())));
               }
               context.drawText(
                       font,
                       effectName,
                       this.x + 19.0F * anim.getValue(),
                       this.y + offset + off + GuiUtility.getMiddleOfBox(font.height(), 18.0F),
                       effectColor.withAlpha(alpha * anim.getValue())
               );
               offset += 18.0F * anim.getValue();
            }
         }

         if (toRemove != null) {
            class_1291 potion = (class_1291)toRemove.method_5579().comp_349();
            this.effects.remove(potion.method_5560().getString(), toRemove);
         }

         ScissorUtility.pop();
      }
   }

   @Override
   public boolean show() {
      return mc.field_1724 != null && mc.field_1687 != null
              ? (!mc.field_1724.method_6026().isEmpty() || mc.field_1755 instanceof class_408 || this.alwaysDisplay.isEnabled()) && !ServerUtility.isCM()
              : false;
   }

   public static boolean shouldReplaceVanilla() {
      return Interface.isHudElementEnabled("hud.effects");
   }
}
