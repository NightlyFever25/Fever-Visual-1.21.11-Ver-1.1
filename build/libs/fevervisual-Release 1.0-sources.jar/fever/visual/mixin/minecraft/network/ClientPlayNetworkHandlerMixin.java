package fever.visual.mixin.minecraft.network;

import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_2684;
import net.minecraft.class_634;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin implements IMinecraft {
   @Inject(method = "onEntity", at = @At("TAIL"))
   public void onEntity(class_2684 packet, CallbackInfo ci) {
      class_634 self = (class_634) (Object) this;
      class_638 world = self.method_2890();
   }
}
