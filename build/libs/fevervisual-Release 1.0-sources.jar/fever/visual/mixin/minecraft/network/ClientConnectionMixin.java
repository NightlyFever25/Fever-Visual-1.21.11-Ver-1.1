package fever.visual.mixin.minecraft.network;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.event.impl.network.SendPacketEvent;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class ClientConnectionMixin implements IMinecraft {
   @Unique
   private static boolean stackOverflowFix;

   @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
   private static <T extends class_2547> void triggerReceivePacketEvent(class_2596<T> packet, class_2547 listener, CallbackInfo ci) {
      ReceivePacketEvent event = new ReceivePacketEvent(packet);
      FeverVisual.getInstance().getEventManager().triggerEvent(event);
      if (event.isCancelled()) {
         ci.cancel();
      }
   }

   @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
   public void triggerSendPacketEvent(class_2596<?> packet, CallbackInfo ci) {
      SendPacketEvent event = new SendPacketEvent(packet);
      if (!stackOverflowFix) {
         FeverVisual.getInstance().getEventManager().triggerEvent(event);
         if (event.isCancelled()) {
            ci.cancel();
         }

         class_2596<?> newPacket = event.getPacket();
         if (newPacket != packet) {
            ci.cancel();
            stackOverflowFix = true;
            mc.method_1562().method_52787(newPacket);
            stackOverflowFix = false;
         }
      }
   }
}
