package fever.visual.mixin.minecraft.item;

import com.holdmylua.source.access.ItemStackAccessor;
import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.game.FinishEatEvent;
import fever.visual.systems.modules.modules.visuals.ArmorDurability;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements ItemStackAccessor {
   @Unique private int feverVisual$hmiTransform = -1;
   @Unique private int feverVisual$hmiSwingSpeed = 10;
   @Unique private int feverVisual$hmiShouldRenderAsBlock = -1;
   @Inject(method = "finishUsing", at = @At("TAIL"))
   private void onFinishUsing(class_1937 world, class_1309 user, CallbackInfoReturnable<class_1799> cir) {
      if (user instanceof class_1657 player) {
         FeverVisual.getInstance().getEventManager().triggerEvent(new FinishEatEvent(player, (class_1799) (Object) this));
      }
   }

   @Inject(method = "getItemBarColor", at = @At("HEAD"), cancellable = true)
   private void fevervisual$applyArmorDurabilityColor(CallbackInfoReturnable<Integer> cir) {
      ArmorDurability module = ArmorDurability.getModule();
      if (module == null || !module.isEnabled()) {
         return;
      }

      class_1799 stack = (class_1799) (Object) this;
      if (!stack.method_7963() || !stack.method_31578() || !fevervisual$isArmorLike(stack)) {
         return;
      }

      int maxDamage = stack.method_7936();
      if (maxDamage <= 0) {
         return;
      }

      float durabilityPercent = 1.0F - (float) stack.method_7919() / (float) maxDamage;
      cir.setReturnValue(module.getColorIntByPercent(durabilityPercent));
   }

   private static boolean fevervisual$isArmorLike(class_1799 stack) {
      class_10192 equippable = stack.method_58694(class_9334.field_54196);
      if (equippable == null) {
         return false;
      }

      class_1304 slot = equippable.comp_3174();
      return slot == class_1304.field_6169
              || slot == class_1304.field_6174
              || slot == class_1304.field_6172
              || slot == class_1304.field_6166;
   }

   @Override
   public void hMI5_0$setTransform(boolean value) {
      this.feverVisual$hmiTransform = value ? 1 : 0;
   }

   @Override
   public void hMI5_0$setTransform(int value) {
      this.feverVisual$hmiTransform = value;
   }

   @Override
   public int hMI5_0$getTransform() {
      return this.feverVisual$hmiTransform;
   }

   @Override
   public void hMI5_0$setSwingSpeed(int value) {
      this.feverVisual$hmiSwingSpeed = value;
   }

   @Override
   public int hMI5_0$getSwingSpeed() {
      return this.feverVisual$hmiSwingSpeed;
   }

   @Override
   public void hMI5_0$setRenderAsBlock(boolean value) {
      this.feverVisual$hmiShouldRenderAsBlock = value ? 1 : 0;
   }

   @Override
   public int hMI5_0$getRenderAsBlock() {
      return this.feverVisual$hmiShouldRenderAsBlock;
   }
}
