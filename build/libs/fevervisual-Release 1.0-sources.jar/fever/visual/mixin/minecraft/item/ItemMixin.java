package fever.visual.mixin.minecraft.item;

import fever.visual.systems.modules.modules.visuals.ArmorDurability;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public abstract class ItemMixin {

    @Inject(method = "getItemBarColor", at = @At("HEAD"), cancellable = true)
    private void fevervisual$applyArmorDurabilityColor(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        ArmorDurability module = ArmorDurability.getModule();
        if (module == null || !module.isEnabled()) {
            return;
        }

        if (stack == null || !stack.method_7963() || !fevervisual$isArmorLike(stack)) {
            return;
        }

        int maxDamage = stack.method_7936();
        if (maxDamage <= 0) {
            return;
        }

        float durabilityPercent = 1.0F - (float) stack.method_7919() / (float) maxDamage;
        cir.setReturnValue(module.getColorIntByPercent(durabilityPercent));
    }

    private static boolean fevervisual$isArmorLike(class_1799 stack) {
        class_10192 equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null) {
            return false;
        }

        class_1304 slot = equippable.comp_3174();
        return slot == class_1304.field_6169
                || slot == class_1304.field_6174
                || slot == class_1304.field_6172
                || slot == class_1304.field_6166;
    }
}
