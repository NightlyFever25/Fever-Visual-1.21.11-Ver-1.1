package fever.visual.mixin.minecraft.client.network;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.game.PickupEvent;
import fever.visual.systems.event.impl.game.WorldChangeEvent;
import fever.visual.utility.game.WorldUtility;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2672;
import net.minecraft.class_2678;
import net.minecraft.class_2775;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin extends class_8673 implements IMinecraft {

   protected ClientPlayNetworkHandlerMixin(class_310 client, class_2535 connection, class_8675 connectionState) {
      super(client, connection, connectionState);
   }

   @Inject(
      method = "onItemPickupAnimation",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/world/ClientWorld;getEntityById(I)Lnet/minecraft/entity/Entity;", ordinal = 0)
   )
   private void onItemPickupAnimation(class_2775 packet, CallbackInfo info) {
      class_1297 itemEntity = this.field_45588.field_1687.method_8469(packet.method_11915());
      class_1297 entity = this.field_45588.field_1687.method_8469(packet.method_11912());
      if (itemEntity instanceof class_1542 && entity == this.field_45588.field_1724) {
         FeverVisual.getInstance().getEventManager().triggerEvent(new PickupEvent(((class_1542)itemEntity).method_6983(), packet.method_11913()));
      }
   }

   @Inject(method = "onBlockEntityUpdate", at = @At("TAIL"))
   private void onBlockEntityUpdate(class_2622 packet, CallbackInfo ci) {
      if (mc.field_1687 != null) {
         class_2338 pos = packet.method_11293();
         class_2586 blockEntity = mc.field_1687.method_8321(pos);
         if (blockEntity != null && !WorldUtility.blockEntities.contains(blockEntity)) {
            WorldUtility.blockEntities.add(blockEntity);
         }
      }
   }

   @Inject(method = "onChunkData", at = @At("TAIL"))
   private void onChunkData(class_2672 packet, CallbackInfo ci) {
      if (ClientPlayNetworkHandlerMixin.mc.field_1687 != null) {
         class_2818 chunk = ClientPlayNetworkHandlerMixin.mc.field_1687.method_8497(packet.method_11523(), packet.method_11524());
         chunk.method_12214().values().forEach(be -> {
            if (!WorldUtility.blockEntities.contains(be)) {
               WorldUtility.blockEntities.add(be);
            }
         });
      }
   }

   @Inject(method = "onGameJoin", at = @At("TAIL"))
   private void onGameJoin(class_2678 packet, CallbackInfo ci) {
      WorldUtility.blockEntities.clear();
      FeverVisual.getInstance().getEventManager().triggerEvent(new WorldChangeEvent());
   }
}
