package fever.visual.mixin.minecraft.client.input;

import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_744.class)
public interface InputAccessor {
   @Accessor("movementVector")
   class_241 getMovementVector();

   @Accessor("movementVector")
   void setMovementVector(class_241 movement);

   @Accessor("playerInput")
   class_10185 getInput();

   @Accessor("playerInput")
   void setInput(class_10185 var1);
}
