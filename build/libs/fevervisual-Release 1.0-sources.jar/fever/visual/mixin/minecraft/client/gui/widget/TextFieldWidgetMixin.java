package fever.visual.mixin.minecraft.client.gui.widget;

import fever.visual.systems.modules.modules.visuals.CustomChat;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_342.class)
public class TextFieldWidgetMixin {
   @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;getWidth(Lnet/minecraft/text/OrderedText;)I"))
   private int fevervisual$getCustomChatOrderedWidth(class_327 renderer, class_5481 text) {
      return CustomChat.shouldUseCustomChatInputText() ? CustomChat.getCustomTextWidth(text) : renderer.method_30880(text);
   }

   @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;getWidth(Ljava/lang/String;)I"))
   private int fevervisual$getCustomChatStringWidth(class_327 renderer, String text) {
      return CustomChat.shouldUseCustomChatInputText() ? CustomChat.getCustomTextWidth(text) : renderer.method_1727(text);
   }

   @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;IIIZ)V"))
   private void fevervisual$drawCustomChatOrderedText(class_332 context, class_327 renderer, class_5481 text, int x, int y, int color, boolean shadow) {
      if (!CustomChat.renderChatInputOrderedText(context, text, x, y, color)) {
         context.method_51430(renderer, text, x, y, color, shadow);
      }
   }

   @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;IIIZ)V"))
   private void fevervisual$drawCustomChatStringText(class_332 context, class_327 renderer, String text, int x, int y, int color, boolean shadow) {
      if (!CustomChat.renderChatInputStringText(context, text, x, y, color)) {
         context.method_51433(renderer, text, x, y, color, shadow);
      }
   }

   @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)V"))
   private void fevervisual$drawCustomChatPlaceholderText(class_332 context, class_327 renderer, class_2561 text, int x, int y, int color) {
      if (!CustomChat.renderChatInputText(context, text, x, y, color)) {
         context.method_27535(renderer, text, x, y, color);
      }
   }
}
