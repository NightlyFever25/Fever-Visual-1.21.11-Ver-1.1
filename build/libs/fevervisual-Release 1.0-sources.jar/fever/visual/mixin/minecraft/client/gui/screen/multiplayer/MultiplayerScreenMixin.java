package fever.visual.mixin.minecraft.client.gui.screen.multiplayer;

import fever.visual.utility.game.server.SponsorServerUtility;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_500;
import net.minecraft.client.gui.screen.multiplayer.FeverVisualServerCategoryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_500.class)
public class MultiplayerScreenMixin {
   @Shadow
   protected class_4267 serverListWidget;
   @Shadow
   private class_4185 buttonJoin;
   @Shadow
   private class_4185 buttonEdit;
   @Shadow
   private class_4185 buttonDelete;

   @Inject(method = "updateButtonActivationStates", at = @At("RETURN"))
   private void feverVisual$lockSponsorButtons(CallbackInfo ci) {
      class_4267.class_504 entry = this.serverListWidget.method_25334();
      if (entry instanceof FeverVisualServerCategoryEntry) {
         this.buttonJoin.field_22763 = false;
         this.buttonEdit.field_22763 = false;
         this.buttonDelete.field_22763 = false;
      } else if (entry instanceof class_4267.class_4270 serverEntry && SponsorServerUtility.isSponsor(serverEntry.method_20133())) {
         this.buttonEdit.field_22763 = false;
         this.buttonDelete.field_22763 = false;
      }
   }
}
