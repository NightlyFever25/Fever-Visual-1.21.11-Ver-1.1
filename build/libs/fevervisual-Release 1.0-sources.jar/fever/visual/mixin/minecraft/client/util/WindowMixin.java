package fever.visual.mixin.minecraft.client.util;

import java.io.InputStream;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_3262;
import net.minecraft.class_7367;
import net.minecraft.class_8518;
import fever.visual.FeverVisual;
import fever.visual.minecraft.MinecraftClientMixinProtection;
import fever.visual.utility.game.PlatformUtility;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1041.class)
public class WindowMixin {
   @Redirect(
      method = "setIcon",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Icons;getIcons(Lnet/minecraft/resource/ResourcePack;)Ljava/util/List;")
   )
   public List<class_7367<InputStream>> setCustomIcon(class_8518 instance, class_3262 resourcePack) {
      InputStream icon16x = FeverVisual.class.getResourceAsStream("/assets/fevervisual/icons/window/icon16x16.png".formatted(FeverVisual.MOD_ID));
      InputStream icon32x = FeverVisual.class.getResourceAsStream("/assets/fevervisual/icons/window/icon32x32.png".formatted(FeverVisual.MOD_ID));
      return List.of(() -> icon16x, () -> icon32x);
   }

   @ModifyArg(
      method = "setTitle",
      at = @At(value = "INVOKE", target = "Lorg/lwjgl/glfw/GLFW;glfwSetWindowTitle(JLjava/lang/CharSequence;)V"),
      index = 1
   )
   private CharSequence forceLunarWindowTitle(CharSequence title) {
      if (PlatformUtility.isLunarClient() && !FeverVisual.INSTANCE.isSafeMode()) {
         return MinecraftClientMixinProtection.getCachedTitle();
      }
      return title;
   }
}
