package fever.visual.mixin.minecraft.client.gui.screen.multiplayer;

import fever.visual.utility.game.server.SponsorServerUtility;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_4267;
import net.minecraft.class_4280;
import net.minecraft.class_641;
import net.minecraft.client.gui.screen.multiplayer.FeverVisualServerCategoryEntry;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4267.class)
public abstract class MultiplayerServerListWidgetMixin extends class_4280<class_4267.class_504> {
   @Shadow
   @Final
   private List<class_4267.class_4270> servers;
   @Shadow
   @Final
   private class_4267.class_504 scanningEntry;
   @Shadow
   @Final
   private List<class_4267.class_4269> lanServers;

   public MultiplayerServerListWidgetMixin(class_310 client, int width, int height, int y, int itemHeight) {
      super(client, width, height, y, itemHeight);
   }

   @Inject(method = "setServers", at = @At("HEAD"))
   private void feverVisual$ensureSponsorBeforeEntries(class_641 serverList, CallbackInfo ci) {
      if (SponsorServerUtility.ensureFirst(serverList)) {
         serverList.method_2987();
      }
   }

   @Inject(method = "updateEntries", at = @At("RETURN"))
   private void feverVisual$addServerCategories(CallbackInfo ci) {
      class_4267.class_504 selected = this.method_25334();
      List<class_4267.class_504> entries = new ArrayList<>();
      int serverStart = 0;

      if (!this.servers.isEmpty() && SponsorServerUtility.isSponsor(this.servers.get(0).method_20133())) {
         entries.add(new FeverVisualServerCategoryEntry(SponsorServerUtility.SPONSOR_CATEGORY));
         entries.add(this.servers.get(0));
         serverStart = 1;
      }

      if (this.servers.size() > serverStart) {
         entries.add(new FeverVisualServerCategoryEntry(SponsorServerUtility.MULTIPLAYER_CATEGORY));

         for(int i = serverStart; i < this.servers.size(); ++i) {
            entries.add(this.servers.get(i));
         }
      }

      entries.add(this.scanningEntry);
      entries.addAll(this.lanServers);
      this.method_25314(entries);

      if (selected != null && entries.contains(selected)) {
         this.method_25313(selected);
      }
   }
}
