package fever.visual.mixin.minecraft.client.render;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.NoRender;
import net.minecraft.class_12077;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_9976;
import fever.visual.systems.modules.modules.other.Optimization;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9976.class)
public abstract class WeatherRendererMixin {
   @Inject(method = "buildPrecipitationPieces", at = @At("HEAD"), cancellable = true)
   private void fevervisual$suppressWeather(class_1937 world, int ticks, float tickDelta, class_243 pos, class_12077 state, CallbackInfo ci) {
      NoRender NoRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
      if (NoRender.isEnabled() && NoRender.getWeather().isSelected()) {
         ci.cancel();
         return;
      }

      Optimization optimization = Optimization.getInstanceSafe();
      if (optimization != null && optimization.shouldSkipWeatherRendering()) {
         ci.cancel();
      }
   }
}
