package fever.visual.mixin.minecraft.client.gui.overlay;

import fever.visual.utility.interfaces.ChatHudBackendContext;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(targets = "net.minecraft.client.gui.hud.ChatHud$Interactable")
public class ChatHudInteractableMixin implements ChatHudBackendContext {
   @Shadow
   private class_332 context;

   @Override
   public class_332 fevervisual$getContext() {
      return this.context;
   }
}
