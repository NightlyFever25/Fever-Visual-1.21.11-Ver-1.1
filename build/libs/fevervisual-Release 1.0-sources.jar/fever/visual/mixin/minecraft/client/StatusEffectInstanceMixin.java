package fever.visual.mixin.minecraft.client;

import fever.visual.framework.msdf.Fonts;
import fever.visual.ui.components.animated.AnimatedNumber;
import fever.visual.utility.animation.base.Animation;
import fever.visual.utility.animation.base.Easing;
import fever.visual.utility.mixins.StatusEffectInstanceAddition;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1293.class)
public class StatusEffectInstanceMixin implements StatusEffectInstanceAddition {
   @Unique
   private final Animation potionStatusAnimation = new Animation(300L, 0.0F, Easing.FIGMA_EASE_IN_OUT);
   @Unique
   private AnimatedNumber timeAnimation;

   @Inject(method = "<init>(Lnet/minecraft/registry/entry/RegistryEntry;IIZZZLnet/minecraft/entity/effect/StatusEffectInstance;)V", at = @At("TAIL"))
   public void onInit(
      class_6880<?> effect,
      int duration,
      int amplifier,
      boolean ambient,
      boolean showParticles,
      boolean showIcon,
      class_1293 hiddenEffect,
      CallbackInfo ci
   ) {
      if (class_310.method_1551() != null && class_310.method_1551().field_1724 != null) {
         this.timeAnimation = new AnimatedNumber(Fonts.REGULAR.getFont(7.0F), 3.0F, 300L, Easing.FIGMA_EASE_IN_OUT);
      }
   }

   @Override
   public Animation fevervisual$getAnimPotion() {
      return this.potionStatusAnimation;
   }

   @Override
   public AnimatedNumber fevervisual$getTimeAnimation() {
      return this.timeAnimation;
   }
}
