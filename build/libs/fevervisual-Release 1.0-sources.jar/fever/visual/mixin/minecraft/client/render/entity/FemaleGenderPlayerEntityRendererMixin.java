package fever.visual.mixin.minecraft.client.render.entity;

import fever.visual.utility.render.female.FemaleGenderArmorLayer;
import fever.visual.utility.render.female.FemaleGenderLayer;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1657;
import net.minecraft.class_3883;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class FemaleGenderPlayerEntityRendererMixin extends class_922<class_1657, class_10055, class_591> {
   private FemaleGenderPlayerEntityRendererMixin(class_5617.class_5618 context, class_591 model, float shadowRadius) {
      super(context, model, shadowRadius);
   }

   @SuppressWarnings("unchecked")
   @Inject(method = "<init>", at = @At("TAIL"))
   private void fevervisual$addFemaleGenderLayer(class_5617.class_5618 context, boolean slim, CallbackInfo ci) {
      this.method_4046(new FemaleGenderLayer((class_3883<class_10055, class_591>) (Object) this));
      this.method_4046(new FemaleGenderArmorLayer((class_3883<class_10055, class_591>) (Object) this, context.method_64071()));
   }
}
