package fever.visual.mixin.minecraft.client.render;

import fever.visual.utility.render.compat.RenderSystem;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_4608;
import fever.visual.systems.modules.modules.visuals.HitColor;
import fever.visual.utility.render.OverlayTextureReloadBridge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4608.class)
public abstract class OverlayTextureMixin {
    @Unique
    private static final int FEVER_VISUAL_DEFAULT_HIT_OVERLAY = -1291911168;
    @Unique
    private final Runnable fevervisual$reloadCallback = this::fevervisual$reloadOverlay;

    @Shadow
    @Final
    private class_1043 texture;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void fevervisual$onInit(CallbackInfo ci) {
        OverlayTextureReloadBridge.register(this.fevervisual$reloadCallback);
        this.fevervisual$reloadOverlay();
    }

    @Inject(method = "close", at = @At("HEAD"))
    private void fevervisual$onClose(CallbackInfo ci) {
        OverlayTextureReloadBridge.unregister(this.fevervisual$reloadCallback);
    }

    @Unique
    private int fevervisual$getTargetOverlayColor() {
        HitColor module = HitColor.getModule();
        if (module != null && module.isEnabled()) {
            return module.getOverlayArgb();
        }
        return FEVER_VISUAL_DEFAULT_HIT_OVERLAY;
    }

    @Unique
    private void fevervisual$reloadOverlay() {
        class_1011 nativeImage = this.texture.method_4525();
        if (nativeImage == null) {
            return;
        }

        int color = this.fevervisual$getTargetOverlayColor();
        for (int y = 0; y < 8; ++y) {
            for (int x = 0; x < 16; ++x) {
                nativeImage.method_61941(x, y, color);
            }
        }

        this.texture.method_4524();
    }
}
