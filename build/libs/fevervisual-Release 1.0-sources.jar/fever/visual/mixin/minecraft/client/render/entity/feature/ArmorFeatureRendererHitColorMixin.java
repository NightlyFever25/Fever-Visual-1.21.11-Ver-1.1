package fever.visual.mixin.minecraft.client.render.entity.feature;

import fever.visual.systems.modules.modules.visuals.HitColor;
import fever.visual.utility.render.HitColorRenderContext;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_970.class)
public abstract class ArmorFeatureRendererHitColorMixin<
        S extends class_10034,
        M extends class_572<S>,
        A extends class_572<S>> {

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
            at = @At("HEAD"),
            require = 1
    )
    private void fevervisual$startArmorHitRender(
            class_4587 matrices,
            class_11659 queue,
            int light,
            S state,
            float limbAngle,
            float limbDistance,
            CallbackInfo ci
    ) {
        HitColor module = HitColor.getModule();
        boolean useHurtOverlay = module != null && module.isEnabled() && state != null && state.field_53460;
        HitColorRenderContext.setHurt(useHurtOverlay);
    }

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
            at = @At("RETURN"),
            require = 1
    )
    private void fevervisual$endArmorHitRender(
            class_4587 matrices,
            class_11659 queue,
            int light,
            S state,
            float limbAngle,
            float limbDistance,
            CallbackInfo ci
    ) {
        HitColorRenderContext.clear();
    }
}
