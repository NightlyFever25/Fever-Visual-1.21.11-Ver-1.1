package fever.visual.mixin.minecraft.client.gui.overlay;

import fever.visual.systems.modules.modules.visuals.CustomChat;
import fever.visual.utility.game.PlatformUtility;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public class ChatHudMixin {
   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V", at = @At("HEAD"), cancellable = true)
   private void fevervisual$skipHudChatBehindOpenCustomChat(
      class_332 context,
      class_327 textRenderer,
      int currentTick,
      int mouseX,
      int mouseY,
      boolean interactable,
      boolean bl,
      CallbackInfo ci
   ) {
      if (PlatformUtility.isLabyMod() && CustomChat.renderChatFrame(context, currentTick, interactable)) {
         ci.cancel();
         return;
      }

      CustomChat.beginChatRender();
      if (!interactable && CustomChat.isActive() && class_310.method_1551().field_1755 instanceof class_408) {
         ci.cancel();
      }
   }

   @ModifyConstant(
      method = "render(Lnet/minecraft/client/gui/hud/ChatHud$Backend;IIZ)V",
      constant = @Constant(intValue = 9),
      require = 0
   )
   private int fevervisual$customChatLineHeight(int original) {
      return CustomChat.getLineHeight(original);
   }

   @Inject(method = "clear", at = @At("HEAD"), cancellable = true)
   private void fevervisual$keepCustomChatHistory(boolean clearHistory, CallbackInfo ci) {
      if (CustomChat.shouldKeepHistory()) {
         ci.cancel();
      }
   }
}
