package fever.visual.mixin.minecraft.client.gui.screen.multiplayer;

import fever.visual.mixin.accessors.MultiplayerScreenAccessor;
import fever.visual.utility.game.server.SponsorServerUtility;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_12293;
import net.minecraft.class_4267;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4267.class_4270.class)
public abstract class MultiplayerServerEntryMixin implements class_12293 {
   @Shadow
   @Final
   private class_500 screen;
   @Shadow
   @Final
   private class_642 server;

   @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
   private void feverVisual$fixMoveWithCategories(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
      class_4267.class_4270 self = (class_4267.class_4270)(Object)this;
      int x = (int)click.comp_4798() - self.method_73380();
      int y = (int)click.comp_4799() - self.method_73382();
      if (this.method_76267(x, y, 32)) {
         cir.setReturnValue(this.feverVisual$move(-1));
      } else if (this.method_76268(x, y, 32)) {
         cir.setReturnValue(this.feverVisual$move(1));
      }
   }

   @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
   private void feverVisual$fixKeyboardMoveWithCategories(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
      if (input.method_74239() && (input.method_74234() || input.method_74235())) {
         cir.setReturnValue(this.feverVisual$move(input.method_74234() ? -1 : 1));
      }
   }

   private boolean feverVisual$move(int direction) {
      class_641 serverList = this.screen.method_2529();
      SponsorServerUtility.ensureFirst(serverList);
      int index = SponsorServerUtility.indexOf(serverList, this.server);
      int target = index + direction;
      if (index < 0 || target < 0 || target >= serverList.method_2984() || SponsorServerUtility.isSponsor(this.server) || target == 0) {
         return true;
      }

      serverList.method_2985(index, target);
      SponsorServerUtility.ensureFirst(serverList);
      serverList.method_2987();
      ((MultiplayerScreenAccessor)this.screen).feverVisual$getServerListWidget().method_20125(serverList);
      return true;
   }
}
