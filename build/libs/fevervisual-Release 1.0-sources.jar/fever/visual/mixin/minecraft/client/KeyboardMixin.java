package fever.visual.mixin.minecraft.client;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.window.KeyPressEvent;
import fever.visual.utility.game.PlatformUtility;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin implements IMinecraft {
   @Inject(method = "onKey(JILnet/minecraft/client/input/KeyInput;)V", at = @At("HEAD"))
   public void triggerKeyEvent(long window, int action, class_11908 input, CallbackInfo ci) {
      int key = input.comp_4795();
      if (key != -1) {
         FeverVisual.getInstance().getEventManager().triggerEvent(new KeyPressEvent(action, key));
         if (PlatformUtility.isLabyMod() && action == GLFW.GLFW_PRESS) {
            if (key == GLFW.GLFW_KEY_T || key == GLFW.GLFW_KEY_SLASH || key == 46) {
               PlatformUtility.markChatEditorOpen();
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) {
               PlatformUtility.markChatEditorClosed();
            }
         }

         if (mc.field_1755 == null) {
            if (key == 46 && action == 1) {
               mc.method_1507(new class_408("", false));
            }
         }
      }
   }
}
