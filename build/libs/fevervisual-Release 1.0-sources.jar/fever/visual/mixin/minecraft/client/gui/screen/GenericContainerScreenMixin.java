package fever.visual.mixin.minecraft.client.gui.screen;

import fever.visual.FeverVisual;
import fever.visual.framework.base.CustomDrawContext;
import fever.visual.systems.modules.modules.visuals.CustomInv;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.GuiPanelStyle;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_476.class)
public abstract class GenericContainerScreenMixin extends class_465<class_1707> implements IMinecraft {
   protected GenericContainerScreenMixin(class_1707 handler, class_1661 inventory, class_2561 title) {
      super(handler, inventory, title);
   }

   @Inject(method = "drawBackground", at = @At("HEAD"), cancellable = true)
   private void fevervisual$drawChestAndBarrelBackground(class_332 context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
      if (!this.fevervisual$isCustomInventoryEnabled()) {
         return;
      }

      ci.cancel();
      GuiPanelStyle.drawPanel(CustomDrawContext.of(context), this.field_2776, this.field_2800, this.field_2792, this.field_2779, 7.0F);
   }

   @Unique
   private boolean fevervisual$isCustomInventoryEnabled() {
      if (FeverVisual.getInstance().getModuleManager() == null) {
         return false;
      }

      CustomInv module = FeverVisual.getInstance().getModuleManager().getModuleSafe(CustomInv.class);
      return module != null && module.isEnabled();
   }
}
