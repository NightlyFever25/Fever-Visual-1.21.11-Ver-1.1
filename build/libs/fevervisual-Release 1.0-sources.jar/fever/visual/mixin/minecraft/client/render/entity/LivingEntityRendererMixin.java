package fever.visual.mixin.minecraft.client.render.entity;

import fever.visual.FeverVisual;
import fever.visual.systems.event.RenderStateEntityCache;
import fever.visual.systems.modules.modules.visuals.BadTrip;
import fever.visual.systems.modules.modules.visuals.ChinaHatModule;
import fever.visual.systems.modules.modules.visuals.CustomModels;
import fever.visual.systems.modules.modules.visuals.FriendMarkers;
import fever.visual.systems.modules.modules.visuals.ModelChanger;
import fever.visual.systems.modules.modules.visuals.SelfTag;
import fever.visual.systems.modules.modules.visuals.cosmetic.CustomModelType;
import fever.visual.systems.modules.modules.visuals.cosmetic.CustomModelsRenderer;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_3882;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_9064;
import net.minecraft.class_922;
import net.minecraft.class_970;
import net.minecraft.class_979;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static fever.visual.utility.interfaces.IMinecraft.mc;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
   @Unique
   private static final String FEVER_VISUAL_RENDER_METHOD =
      "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;"
         + "Lnet/minecraft/client/util/math/MatrixStack;"
         + "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
         + "Lnet/minecraft/client/render/state/CameraRenderState;)V";

   @Shadow
   @Nullable
   protected abstract class_1921 getRenderLayer(S state, boolean showBody, boolean translucent, boolean showOutline);

   @Shadow
   protected M model;

   @Unique private static final FriendMarkers FRIEND_MARKERS_MODULE = FeverVisual.getInstance().getModuleManager().getModule(FriendMarkers.class);
   @Unique private static final ModelChanger MODEL_CHANGER_MODULE = FeverVisual.getInstance().getModuleManager().getModule(ModelChanger.class);
   @Unique private static final BadTrip BAD_TRIP_MODULE = FeverVisual.getInstance().getModuleManager().getModule(BadTrip.class);
   @Unique private static final CustomModels CUSTOM_MODELS_MODULE = FeverVisual.getInstance().getModuleManager().getModule(CustomModels.class);
   @Unique private static final ChinaHatModule CHINA_HAT_MODULE = FeverVisual.getInstance().getModuleManager().getModule(ChinaHatModule.class);

   @Unique private boolean fevervisual$scaleHead;
   @Unique private boolean fevervisual$scaleModel;
   @Unique private boolean fevervisual$badTrip;
   @Unique private boolean fevervisual$skipArmor;
   @Unique private boolean fevervisual$pushedTransform;
   @Unique private boolean fevervisual$chinaHatSubmitted;
   @Unique private float fevervisual$modelScale = 1.0F;
   @Unique private float fevervisual$modelOffset;
   @Unique private float fevervisual$badTripX = 1.0F;
   @Unique private float fevervisual$badTripY = 1.0F;
   @Unique private float fevervisual$badTripZ = 1.0F;
   @Unique private S fevervisual$currentState;

   @Inject(method = "updateRenderState", at = @At("TAIL"))
   private void fevervisual$storeEntity(class_1309 entity, S state, float tickProgress, CallbackInfo ci) {
      RenderStateEntityCache.put(state, entity);
      if (entity == mc.field_1724 && SelfTag.isActive() && state.field_53337 == null && !mc.field_1690.method_31044().method_31034()) {
         state.field_53337 = entity.method_5476();
         state.field_53338 = entity.method_56072().method_55675(class_9064.field_47745, 0, entity.method_5705(tickProgress));
      }
   }

   @Inject(method = FEVER_VISUAL_RENDER_METHOD, at = @At("HEAD"))
   private void fevervisual$beginRender(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
      this.fevervisual$currentState = state;
      this.fevervisual$scaleHead = false;
      this.fevervisual$scaleModel = false;
      this.fevervisual$badTrip = false;
      this.fevervisual$skipArmor = false;
      this.fevervisual$pushedTransform = false;
      this.fevervisual$chinaHatSubmitted = false;
      this.fevervisual$modelScale = 1.0F;
      this.fevervisual$modelOffset = 0.0F;
      this.fevervisual$badTripX = 1.0F;
      this.fevervisual$badTripY = 1.0F;
      this.fevervisual$badTripZ = 1.0F;

      class_1309 entity = RenderStateEntityCache.get(state);
      if (!(entity instanceof class_1657 player)) {
         return;
      }

      boolean self = player == mc.field_1724;
      String name = player.method_5477().getString();
      boolean friend = FeverVisual.getInstance().getFriendManager().isFriend(name);
      boolean invisibleOtherPlayer = !self && this.fevervisual$isInvisible(player);
      this.fevervisual$scaleHead = FRIEND_MARKERS_MODULE != null
         && FRIEND_MARKERS_MODULE.isEnabled()
         && FRIEND_MARKERS_MODULE.getHeads() != null
         && FRIEND_MARKERS_MODULE.getHeads().isSelected()
         && friend
         && !invisibleOtherPlayer;

      if (MODEL_CHANGER_MODULE != null && MODEL_CHANGER_MODULE.isEnabled() && !invisibleOtherPlayer) {
         this.fevervisual$modelScale = MODEL_CHANGER_MODULE.getScaleForPlayer(name, self);
         this.fevervisual$scaleModel = this.fevervisual$modelScale != 1.0F;
         this.fevervisual$modelOffset = (1.0F - this.fevervisual$modelScale) * 1.5F;
      }

      if (BAD_TRIP_MODULE != null && BAD_TRIP_MODULE.isEnabled() && BAD_TRIP_MODULE.shouldAffectPlayer(player)) {
         this.fevervisual$badTrip = true;
         BAD_TRIP_MODULE.updateScales();
         this.fevervisual$badTripX = BadTrip.getCurrentScaleX();
         this.fevervisual$badTripY = BadTrip.getCurrentScaleY();
         this.fevervisual$badTripZ = BadTrip.getCurrentScaleZ();
      }

      this.fevervisual$skipArmor = CUSTOM_MODELS_MODULE != null
         && CUSTOM_MODELS_MODULE.isEnabled()
         && CUSTOM_MODELS_MODULE.shouldApplyTo(player)
         && (self || friend);
   }

   @ModifyExpressionValue(
      method = FEVER_VISUAL_RENDER_METHOD,
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;")
   )
   private class_1921 fevervisual$renderLayer(class_1921 original) {
      class_1309 entity = RenderStateEntityCache.get(this.fevervisual$currentState);
      CustomModelType type = entity != null && CUSTOM_MODELS_MODULE != null && CUSTOM_MODELS_MODULE.shouldApplyTo(entity)
         ? CUSTOM_MODELS_MODULE.getSelectedTypeFor(entity)
         : null;
      if (type != null) {
         class_2960 texture = type.getTexture();
         return class_12249.method_75980(texture, true);
      }
      return original;
   }

   @Redirect(
      method = FEVER_VISUAL_RENDER_METHOD,
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/EntityRenderState;FF)V")
   )
   @SuppressWarnings({"rawtypes", "unchecked"})
   private void fevervisual$renderFeature(class_3887 feature, class_4587 matrices, class_11659 queue, int light, class_10017 state, float limbAngle, float limbDistance) {
      if (!this.fevervisual$skipArmor || !(feature instanceof class_970 || feature instanceof class_979)) {
         feature.method_4199(matrices, queue, light, state, limbAngle, limbDistance);
      }
   }

   @Inject(
      method = FEVER_VISUAL_RENDER_METHOD,
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;setupTransforms(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;FF)V")
   )
   private void fevervisual$applyTransform(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
      if (!this.fevervisual$scaleModel && !this.fevervisual$badTrip) {
         return;
      }

      float x = this.fevervisual$modelScale * this.fevervisual$badTripX;
      float y = this.fevervisual$modelScale * this.fevervisual$badTripY;
      float z = this.fevervisual$modelScale * this.fevervisual$badTripZ;
      float offset = this.fevervisual$modelOffset;
      if (this.fevervisual$badTrip && this.fevervisual$badTripY != 1.0F) {
         offset += (1.0F - this.fevervisual$badTripY) * 0.8F;
      }

      matrices.method_22903();
      matrices.method_46416(0.0F, -offset, 0.0F);
      matrices.method_22905(x, y, z);
      matrices.method_46416(0.0F, offset / y, 0.0F);
      this.fevervisual$pushedTransform = true;
      if (MODEL_CHANGER_MODULE != null && this.fevervisual$scaleModel) {
         ModelChanger.setCurrentScale(this.fevervisual$modelScale);
         ModelChanger.setCurrentOffset(this.fevervisual$modelOffset);
      }
   }

   @Redirect(
      method = FEVER_VISUAL_RENDER_METHOD,
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V")
   )
   @SuppressWarnings({"unchecked", "rawtypes"})
   private void fevervisual$submitModel(
      class_11659 queue,
      class_3879 model,
      Object state,
      class_4587 matrices,
      class_1921 layer,
      int light,
      int overlay,
      int color,
      class_1058 sprite,
      int outlineColor,
      class_11683.class_11792 crumbling
   ) {
      class_1309 entity = RenderStateEntityCache.get(this.fevervisual$currentState);
      CustomModelType customType = entity != null && CUSTOM_MODELS_MODULE != null && CUSTOM_MODELS_MODULE.shouldApplyTo(entity)
         ? CUSTOM_MODELS_MODULE.getSelectedTypeFor(entity)
         : null;
      boolean enlargedHead = this.fevervisual$scaleHead;
      if (customType == null && !enlargedHead) {
         queue.method_73490(model, state, matrices, layer, light, overlay, color, sprite, outlineColor, crumbling);
         this.fevervisual$renderChinaHat(queue, model, state, matrices, layer, light);
         return;
      }

      queue.method_73483(matrices, layer, (entry, vertices) -> {
         class_4587 renderMatrices = new class_4587();
         renderMatrices.method_34425(entry.method_23761());
         class_583 entityModel = (class_583)model;
         entityModel.method_2819(state);
         class_630 head = entityModel instanceof class_572<?> biped ? biped.field_3398 : null;
         float oldX = head == null ? 1.0F : head.field_37938;
         float oldY = head == null ? 1.0F : head.field_37939;
         float oldZ = head == null ? 1.0F : head.field_37940;
         if (head != null && enlargedHead) {
            head.field_37938 *= 1.5F;
            head.field_37939 *= 1.5F;
            head.field_37940 *= 1.5F;
         }

         boolean renderedCustom = customType != null
            && CustomModelsRenderer.render(customType, entityModel, renderMatrices, vertices, light, overlay, color);
         if (!renderedCustom) {
            entityModel.method_62100(renderMatrices, vertices, light, overlay, color);
         }
         if (head != null) {
            head.field_37938 = oldX;
            head.field_37939 = oldY;
            head.field_37940 = oldZ;
         }
      });
      this.fevervisual$renderChinaHat(queue, model, state, matrices, layer, light);
   }

   @Unique
   @SuppressWarnings({"rawtypes", "unchecked"})
   private void fevervisual$renderChinaHat(
      class_11659 queue,
      class_3879 model,
      Object state,
      class_4587 matrices,
      class_1921 layer,
      int light
   ) {
      class_1309 entity = RenderStateEntityCache.get(this.fevervisual$currentState);
      if (!(entity instanceof class_742 player)
         || CHINA_HAT_MODULE == null
         || !CHINA_HAT_MODULE.shouldRenderForPlayer(player)
         || !(model instanceof class_583 entityModel)
         || !(entityModel instanceof class_3882 headModel)) {
         return;
      }

      queue.method_73483(matrices, layer, (entry, vertices) -> {
         class_4587 renderMatrices = new class_4587();
         renderMatrices.method_34425(entry.method_23761());
         entityModel.method_2819(state);
         entityModel.method_63512().method_22703(renderMatrices);
         headModel.method_74046(renderMatrices);
         CHINA_HAT_MODULE.renderHeadAnchored(player, renderMatrices);
      });
      this.fevervisual$chinaHatSubmitted = true;
   }

   @Inject(method = FEVER_VISUAL_RENDER_METHOD, at = @At("RETURN"))
   private void fevervisual$finishRender(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
      this.fevervisual$renderInvisibleSelfChinaHat(state, matrices, queue);
      if (this.fevervisual$pushedTransform) {
         matrices.method_22909();
      }
      if (MODEL_CHANGER_MODULE != null && this.fevervisual$scaleModel) {
         ModelChanger.setCurrentScale(1.0F);
         ModelChanger.setCurrentOffset(0.0F);
      }
      this.fevervisual$currentState = null;
      this.fevervisual$skipArmor = false;
      this.fevervisual$pushedTransform = false;
      this.fevervisual$chinaHatSubmitted = false;
   }

   @Unique
   @SuppressWarnings({"rawtypes", "unchecked"})
   private void fevervisual$renderInvisibleSelfChinaHat(S state, class_4587 matrices, class_11659 queue) {
      if (this.fevervisual$chinaHatSubmitted
         || CHINA_HAT_MODULE == null
         || this.model == null
         || !(this.model instanceof class_3882 headModel)
         || !(RenderStateEntityCache.get(state) instanceof class_742 player)
         || player != mc.field_1724
         || !CHINA_HAT_MODULE.shouldRenderForPlayer(player)) {
         return;
      }

      class_1921 layer = this.getRenderLayer(state, true, true, false);
      if (layer == null) {
         layer = class_12249.method_75980(FeverVisual.id("textures/particles/triangle.png"), true);
      }

      class_583 entityModel = this.model;
      queue.method_73483(matrices, layer, (entry, vertices) -> {
         class_4587 renderMatrices = new class_4587();
         renderMatrices.method_34425(entry.method_23761());
         entityModel.method_2819(state);
         entityModel.method_63512().method_22703(renderMatrices);
         headModel.method_74046(renderMatrices);
         CHINA_HAT_MODULE.renderHeadAnchored(player, renderMatrices);
      });
      this.fevervisual$chinaHatSubmitted = true;
   }

   @Unique
   private boolean fevervisual$isInvisible(class_1309 entity) {
      if (entity.method_6059(class_1294.field_5905)) {
         return true;
      }
      if (entity.method_5767()) {
         return true;
      }
      return mc.field_1724 != null && entity.method_5756(mc.field_1724);
   }
}
