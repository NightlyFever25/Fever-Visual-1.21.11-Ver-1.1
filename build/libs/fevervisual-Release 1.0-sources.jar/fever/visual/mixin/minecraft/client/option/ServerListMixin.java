package fever.visual.mixin.minecraft.client.option;

import fever.visual.utility.game.server.SponsorServerUtility;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_641.class)
public class ServerListMixin {
   @Inject(method = "loadFile", at = @At("RETURN"))
   private void feverVisual$ensureSponsorAfterLoad(CallbackInfo ci) {
      class_641 serverList = (class_641)(Object)this;
      if (SponsorServerUtility.ensureFirst(serverList)) {
         serverList.method_2987();
      }
   }

   @Inject(method = "saveFile", at = @At("HEAD"))
   private void feverVisual$ensureSponsorBeforeSave(CallbackInfo ci) {
      SponsorServerUtility.ensureFirst((class_641)(Object)this);
   }

   @Inject(method = "remove", at = @At("HEAD"), cancellable = true)
   private void feverVisual$cancelSponsorRemove(class_642 serverInfo, CallbackInfo ci) {
      if (SponsorServerUtility.isSponsor(serverInfo)) {
         SponsorServerUtility.ensureFirst((class_641)(Object)this);
         ci.cancel();
      }
   }
}
