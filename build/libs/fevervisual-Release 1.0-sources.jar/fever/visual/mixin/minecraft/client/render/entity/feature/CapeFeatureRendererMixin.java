package fever.visual.mixin.minecraft.client.render.entity.feature;

import fever.visual.systems.modules.modules.visuals.Cape;
import fever.visual.utility.render.cape.WaveyCapeClothRenderer;
import net.minecraft.class_10055;
import net.minecraft.class_10186;
import net.minecraft.class_10192;
import net.minecraft.class_10201;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import net.minecraft.class_9334;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_972.class, priority = 2000)
public abstract class CapeFeatureRendererMixin {

    @Shadow
    @Final
    private class_10201 equipmentModelLoader;

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void fevervisual$renderWaveyCape(
            class_4587 matrices,
            class_11659 queue,
            int light,
            class_10055 state,
            float limbAngle,
            float limbDistance,
            CallbackInfo ci
    ) {
        Cape module = Cape.getModule();
        if (module == null || !module.isEnabled() || !module.isClothPhysicsEnabled()) {
            return;
        }

        if (state == null || state.field_53333 || !state.field_53532) {
            return;
        }

        class_8685 skinTextures = state.field_53520;
        if (skinTextures == null) {
            return;
        }

        class_2960 capeTexture = skinTextures.comp_1627() == null ? null : skinTextures.comp_1627().comp_3627();
        if (capeTexture == null) {
            return;
        }

        if (this.fevervisual$hasCustomModelForLayer(state.field_53418, class_10186.class_10190.field_54127)) {
            return;
        }

        class_742 player = this.fevervisual$findPlayerById(state.field_53528);
        if (player == null) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && client.field_1724.method_5628() == state.field_53528) {
                player = client.field_1724;
            }
        }

        if (player == null || !module.shouldRenderForPlayer(player)) {
            return;
        }

        float tickDelta = class_310.method_1551().method_61966().method_60637(false);
        tickDelta = class_3532.method_15363(tickDelta, 0.0F, 1.0F);

        ci.cancel();
        matrices.method_22903();
        if (this.fevervisual$hasCustomModelForLayer(state.field_53418, class_10186.class_10190.field_54125)) {
            matrices.method_46416(0.0F, -0.053125F, 0.06875F);
        }

        WaveyCapeClothRenderer.render(matrices, queue, light, state, capeTexture, module, player, tickDelta);
        matrices.method_22909();
    }

    @Unique
    private class_742 fevervisual$findPlayerById(int id) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return null;
        }

        for (class_742 player : client.field_1687.method_18456()) {
            if (player.method_5628() == id) {
                return player;
            }
        }
        return null;
    }

    @Unique
    private boolean fevervisual$hasCustomModelForLayer(class_1799 stack, class_10186.class_10190 layerType) {
        class_10192 equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null || equippable.comp_3176().isEmpty()) {
            return false;
        }
        class_10186 equipmentModel = this.equipmentModelLoader.method_64087(equippable.comp_3176().get());
        return !equipmentModel.method_63996(layerType).isEmpty();
    }
}
