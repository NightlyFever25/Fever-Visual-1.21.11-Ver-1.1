package fever.visual.mixin.minecraft.client;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.Ambience;
import net.minecraft.class_2874;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2874.class)
public class ClientWorldMixin {
   @Inject(method = "skybox", at = @At("HEAD"), cancellable = true)
   private void fevervisual$useEndSkybox(CallbackInfoReturnable<class_2874.class_12326> info) {
      if (FeverVisual.getInstance().getModuleManager().getModule(Ambience.class).isEnabled()
         && FeverVisual.getInstance().getModuleManager().getModule(Ambience.class).getEndSky().isEnabled()) {
         info.setReturnValue(class_2874.class_12326.field_64387);
      }
   }
}
