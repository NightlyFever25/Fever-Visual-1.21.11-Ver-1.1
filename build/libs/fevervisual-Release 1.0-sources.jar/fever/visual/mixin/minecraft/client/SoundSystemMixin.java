package fever.visual.mixin.minecraft.client;

import fever.visual.minecraft.SoundSystemMixinProtection;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1140.class)
public class SoundSystemMixin {
   @Inject(
      method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;",
      at = @At("HEAD"),
      cancellable = true
   )
   private void onPlaySound(class_1113 sound, CallbackInfoReturnable<class_1140.class_11518> cir) {
      SoundSystemMixinProtection.playSound(sound, cir);
   }
}
