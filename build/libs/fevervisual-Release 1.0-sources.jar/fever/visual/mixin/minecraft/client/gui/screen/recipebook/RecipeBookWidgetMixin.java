package fever.visual.mixin.minecraft.client.gui.screen.recipebook;

import fever.visual.FeverVisual;
import fever.visual.framework.base.CustomDrawContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.framework.objects.BorderRadius;
import fever.visual.systems.modules.modules.visuals.CustomInv;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.GuiPanelStyle;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_507;
import net.minecraft.class_5676;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_507.class)
public abstract class RecipeBookWidgetMixin implements IMinecraft {
   @Shadow
   private class_342 searchField;

   @Shadow
   protected class_5676<Boolean> toggleCraftableButton;

   @Inject(method = "initialize", at = @At("TAIL"))
   private void fevervisual$initCustomControls(int parentWidth, int parentHeight, class_310 client, boolean narrow, CallbackInfo ci) {
      if (this.searchField == null) {
         return;
      }

      if (this.fevervisual$isCustomInventoryEnabled()) {
         this.searchField.method_1858(false);
         this.searchField.method_47404(class_2561.method_43473());
         this.searchField.method_1868(Colors.getTextColor().withAlpha(255.0F).getRGB());
      } else {
         this.searchField.method_1858(true);
         this.searchField.method_47404(class_2561.method_43471("gui.recipebook.search_hint"));
         this.searchField.method_1868(16777215);
      }
   }

   @Redirect(
      method = "render",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIFFIIII)V"
      )
   )
   private void fevervisual$replaceRecipeBookBackground(
      class_332 context,
      RenderPipeline pipeline,
      class_2960 texture,
      int x,
      int y,
      float u,
      float v,
      int width,
      int height,
      int textureWidth,
      int textureHeight
   ) {
      if (!this.fevervisual$isCustomInventoryEnabled()) {
         context.method_25290(pipeline, texture, x, y, u, v, width, height, textureWidth, textureHeight);
         return;
      }

      GuiPanelStyle.drawPanel(CustomDrawContext.of(context), x, y, width, height, 7.0F);
   }

   @Redirect(
      method = "render",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/widget/TextFieldWidget;render(Lnet/minecraft/client/gui/DrawContext;IIF)V"
      )
   )
   private void fevervisual$renderCustomSearchField(class_342 field, class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.fevervisual$isCustomInventoryEnabled()) {
         field.method_25394(context, mouseX, mouseY, delta);
         return;
      }

      CustomDrawContext customContext = CustomDrawContext.of(context);
      GuiPanelStyle.drawPanel(customContext, field.method_46426() - 2.0F, field.method_46427() - 1.0F, field.method_25368() + 4.0F, field.method_25364() + 2.0F, 5.0F, field.method_25370() ? 1.0F : 0.95F);

      field.method_1858(false);
      field.method_47404(class_2561.method_43473());
      field.method_1868(0x00000000);
      field.method_1860(0x00000000);

      Font textFont = Fonts.MEDIUM.getFont(7.3F);
      String inputText = field.method_1882();
      boolean empty = inputText == null || inputText.isEmpty();
      String displayText = empty ? "\u041D\u0430\u0439\u0442\u0438..." : inputText;
      float textWidth = textFont.width(displayText);
      float textX = field.method_46426() + field.method_25368() / 2.0F - textWidth / 2.0F;
      float textY = field.method_46427() + field.method_25364() / 2.0F - textFont.height() / 2.0F + 0.5F;
      context.method_44379(field.method_46426() + 2, field.method_46427() + 1, field.method_46426() + field.method_25368() - 2, field.method_46427() + field.method_25364() - 1);
      customContext.drawText(textFont, displayText, textX, textY, empty ? Colors.getTextColor().withAlpha(130.0F) : Colors.getTextColor());

      if (field.method_25370() && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         int cursor = Math.clamp(field.method_1881(), 0, empty ? 0 : inputText.length());
         String left = empty ? "" : inputText.substring(0, cursor);
         float cursorX = field.method_46426() + field.method_25368() / 2.0F - (empty ? 0.0F : textFont.width(inputText)) / 2.0F + textFont.width(left);
         customContext.drawRect(cursorX + 0.4F, textY + 0.7F, 1.0F, Math.max(6.0F, textFont.height() - 1.4F), Colors.getTextColor().withAlpha(210.0F));
      }

      context.method_44380();
   }

   @Redirect(
      method = "render",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/widget/CyclingButtonWidget;render(Lnet/minecraft/client/gui/DrawContext;IIF)V"
      )
   )
   private void fevervisual$renderCustomCraftableToggle(class_5676<Boolean> button, class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.fevervisual$isCustomInventoryEnabled()) {
         button.method_25394(context, mouseX, mouseY, delta);
         return;
      }

      CustomDrawContext customContext = CustomDrawContext.of(context);
      GuiPanelStyle.drawPanel(customContext, button.method_46426(), button.method_46427(), button.method_25368(), button.method_25364(), 5.0F, 0.98F);

      Font labelFont = Fonts.SEMIBOLD.getFont(6.7F);
      String label = button.method_32603() ? "\u041A\u0440" : "\u0412\u0441\u0435";
      float textX = button.method_46426() + button.method_25368() / 2.0F - labelFont.width(label) / 2.0F;
      float textY = button.method_46427() + button.method_25364() / 2.0F - labelFont.height() / 2.0F + 0.5F;
      customContext.drawText(labelFont, label, textX, textY, Colors.getTextColor());

      if (button.method_32603()) {
         customContext.drawRoundedRect(
            button.method_46426() + button.method_25368() - 5.0F,
            button.method_46427() + 2.0F,
            2.5F,
            2.5F,
            BorderRadius.all(1.25F),
            Colors.getAccentColor().withAlpha(230.0F)
         );
      }
   }

   @Unique
   private boolean fevervisual$isCustomInventoryEnabled() {
      if (FeverVisual.getInstance().getModuleManager() == null) {
         return false;
      }

      CustomInv module = FeverVisual.getInstance().getModuleManager().getModuleSafe(CustomInv.class);
      return module != null && module.isEnabled();
   }
}
