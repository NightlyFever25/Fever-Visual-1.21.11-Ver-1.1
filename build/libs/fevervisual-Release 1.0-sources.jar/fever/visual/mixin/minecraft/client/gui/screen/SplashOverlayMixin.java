package fever.visual.mixin.minecraft.client.gui.screen;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import fever.visual.FeverVisual;
import fever.visual.framework.base.UIContext;
import fever.visual.utility.animation.base.Animation;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.interfaces.IScaledResolution;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_425.class)
public class SplashOverlayMixin implements IScaledResolution, IMinecraft {
   @Unique
   private Animation fadeOutAnimation;
   @Shadow
   private long reloadCompleteTime = -1L;
   @Final
   @Shadow
   private Consumer<Optional<Throwable>> exceptionHandler;
   @Shadow
   @Final
   private class_4011 reload;
   @Shadow
   @Final
   private boolean reloading;
   @Shadow
   private long reloadStartTime;

   @Inject(method = "<init>", at = @At("RETURN"))
   public void init(class_310 client, class_4011 monitor, Consumer<Optional<Throwable>> exceptionHandler, boolean reloading, CallbackInfo ci) {
   }

   @Inject(method = "render", at = @At("HEAD"), cancellable = true)
   private void replaceRendering(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (!FeverVisual.getInstance().isSafeMode()) {
         ci.cancel();
         int width = context.method_51421();
         int height = context.method_51443();
         UIContext uiContext = UIContext.of(context, 0, 0, delta);
         long currentTime = class_156.method_658();
         if (this.reloading && this.reloadStartTime == -1L) {
            this.reloadStartTime = currentTime;
         }

         float f = this.reloadCompleteTime > -1L ? (float)(currentTime - this.reloadCompleteTime) / 1000.0F : -1.0F;
         float g = this.reloadStartTime > -1L ? (float)(currentTime - this.reloadStartTime) / 500.0F : -1.0F;
         if (f >= 1.0F) {
            if (mc.field_1755 != null) {
               mc.field_1755.method_25394(context, 0, 0, delta);
            }

            int k = class_3532.method_15386((1.0F - class_3532.method_15363(f - 1.0F, 0.0F, 1.0F)) * 255.0F);
            context.method_25294(0, 0, width, height, Colors.BLACK.withAlpha(k).getRGB());
         } else if (this.reloading && mc.field_1755 != null && g < 1.0F) {
            mc.field_1755.method_25394(context, mouseX, mouseY, delta);
            int k = class_3532.method_15384(class_3532.method_15350(g, 0.15, 1.0) * 255.0);
            context.method_25294(0, 0, width, height, Colors.BLACK.withAlpha(k).getRGB());
         }

         if (f < 1.0F) {
            //this.daunGif
            //.set(
            //0.0F,
            //sr.getScaledHeight() / 2.0F - sr.getScaledWidth() / 1920.0F * 1080.0F / 2.0F,
            //sr.getScaledWidth(),
            //sr.getScaledWidth() / 1920.0F * 1080.0F
            //);
            //this.daunGif.setAlpha(1.0F);
            //this.daunGif.render(uiContext);
         }

         if (f >= 2.0F) {
            mc.method_18502(null);
            //this.daunGif.dispose();
         }

         if (this.reloadCompleteTime == -1L && this.reload.method_18787() && (!this.reloading || g >= 2.0F)) {
            try {
               this.reload.method_18849();
               this.exceptionHandler.accept(Optional.empty());
            } catch (Throwable var15) {
               this.exceptionHandler.accept(Optional.of(var15));
            }

            this.reloadCompleteTime = currentTime;
            if (mc.field_1755 != null) {
               mc.field_1755.method_25423(context.method_51421(), context.method_51443());
            }
         }
      }
   }
}
