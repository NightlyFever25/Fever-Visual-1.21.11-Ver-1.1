package fever.visual.mixin.minecraft.client.render.debug;

import net.minecraft.class_12155;
import net.minecraft.class_12178;
import net.minecraft.class_12180;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_12155.class)
public class EntityHitboxDebugRendererMixin {
   private static final int VANILLA_LOOK_VECTOR_COLOR = -16776961;

   @Redirect(
      method = "drawHitbox",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/debug/gizmo/GizmoDrawing;arrow(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;I)Lnet/minecraft/world/debug/gizmo/VisibilityConfigurable;"),
      require = 0
   )
   private class_12178 fevervisual$hideVanillaLookVector(class_243 start, class_243 end, int color) {
      if (color == VANILLA_LOOK_VECTOR_COLOR) {
         return null;
      }

      return class_12180.method_75555(start, end, color);
   }
}
