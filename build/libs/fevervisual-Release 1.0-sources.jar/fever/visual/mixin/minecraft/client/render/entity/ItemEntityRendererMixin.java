package fever.visual.mixin.minecraft.client.render.entity;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.ItemPhysics;
import fever.visual.utility.mixins.ItemEntityRenderStateAddition;
import net.minecraft.class_10039;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public abstract class ItemEntityRendererMixin {
   @Shadow
   @Final
   private class_5819 random;

   @Inject(method = "updateRenderState", at = @At("TAIL"))
   private void fevervisual$captureEntity(class_1542 entity, class_10039 state, float tickProgress, CallbackInfo ci) {
      ((ItemEntityRenderStateAddition)state).fevervisual$setOnGround(entity.method_24828());
   }

   @Inject(method = "render", at = @At("HEAD"), cancellable = true)
   private void fevervisual$renderPhysics(
      class_10039 state,
      class_4587 matrices,
      class_11659 queue,
      class_12075 cameraState,
      CallbackInfo ci
   ) {
      ItemPhysics module = FeverVisual.getInstance().getModuleManager().getModuleSafe(ItemPhysics.class);
      if (module == null || !module.isEnabled() || state.field_55310.method_65606()) {
         return;
      }

      matrices.method_22903();
      class_238 bounds = state.field_55310.method_72173();
      matrices.method_46416(0.0F, -((float)bounds.field_1322) + 0.0625F, 0.0F);
      float rotation = class_1542.method_27314(state.field_53328, state.field_53435);
      if (((ItemEntityRenderStateAddition)state).fevervisual$isOnGround()) {
         matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
      } else {
         matrices.method_22907(class_7833.field_40714.rotationDegrees(rotation * 300.0F));
      }

      class_916.method_72986(matrices, queue, state.field_61820, state, this.random, bounds);
      matrices.method_22909();
      ci.cancel();
   }
}
