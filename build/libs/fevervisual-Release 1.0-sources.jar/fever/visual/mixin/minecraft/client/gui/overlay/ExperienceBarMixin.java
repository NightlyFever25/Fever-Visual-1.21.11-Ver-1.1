package fever.visual.mixin.minecraft.client.gui.overlay;

import fever.visual.ui.hud.impl.Hotbar;
import net.minecraft.class_11224;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_11224.class)
public class ExperienceBarMixin {
   @Inject(method = "renderBar", at = @At("HEAD"), cancellable = true)
   private void fevervisual$suppressExperienceBar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (Hotbar.shouldSuppressVanilla()) {
         ci.cancel();
      }
   }
}
