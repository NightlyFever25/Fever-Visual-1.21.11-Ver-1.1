package fever.visual.mixin.minecraft.client.render;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.NoRender;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import fever.visual.systems.modules.modules.other.Optimization;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_702.class)
public abstract class ParticleManagerMixin {
   @Inject(method = "addParticle", at = @At("HEAD"), cancellable = true)
   private void onAddParticle(
      class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<class_703> cir
   ) {
      NoRender NoRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
      if (NoRender.isEnabled() && NoRender.getWeather().isSelected() && parameters.method_10295() == class_2398.field_11242) {
         cir.cancel();
         return;
      }

      Optimization optimization = Optimization.getInstanceSafe();
      if (optimization != null && optimization.shouldSkipParticle(parameters, x, y, z)) {
         cir.cancel();
      }
   }
}
