package fever.visual.mixin.minecraft.client.render.entity.emotions;

import fever.visual.systems.modules.modules.visuals.emotions.EmotionPlayback;
import fever.visual.systems.modules.modules.visuals.emotions.EmotionStateHolder;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class AvatarRendererEmotionMixin {
   @Inject(method = "updateRenderState", at = @At("TAIL"), require = 0)
   private void fevervisual$extractEmotion(class_11890 entity, class_10055 state, float tickDelta, CallbackInfo ci) {
      EmotionPlayback.fill((EmotionStateHolder)state, (class_1297)entity);
   }
}
