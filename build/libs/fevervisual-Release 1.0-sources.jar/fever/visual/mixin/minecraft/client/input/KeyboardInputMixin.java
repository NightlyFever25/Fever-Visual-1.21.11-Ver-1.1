package fever.visual.mixin.minecraft.client.input;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.player.InputEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_743.class)
public abstract class KeyboardInputMixin {
   @Inject(method = "tick", at = @At("TAIL"))
   private void onTick(CallbackInfo ci) {
      class_744 input = (class_744) (Object) this;
      InputAccessor accessor = (InputAccessor) input;
      class_10185 keys = accessor.getInput();
      float movementForward = accessor.getMovementVector().field_1342;
      float movementSideways = accessor.getMovementVector().field_1343;
      boolean jumping = accessor.getInput().comp_3163();
      boolean sneaking = accessor.getInput().comp_3164();
      boolean sprint = accessor.getInput().comp_3165();
      InputEvent event = new InputEvent(movementForward, movementSideways, jumping, sneaking, sprint);
      FeverVisual.getInstance().getEventManager().triggerEvent(event);
      accessor.setMovementVector(new class_241(event.getStrafe(), event.getForward()));
      boolean forwardKey = event.getForward() > 0.0F;
      boolean backwardKey = event.getForward() < 0.0F;
      boolean leftKey = event.getStrafe() > 0.0F;
      boolean rightKey = event.getStrafe() < 0.0F;
      accessor.setInput(new class_10185(forwardKey, backwardKey, leftKey, rightKey, event.isJump(), event.isSneak(),
            event.isSprint()));
   }
}
