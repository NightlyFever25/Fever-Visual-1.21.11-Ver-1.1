package fever.visual.mixin.minecraft.client.gui.screen;

import fever.visual.systems.modules.modules.visuals.CustomButtons;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenMixin {
   @Inject(method = "applyBlur", at = @At("HEAD"), cancellable = true)
   private void fevervisual$disableVanillaBlurForCustomButtons(class_332 context, CallbackInfo ci) {
      if (CustomButtons.isEnabledSafe() && CustomButtons.shouldStyleCurrentButtonScreen()) {
         ci.cancel();
      }
   }
}
