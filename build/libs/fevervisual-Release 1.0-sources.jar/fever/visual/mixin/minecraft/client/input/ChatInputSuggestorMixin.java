package fever.visual.mixin.minecraft.client.input;

import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_4717;
import net.minecraft.class_4717.class_464;
import net.minecraft.class_5481;
import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.CustomChat;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4717.class)
public abstract class ChatInputSuggestorMixin {
   @Shadow
   @Final
   class_342 textField;
   @Shadow
   @Final
   private class_437 owner;
   @Shadow
   @Final
   private class_327 textRenderer;
   @Shadow
   @Final
   private boolean chatScreenSized;
   @Shadow
   @Final
   private List<class_5481> messages;
   @Shadow
   private int x;
   @Shadow
   private int width;
   @Shadow
   private CompletableFuture<Suggestions> pendingSuggestions;
   @Shadow
   @Nullable
   private class_464 window;

   @Shadow
   public abstract void show(boolean var1);

   @Inject(method = "renderMessages", at = @At("HEAD"), cancellable = true)
   private void fevervisual$renderCustomCommandMessages(class_332 context, CallbackInfo ci) {
      if (CustomChat.renderCommandSuggestionMessages(context, this.textRenderer, this.messages, this.x, this.width, this.chatScreenSized, this.owner.field_22790)) {
         ci.cancel();
      }
   }

   @Inject(method = "refresh", at = @At(value = "INVOKE", target = "Lcom/mojang/brigadier/StringReader;canRead()Z", remap = false), cancellable = true)
   private void injectAutoCompletion(CallbackInfo ci) {
      String text = this.textField.method_1882();
      String prefix = FeverVisual.getInstance().getCommandManager().getPrefix();
      if (text.startsWith(prefix)) {
         this.pendingSuggestions = FeverVisual.getInstance().getCommandManager().autoComplete(text, this.textField.method_1881());
         this.pendingSuggestions.thenRun(() -> {
            try {
               if (this.pendingSuggestions.isDone() && !this.pendingSuggestions.get().isEmpty() && this.window == null) {
                  this.show(false);
                  ci.cancel();
               }
            } catch (ExecutionException | InterruptedException var3x) {
            }
         });
      }
   }
}
