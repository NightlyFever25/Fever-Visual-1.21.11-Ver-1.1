package fever.visual.mixin.minecraft.client.render.entity.emotions;

import fever.visual.systems.modules.modules.visuals.emotions.EmotionPlayback;
import fever.visual.systems.modules.modules.visuals.emotions.EmotionStateHolder;
import net.minecraft.class_10034;
import net.minecraft.class_10055;
import net.minecraft.class_572;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class HumanoidModelEmotionMixin {
   @Inject(method = "setAngles", at = @At("TAIL"), require = 0)
   private void fevervisual$applyEmotion(class_10034 state, CallbackInfo ci) {
      if (state instanceof class_10055) {
         EmotionPlayback.applyTo((class_572<?>)(Object)this, (EmotionStateHolder)state, state.field_53451);
      }
   }
}
