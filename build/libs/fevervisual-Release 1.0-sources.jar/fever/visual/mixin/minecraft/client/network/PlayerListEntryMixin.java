package fever.visual.mixin.minecraft.client.network;

import com.mojang.authlib.GameProfile;
import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.Cape;
import net.minecraft.class_12079;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_640.class)
public abstract class PlayerListEntryMixin {

    @Shadow
    @Final
    private GameProfile profile;

    @Unique
    private static Cape getCapeModule() {
        try {
            if (FeverVisual.getInstance() == null || FeverVisual.getInstance().getModuleManager() == null) {
                return null;
            }
            return FeverVisual.getInstance().getModuleManager().getModule(Cape.class);
        } catch (Exception e) {
            return null;
        }
    }

    @Unique
    private class_1657 getPlayerByName(String playerName) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return null;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player.method_5477().getString().equals(playerName)) {
                return player;
            }
        }
        return null;
    }

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void onGetSkinTextures(CallbackInfoReturnable<class_8685> cir) {
        try {
            Cape capeModule = getCapeModule();
            if (capeModule == null || !capeModule.isEnabled()) {
                return;
            }

            class_310 mc = class_310.method_1551();
            String playerName = profile.name();

            class_1657 player = getPlayerByName(playerName);
            if (player == null) return;
            if (!capeModule.shouldRenderForPlayer(player)) {
                return;
            }

            class_8685 original = cir.getReturnValue();
            if (original != null) {
                class_12079.class_12081 cape = new class_12079.class_10726(
                        capeModule.getCapeTexture(),
                        capeModule.getCapeTexture()
                );
                class_8685 modified = new class_8685(
                        original.comp_1626(),
                        cape,
                        cape,
                        original.comp_1629(),
                        original.comp_1630()
                );
                cir.setReturnValue(modified);
            }
        } catch (Exception e) {

        }
    }
}
