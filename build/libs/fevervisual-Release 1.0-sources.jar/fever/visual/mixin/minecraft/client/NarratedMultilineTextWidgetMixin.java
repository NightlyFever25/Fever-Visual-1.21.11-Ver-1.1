package fever.visual.mixin.minecraft.client;

import fever.visual.framework.base.CustomDrawContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.systems.modules.modules.visuals.CustomButtons;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_332;
import net.minecraft.class_8019;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8019.class)
public class NarratedMultilineTextWidgetMixin implements IMinecraft {
   @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
   private void fevervisual$renderCustomSettingsMultilineTextWidget(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      class_8019 widget = (class_8019) (Object) this;
      if (!CustomButtons.isEnabledSafe() || !CustomButtons.shouldStyleCurrentSettingsScreen() || !widget.field_22764) {
         return;
      }

      String text = widget.method_25369().getString();
      if (text.isEmpty()) {
         ci.cancel();
         return;
      }

      CustomDrawContext customContext = CustomDrawContext.of(context);
      Font font = Fonts.MEDIUM.getFont(9.0F);
      float x = this.fevervisual$getCenteredTextX(widget, font, text);
      float y = widget.method_46427() + widget.method_25364() / 2.0F - font.height() / 2.0F;

      customContext.drawText(font, text, x, y, Colors.getTextColor());
      ci.cancel();
   }

   @Unique
   private float fevervisual$getCenteredTextX(class_8019 widget, Font font, String text) {
      return widget.method_46426() + widget.method_25368() / 2.0F - font.width(text) / 2.0F;
   }
}
