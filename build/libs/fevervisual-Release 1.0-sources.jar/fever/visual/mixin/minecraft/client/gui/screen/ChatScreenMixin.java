package fever.visual.mixin.minecraft.client.gui.screen;

import fever.visual.FeverVisual;
import fever.visual.framework.base.CustomDrawContext;
import fever.visual.systems.event.impl.render.ChatRenderEvent;
import fever.visual.systems.event.impl.window.ChatClickEvent;
import fever.visual.systems.modules.modules.visuals.CustomChat;
import fever.visual.utility.game.PlatformUtility;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public class ChatScreenMixin extends class_437 implements IMinecraft {
   @Shadow
   protected class_342 chatField;
   @Shadow
   private class_4717 chatInputSuggestor;

   protected ChatScreenMixin(class_2561 title) {
      super(title);
   }

   @Inject(method = "render", at = @At("HEAD"))
   private void fevervisual$beginCustomChatInputRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      PlatformUtility.markChatEditorOpen();
      CustomChat.beginChatScreenRender();
   }

   @Inject(method = "removed", at = @At("HEAD"))
   private void fevervisual$closeVanillaHudSettingsOnRemoved(CallbackInfo ci) {
      FeverVisual.getInstance().getHud().closeFloatingControlsForVanillaChat();
      PlatformUtility.markChatEditorClosed();
   }

   @Inject(method = "sendMessage(Ljava/lang/String;Z)V", at = @At("HEAD"), cancellable = true)
   private void onSendMessage(String text, boolean addToHistory, CallbackInfo ci) {
      if (FeverVisual.getInstance().handleSafeModeReturn(text)) {
         if (addToHistory) {
            mc.field_1705.method_1743().method_1803(text);
         }

         ci.cancel();
         return;
      }

      if (FeverVisual.getInstance().getCommandManager().dispatch(text)) {
         mc.field_1705.method_1743().method_1803(text);
         ci.cancel();
      }
   }

   @Inject(method = "render", at = @At("RETURN"))
   public void render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      context.method_71048();
      FeverVisual.getInstance().getEventManager().triggerEvent(
              new ChatRenderEvent(CustomDrawContext.isolated(context), delta)
      );
      CustomChat.renderScrollbar(context);
      CustomChat.endChatScreenRender();
   }

   @Inject(
      method = "render",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"),
      require = 0
   )
   private void fevervisual$drawCustomChatInputBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.chatField != null) {
         CustomChat.renderInputBackground(
            context,
            this.chatField.method_46426() - 4,
            this.chatField.method_46427() - 4,
            this.chatField.method_46426() + this.chatField.method_25368() + 4,
            this.chatField.method_46427() + this.chatField.method_25364() + 4
         );
      }
   }

   @ModifyArg(
      method = "render",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"),
      index = 4,
      require = 0
   )
   private int fevervisual$hideVanillaChatInputBackground(int color) {
      return CustomChat.isActive() ? 0 : color;
   }

   @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
   private void onMouseClick(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
      if (CustomChat.handleScrollbarClick(click.comp_4798(), click.comp_4799(), click.method_74245())) {
         cir.setReturnValue(true);
         return;
      }

      ChatClickEvent event = new ChatClickEvent((float)click.comp_4798(), (float)click.comp_4799(), click.method_74245());
      FeverVisual.getInstance().getEventManager().triggerEvent(event);
      if (event.isHandled()) {
         cir.setReturnValue(true);
      }
   }

}
