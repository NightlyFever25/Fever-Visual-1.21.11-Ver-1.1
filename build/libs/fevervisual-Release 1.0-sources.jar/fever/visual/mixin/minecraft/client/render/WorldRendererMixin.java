package fever.visual.mixin.minecraft.client.render;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import fever.visual.FeverVisual;
import fever.visual.systems.event.RenderedEntityTracker;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.modules.visuals.GlowEsp;
import net.minecraft.class_10209;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {
   @Inject(method = "render", at = @At("HEAD"), require = 0)
   private void fevervisual$beginEntityVisibilityFrame(
      class_9922 allocator,
      class_9779 tickCounter,
      boolean renderBlockOutline,
      class_4184 camera,
      Matrix4f positionMatrix,
      Matrix4f projectionMatrix,
      Matrix4f frustumMatrix,
      GpuBufferSlice fog,
      org.joml.Vector4f fogColor,
      boolean renderSky,
      CallbackInfo ci
   ) {
      GlowEsp.prepareFrame(tickCounter.method_60637(false));
      RenderedEntityTracker.beginFrame();
   }

   @Inject(method = "render", at = @At("RETURN"), require = 0)
   private void fevervisual$renderWorld(
      class_9922 allocator,
      class_9779 tickCounter,
      boolean renderBlockOutline,
      class_4184 camera,
      Matrix4f positionMatrix,
      Matrix4f projectionMatrix,
      Matrix4f frustumMatrix,
      GpuBufferSlice fog,
      org.joml.Vector4f fogColor,
      boolean renderSky,
      CallbackInfo ci
   ) {
      if (FeverVisual.mc.field_1687 == null || FeverVisual.mc.field_1724 == null) {
         return;
      }

      class_10209.method_64146().method_15405(FeverVisual.MOD_ID + "_renderWorld");
      class_4587 matrices = new class_4587();
      matrices.method_34425(positionMatrix);
      FeverVisual.getInstance().getEventManager().triggerEvent(new Render3DEvent(
         matrices,
         new Matrix4f(positionMatrix),
         new Matrix4f(projectionMatrix),
         camera,
         tickCounter.method_60637(true)
      ));
   }
}
