package fever.visual.mixin.minecraft.client.gui.screen;

import fever.visual.FeverVisual;
import fever.visual.framework.base.CustomDrawContext;
import fever.visual.framework.objects.BorderRadius;
import fever.visual.mixin.accessors.HandledScreenAccessor;
import fever.visual.systems.event.impl.render.ScreenRenderEvent;
import fever.visual.systems.event.impl.window.ContainerClickEvent;
import fever.visual.systems.event.impl.window.ContainerReleaseEvent;
import fever.visual.systems.modules.modules.player.ItemScroller;
import fever.visual.systems.modules.modules.visuals.CustomInv;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.time.Timer;
import net.minecraft.class_11909;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class HandledScreenMixin implements IMinecraft {
   @Unique
   private final Timer timer = new Timer();

   @Shadow
   protected abstract boolean isPointOverSlot(class_1735 var1, double var2, double var4);

   @Shadow
   protected abstract void onMouseClick(class_1735 var1, int var2, int var3, class_1713 var4);

   @Unique
   private float fevervisual$lastDelta = 0.0F;

   @Inject(method = "render", at = @At("HEAD"))
   private void fevervisual$captureDelta(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      this.fevervisual$lastDelta = delta;
   }

   @Inject(method = "drawForeground", at = @At("TAIL"))
   private void onRender(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
      if (mc.field_1724 == null) {
         return;
      }

      CustomDrawContext customDrawContext = CustomDrawContext.of(context);
      FeverVisual.getInstance().getEventManager().triggerEvent(new ScreenRenderEvent(customDrawContext, this.fevervisual$lastDelta));

      if (this.fevervisual$shouldDrawSlotGuides()) {
         this.fevervisual$drawSlotGuides(customDrawContext);
      }

      ItemScroller itemScroller = FeverVisual.getInstance().getModuleManager().getModule(ItemScroller.class);
      if (itemScroller == null || !itemScroller.isEnabled()) {
         return;
      }

      for (class_1735 slot : mc.field_1724.field_7512.field_7761) {
         if (this.isPointOverSlot(slot, mouseX, mouseY)
                 && slot.method_7682()
                 && this.timer.finished((long)itemScroller.getScrollDelay().getCurrentValue())
                 && class_3675.method_15987(mc.method_22683(), 340)
                 && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 0) == 1) {
            this.onMouseClick(slot, slot.field_7874, 0, class_1713.field_7794);
            this.timer.reset();
         }
      }
   }

   @Inject(method = "mouseClicked", at = @At("HEAD"))
   private void onMouseClick(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
      FeverVisual.getInstance().getEventManager().triggerEvent(new ContainerClickEvent((float)click.comp_4798(), (float)click.comp_4799(), click.method_74245()));
   }

   @Inject(method = "mouseReleased", at = @At("HEAD"))
   public void mouseReleased(class_11909 click, CallbackInfoReturnable<Boolean> cir) {
      FeverVisual.getInstance().getEventManager().triggerEvent(new ContainerReleaseEvent((float)click.comp_4798(), (float)click.comp_4799(), click.method_74245()));
   }

   @Unique
   private boolean fevervisual$shouldDrawSlotGuides() {
      if (!(mc.field_1755 instanceof class_465<?> handledScreen)) {
         return false;
      }

      if (handledScreen instanceof class_490 || handledScreen instanceof class_481) {
         return false;
      }

      if (FeverVisual.getInstance().getModuleManager() == null) {
         return false;
      }

      CustomInv customInv = FeverVisual.getInstance().getModuleManager().getModuleSafe(CustomInv.class);
      return customInv != null && customInv.isEnabled();
   }

   @Unique
   private void fevervisual$drawSlotGuides(CustomDrawContext context) {
      if (!((Object)this instanceof class_465<?> handledScreen) || mc.field_1724 == null) {
         return;
      }

      HandledScreenAccessor accessor = (HandledScreenAccessor) handledScreen;
      final float borderThickness = 0.8F;
      final float innerInset = 2.5F;
      final float innerSize = 18.0F - innerInset * 2.0F;

      for (class_1735 slot : mc.field_1724.field_7512.field_7761) {
         if (!slot.method_7682()) {
            continue;
         }

         if (slot.field_7873 <= -1000 || slot.field_7872 <= -1000) {
            continue;
         }

         float slotX = accessor.getX() + slot.field_7873;
         float slotY = accessor.getY() + slot.field_7872;

         context.drawRoundedBorder(
                 slotX + 0.5F,
                 slotY + 0.5F,
                 15.0F,
                 15.0F,
                 borderThickness,
                 BorderRadius.all(3.0F),
                 Colors.getTextColor().withAlpha(42.0F)
         );
         context.drawRoundedRect(
                 slotX + innerInset,
                 slotY + innerInset,
                 innerSize,
                 innerSize,
                 BorderRadius.all(2.0F),
                 Colors.getTextColor().withAlpha(9.0F)
         );
      }
   }
}
