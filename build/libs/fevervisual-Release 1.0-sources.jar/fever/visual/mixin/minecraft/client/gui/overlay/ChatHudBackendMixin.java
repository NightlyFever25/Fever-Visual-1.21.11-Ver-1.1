package fever.visual.mixin.minecraft.client.gui.overlay;

import fever.visual.systems.modules.modules.visuals.CustomChat;
import fever.visual.utility.interfaces.ChatHudBackendContext;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = {
   "net.minecraft.client.gui.hud.ChatHud$Hud",
   "net.minecraft.client.gui.hud.ChatHud$Interactable"
})
public class ChatHudBackendMixin {
   @Redirect(method = "fill", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"))
   private void fevervisual$drawCustomChatBackground(class_332 context, int x1, int y1, int x2, int y2, int color) {
      if (!CustomChat.renderMessageBackground(context, x1, y1, x2, y2, color)) {
         context.method_25294(x1, y1, x2, y2, color);
      }
   }

   @Inject(method = "text", at = @At("HEAD"), cancellable = true)
   private void fevervisual$drawCustomChatText(int y, float opacity, class_5481 text, CallbackInfoReturnable<Boolean> cir) {
      class_332 context = ((ChatHudBackendContext)(Object)this).fevervisual$getContext();
      if (CustomChat.renderChatText(context, y, opacity, text)) {
         cir.setReturnValue(false);
      }
   }
}
