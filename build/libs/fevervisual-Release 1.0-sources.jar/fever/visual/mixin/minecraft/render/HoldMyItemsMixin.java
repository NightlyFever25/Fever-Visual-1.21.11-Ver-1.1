package fever.visual.mixin.minecraft.render;

import com.holdmylua.source.LuaTestHMI;
import com.holdmylua.source.access.ItemStackAccessor;
import com.holdmylua.source.access.LivingEntityAccessor;
import com.holdmylua.source.global.DispatcherStorage;
import com.holdmylua.source.global.GlobalsStorage;
import com.holdmylua.source.global.item_model.ItemModelContext;
import com.holdmylua.source.global.item_model.ItemModelStorage;
import com.holdmylua.source.lua_runtime.LuaScriptCache;
import com.holdmylua.source.lua_runtime.ScriptHolder;
import com.holdmylua.source.patricles.Particle;
import com.holdmylua.source.patricles.ParticleRenderManager;
import fever.visual.systems.modules.modules.visuals.HoldMyItems;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.block.*;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1828;
import net.minecraft.class_1839;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2286;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2459;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3922;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_5134;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_765;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import com.hmi.HandMyItemsRuntime;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import javax.script.ScriptException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Mixin({class_759.class})
public abstract class HoldMyItemsMixin {
   @Unique private boolean repPower = false;
   @Unique private float prevAge = 0.0F;
   @Unique private double previousRotation = 0.0D;
   @Unique private float swingAngleY = 0.0F;
   @Unique private float swingAngleX = 0.0F;
   @Unique private float swingVelocityY = 0.0F;
   @Unique private float swingVelocityX = 0.0F;
   @Unique private float swingVelocityZ = 0.0F;
   @Unique private static final float GRAVITY = 0.1F;
   @Unique private static final float DAMPING = 0.88F;
   @Unique private static final float SENSITIVITY = 0.015F;
   @Unique private float vertAngleY = 0.0F;
   @Unique private float vertVelocityY = 0.0F;
   @Unique private float vertVelocityYSlime = 0.0F;
   @Unique private float vertAngleYSlime = 0.0F;
   @Unique private float riptideCounter = 0.0F;
   @Unique private float netherCounter = 0.0F;
   @Shadow private class_1799 offHand;
   @Shadow @Final private class_310 client;
   @Unique private float fallCounter = 0.0F;
   @Unique private float inWaterCounter = 0.0F;
   @Unique private float inspect = 0.0F;
   @Unique private float tilt = 0.0F;
   @Unique private float freezeCounter = 0.0F;
   @Unique private float clCount = 0.0F;
   @Unique private float crawlCount = 0.0F;
   @Unique private float directionalCrawlCount = 0.0F;
   @Unique private float climbCount = 0.0F;
   @Unique private float mouseHolding = 1.0F;
   @Unique private boolean isSwinging = false;
   @Unique private float swingProgress = 0.0F;
   @Unique private boolean isForward = false;
   @Unique private boolean isAttacking = false;
   @Unique private boolean left = false;
   @Unique private class_742 feverVisual$lastPlayer;
   @Unique private class_1937 feverVisual$lastWorld;
   @Unique private class_1792 feverVisual$prevMainHand = class_1802.field_8162;
   @Unique private class_1792 feverVisual$prevOffHand = class_1802.field_8162;
   @Unique private boolean feverVisual$mainHandSwitchEvent;
   @Unique private boolean feverVisual$offHandSwitchEvent;
   @Unique private boolean feverVisual$swingMHand;
   @Unique private boolean feverVisual$swingOHand;
   @Unique private float feverVisual$mainHandSwingProgress;
   @Unique private float feverVisual$offHandSwingProgress;
   @Unique private final ArrayList<Particle> feverVisual$hmiParticles = new ArrayList<>();

   @Unique
   private float easeInOutBack(float x) {
      float c1 = 1.70158F;
      float c2 = c1 * 1.525F;
      return (float)((double)x < 0.5D ? Math.pow((double)(2.0F * x), 2.0D) * (double)((c2 + 1.0F) * 2.0F * x - c2) / 2.0D : (Math.pow((double)(2.0F * x - 2.0F), 2.0D) * (double)((c2 + 1.0F) * (x * 2.0F - 2.0F) + c2) + 2.0D) / 2.0D);
   }

   @Unique
   private float getAttackDamage(class_1799 stack) {
      class_9285 modifiers = (class_9285)stack.method_57353().method_58694(class_9334.field_49636);
      if (modifiers == null) {
         return 0.0F;
      } else {
         float totalDamage = 0.0F;
         for(var entry : modifiers.comp_2393()) {
            if (entry.comp_2395().comp_349() == class_5134.field_23721) {
               totalDamage += (float)entry.comp_2396().comp_2449();
            }
         }
         return totalDamage;
      }
   }

   @Unique
   private void altSwing(class_4587 matrices, class_1306 arm, float swingProgress, class_1799 item) {
      class_310 client = class_310.method_1551();
      int i = arm == class_1306.field_6183 ? 1 : -1;
      float f = class_3532.method_15374(swingProgress * 3.14F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0F + f * 0.0F)));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0F));
   }

   @Shadow public abstract void renderItem(class_1309 var1, class_1799 var2, class_811 var3, class_4587 var4, class_11659 var5, int var6);
   @Shadow protected abstract void swingArm(float var1, class_4587 var2, int var3, class_1306 var4);
   @Shadow protected abstract void applyEquipOffset(class_4587 var1, class_1306 var2, float var3);
   @Shadow protected abstract void renderMapInBothHands(class_4587 var1, class_11659 var2, int var3, float var4, float var5, float var6);
   @Shadow protected abstract void renderMapInOneHand(class_4587 var1, class_11659 var2, int var3, float var4, class_1306 var5, float var6, class_1799 var7);
   @Shadow protected abstract void renderArmHoldingItem(class_4587 var1, class_11659 var2, int var3, float var4, float var5, class_1306 var6);
   @Shadow protected abstract void applySwingOffset(class_4587 var1, class_1306 var2, float var3);
   @Invoker("renderFirstPersonItem")
   protected abstract void invokeRenderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 queue, int light);

   @Unique
   private HoldMyItems getConfig() {
      return HoldMyItems.getInstance();
   }

   @Unique
   private void feverVisual$resetAnimationState() {
      this.repPower = false;
      this.prevAge = 0.0F;
      this.previousRotation = 0.0D;
      this.swingAngleY = 0.0F;
      this.swingAngleX = 0.0F;
      this.swingVelocityY = 0.0F;
      this.swingVelocityX = 0.0F;
      this.swingVelocityZ = 0.0F;
      this.vertAngleY = 0.0F;
      this.vertVelocityY = 0.0F;
      this.vertVelocityYSlime = 0.0F;
      this.vertAngleYSlime = 0.0F;
      this.riptideCounter = 0.0F;
      this.netherCounter = 0.0F;
      this.fallCounter = 0.0F;
      this.inWaterCounter = 0.0F;
      this.inspect = 0.0F;
      this.tilt = 0.0F;
      this.freezeCounter = 0.0F;
      this.clCount = 0.0F;
      this.crawlCount = 0.0F;
      this.directionalCrawlCount = 0.0F;
      this.climbCount = 0.0F;
      this.mouseHolding = 1.0F;
      this.isSwinging = false;
      this.swingProgress = 0.0F;
      this.isForward = false;
      this.isAttacking = false;
      this.left = false;
   }

   @Unique
   private void feverVisual$resetIfContextChanged(class_742 player) {
      class_1937 world = player.method_73183();
      if (this.feverVisual$lastPlayer != player || this.feverVisual$lastWorld != world || player.field_6012 < this.prevAge) {
         this.feverVisual$resetAnimationState();
         this.feverVisual$lastPlayer = player;
         this.feverVisual$lastWorld = world;
      }
   }

   @Unique
   private boolean shouldApplyAnimation() {
      var config = getConfig();
      return config != null && config.isEnabled();
   }

   @Unique
   private boolean isWeaponLikeItem(class_1799 item) {
      return item.method_31573(class_3489.field_42611)
              || item.method_31573(class_3489.field_42612)
              || item.method_31573(class_3489.field_42613)
              || item.method_31573(class_3489.field_42614)
              || item.method_31573(class_3489.field_42615)
              || item.method_31574(class_1802.field_49814)
              || item.method_7976() == class_1839.field_8949
              || item.method_7976() == class_1839.field_8951
              || item.method_7976() == class_1839.field_8953
              || item.method_7976() == class_1839.field_8947
              || this.getAttackDamage(item) != 0.0F;
   }

   @Redirect(
           method = {"swingArm"},
           at = @At(
                   value = "INVOKE",
                   target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applySwingOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V"
           )
   )
   private void applySwing(class_759 instance, class_4587 matrices, class_1306 arm, float swingProgress) {
      if (!shouldApplyAnimation()) {
         this.applySwingOffset(matrices, arm, swingProgress);
      }
   }

   @Redirect(
           method = {"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"},
           at = @At(
                   value = "INVOKE",
                   target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"
           )
   )
   private void renderOverhaul(class_759 instance, class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 vertexConsumers, int light) {
      this.feverVisual$resetIfContextChanged(player);

      if (!shouldApplyAnimation()) {
         this.feverVisual$resetAnimationState();
         this.invokeRenderFirstPersonItem(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
         return;
      }

      if (player.method_31550()) {
         this.feverVisual$resetAnimationState();
         this.invokeRenderFirstPersonItem(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
         return;
      }

      var config = getConfig();
      if (config == null) {
         this.feverVisual$resetAnimationState();
         this.invokeRenderFirstPersonItem(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
         return;
      }

      try {
      if (HandMyItemsRuntime.isActive()) {
         try {
            this.feverVisual$renderLuaHmi(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
         } catch (ScriptException | NoSuchMethodException ignored) {
            this.invokeRenderFirstPersonItem(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
         }
         return;
      }
      float yaw = player.method_36454();
      double radians = Math.toRadians((double)yaw);
      double forwardX = -Math.sin(radians);
      double forwardZ = Math.cos(radians);
      class_243 horizontalVelocity = player.method_18798();
      double dotProduct = horizontalVelocity.field_1352 * forwardX + horizontalVelocity.field_1350 * forwardZ;
      double crossProduct = player.method_18798().method_61890().field_1352 * forwardZ - horizontalVelocity.field_1350 * forwardX;
      float al;
      if (player.method_36455() != 0.0F) {
         al = 90.0F / player.method_36455() / 10.0F;
      } else {
         al = 1.0F;
      }

      if (al > 1.0F) {
         al = 1.0F;
      }

      if (al < 0.0F) {
         al = 1.0F;
      }

      boolean bl = hand == class_1268.field_5808;
      class_1306 arm = bl ? player.method_6068() : player.method_6068().method_5928();
      float kj = bl ? 1.0F : -1.0F;
      matrices.method_22903();
      matrices.method_22903();
      matrices.method_22904((double)(config.getViewmodelXOffset() * kj), (double)config.getViewmodelYOffset(), (double)config.getViewmodelZOffset());
      double tt = com.holdmyitems.HoldMyItems.deltaTime * 30.0D;
      float swing_rot = (double)swingProgress < 0.6D ? class_3532.method_15374(class_3532.method_15363(swingProgress, 0.0F, 0.12506F) * 12.56F) : class_3532.method_15374(class_3532.method_15363(swingProgress, 0.62532F, 0.75038F) * 12.56F);
      float swing = class_3532.method_15374(swingProgress * 3.14F);
      swing = this.easeInOutBack(swing);

      if ((item.method_31574(class_1802.field_8287) || item.method_31574(class_1802.field_49098) || item.method_31574(class_1802.field_8803) || item.method_31574(class_1802.field_8449) || item.method_31574(class_1802.field_8543) || item.method_31574(class_1802.field_8634) || item.method_7909() instanceof class_1828 || item.method_7909() instanceof class_1803) && player.method_6079().method_7960() && item.method_7976() != class_1839.field_8951 && !item.method_31574(class_1802.field_8814) && !player.method_5681() && !player.method_20448() && !player.method_6101()) {
         if (player.method_6068() == class_1306.field_6182) {
            bl = !bl;
         }
         float jj = bl ? 1.0F : -1.0F;
         matrices.method_22903();
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-25.0F * jj));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-10.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(25.0F * jj * swing));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F * swing));
         matrices.method_22904((double)(-0.15F * jj), 0.1D, 0.1D);
         matrices.method_22904(0.0D, (double)(-0.55F * swing), (double)(0.4F * swing) * 3.141592653589793D);
         this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, 0.0F, arm.method_5928());
         matrices.method_22909();
      }

      if (this.client.field_1690.field_1886.method_1434() && !this.isAttacking && (double)swingProgress == 0.0D) {
         this.left = !this.left;
      }

      if (!item.method_7960()) {
         if (player.method_6068() == class_1306.field_6182) {
            bl = !bl;
         }
         float ll = bl ? 1.0F : -1.0F;
         if ((this.left || item.method_31573(class_3489.field_42612) || item.method_7976() == class_1839.field_8951 || item.method_7976() == class_1839.field_8949) && !item.method_31573(class_3489.field_42615)) {
            if (!item.method_31573(class_3489.field_42611) && !item.method_31573(class_3489.field_42612)) {
               if (item.method_7976() == class_1839.field_8951) {
                  matrices.method_22904(0.0D, 0.0D, (double)(0.45F * swing_rot));
                  matrices.method_22904((double)(-0.25F * kj) * (double)swing, (double)(-0.35F * swing_rot), (double)(-0.6F * swing));
                  matrices.method_22904(0.0D, (double)(0.1F * swing), 0.0D);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(15.0F * swing_rot * ll));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees(30.0F * swing_rot * ll));
               } else if (item.method_31573(ConventionalItemTags.TOOLS) && item.method_7976() != class_1839.field_8949 && !item.method_31573(class_3489.field_42615)) {
                  matrices.method_22904((double)(0.1F * ll) * (double)swing_rot, (double)(0.1F * swing_rot), (double)(-0.5F * swing));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swing_rot));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees(-20.0F * swing_rot * ll));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
               } else if (item.method_7976() != class_1839.field_8949) {
                  matrices.method_22904((double)(0.1F * ll) * (double)swing_rot, (double)(0.1F * swing_rot), (double)(-0.1F * swing));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swing_rot));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees(-10.0F * swing_rot * ll));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(10.0F * swing * ll));
               } else {
                  matrices.method_22904((double)(0.1F * ll) * (double)swing_rot, (double)(0.1F * swing_rot), (double)(-0.2F * swing));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(-10.0F * swing_rot));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees(-10.0F * swing_rot * ll));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(20.0F * swing));
               }
            } else {
               matrices.method_22904((double)(0.8F * ll) * (double)swing_rot, (double)(0.3F * swing_rot), (double)(-0.5F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(15.0F * swing_rot * ll));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-20.0F * swing_rot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-70.0F * swing_rot * ll));
               if (item.method_31573(class_3489.field_42611)) {
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
               } else {
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(30.0F * swing));
               }
            }
         } else if (!item.method_31573(class_3489.field_42615)) {
            if (item.method_31573(class_3489.field_42611)) {
               matrices.method_22904((double)(-0.55F * ll) * (double)swing_rot, (double)(-0.8F * swing_rot), (double)(-0.77F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(5.0F * swing_rot * ll));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swing_rot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(70.0F * swing_rot * ll));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(50.0F * swing));
            } else if (item.method_31573(ConventionalItemTags.TOOLS) && !item.method_31573(class_3489.field_42615)) {
               matrices.method_22904((double)(0.1F * ll) * (double)swing_rot, (double)(0.1F * swing_rot), (double)(-0.5F * swing));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swing_rot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-20.0F * swing_rot * ll));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
            } else {
               matrices.method_22904((double)(0.1F * ll) * (double)swing_rot, (double)(0.1F * swing_rot), (double)(-0.1F * swing));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swing_rot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-10.0F * swing_rot * ll));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(10.0F * swing * ll));
            }
         } else if (item.method_31573(class_3489.field_42615)) {
            matrices.method_22904(0.0D, (double)(0.15F * swing_rot), (double)(-0.25F * swing_rot));
            matrices.method_22904(0.0D, 0.0D, (double)(-0.2F * swing));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(15.0F * swing_rot));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-35.0F * swing_rot));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F * swing));
         }
      } else if (class_2248.method_9503(item.method_7909()) != class_2246.field_10124 && (!item.method_31573(ConventionalItemTags.TOOLS) || item.method_31573(class_3489.field_41890) || item.method_31573(class_3489.field_40109) || item.method_7976() == class_1839.field_8950 || !item.method_7923()) && item.method_7976() != class_1839.field_8953 && item.method_7976() != class_1839.field_27079 && this.getAttackDamage(item) == 0.0F && item.method_7976() != class_1839.field_8949 && !item.method_31574(class_1802.field_23254) && !item.method_31574(class_1802.field_8184) && !item.method_31574(class_1802.field_8378) && !item.method_31574(class_1802.field_8868)) {
         swingProgress = (float)((double)swingProgress * 1.2D);
         if (swingProgress > 1.0F) {
            swingProgress = 0.0F;
         }
      } else if (!item.method_31573(class_3489.field_42615)) {
         swingProgress = (float)((double)swingProgress * 1.5D);
         if (swingProgress > 1.0F) {
            swingProgress = 0.0F;
         }
      }

      if (player.method_18798().method_1033() >= 0.08D) {
         this.crawlCount = (float)((double)this.crawlCount + 0.1D * player.method_18798().method_1033() * 2.0D * tt);
         this.directionalCrawlCount = (float)((double)this.directionalCrawlCount + 0.1D * dotProduct * 4.0D * tt);
         this.directionalCrawlCount = (float)((double)this.directionalCrawlCount + (dotProduct > 0.0D ? 0.1D * Math.abs(crossProduct) * 4.0D * tt : 0.1D * Math.abs(crossProduct) * -1.0D * 4.0D * tt));
      }

      if (player.method_18798().method_10214() > 0.0D) {
         this.climbCount = (float)((double)this.climbCount + 0.1D * tt);
      }
      if (player.method_18798().method_10214() < 0.0D) {
         this.climbCount = (float)((double)this.climbCount - 0.1D * tt);
      }

      if ((player.method_20448() && config.isClimbAndCrawl() || player.method_6101() && !player.method_24828() && Math.abs(player.method_18798().method_10214()) > 0.0D && config.isClimbAndCrawl()) && !player.method_6115() && swingProgress == 0.0F) {
         this.clCount = (float)((double)this.clCount + 0.1D * tt);
         if (this.clCount > 1.0F) {
            this.clCount = 1.0F;
         }
         if (!item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016)) {
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-20.0F * this.clCount));
         }
      } else {
         this.clCount = (float)((double)this.clCount * Math.pow(0.88D, tt));
      }

      if (swingProgress == 0.0F) {
         matrices.method_22904(bl ? (double)(player.method_36455() / 650.0F * this.clCount * -1.0F) : (double)(player.method_36455() / 650.0F * this.clCount), 0.0D, 0.0D);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(player.method_36455() * this.clCount));
      }

      if (!item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016)) {
         matrices.method_22904(0.0F, 0.0F, (double)(player.method_36455() / 120.0F * this.clCount));
      } else if (swingProgress == 0.0F) {
         matrices.method_22904(0.0F, 0.0F, (double)(player.method_36455() / 80.0F * this.clCount));
      }

      if (player.method_6101() && config.isClimbAndCrawl() && !player.method_24828() && !item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016) && !player.method_6115()) {
         matrices.method_22904(0.0D, 0.1D, -0.2D);
      }

      if ((player.method_52535() || player.field_27857) && !player.method_5681() && !player.method_5869()) {
         this.inWaterCounter = (float)((double)this.inWaterCounter + 0.1D * tt);
         if (this.inWaterCounter >= 1.0F) {
            this.inWaterCounter = 1.0F;
         }
      } else {
         this.inWaterCounter = (float)((double)this.inWaterCounter * Math.pow(0.88D, tt));
      }

      if (player.field_27857 && (double)player.method_32313() > 0.1D) {
         this.freezeCounter = (float)((double)this.freezeCounter + 0.1D * tt);
      } else {
         this.freezeCounter = (float)((double)this.freezeCounter * Math.pow(0.88D, tt));
      }

      matrices.method_22904(0.0D, (double)(0.02F * this.inWaterCounter), 0.0D);
      matrices.method_22907(class_7833.field_40718.rotationDegrees(8.0F * kj * this.inWaterCounter));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(0.3F * class_3532.method_15374(this.freezeCounter * 5.0F)));

      if (player.method_18798().method_10214() < -0.85D && item.method_31574(class_1802.field_49814) && player.method_6047() == item) {
         this.fallCounter = (float)((double)this.fallCounter + 0.1D * tt);
         if (this.fallCounter >= 1.0F) {
            this.fallCounter = 1.0F;
         }
      } else {
         this.fallCounter = (float)((double)this.fallCounter * Math.pow(0.88D, tt));
      }

      if (bl) {
         matrices.method_22907(class_7833.field_40714.rotationDegrees(45.0F * this.fallCounter));
         matrices.method_22904(0.0D, (double)(-0.2F * this.fallCounter), 0.0D);
      }

      this.vertAngleY = (float)((double)this.vertAngleY + player.method_18798().method_10214() * 0.015D * tt);
      this.vertAngleY = (float)((double)this.vertAngleY - (double)(0.1F * this.vertAngleY) * tt);
      this.vertAngleY = (float)((double)this.vertAngleY * Math.pow(0.88D, tt));
      this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime + player.method_18798().method_10214() * 0.015D * tt);
      this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime - (double)(0.1F * this.vertAngleYSlime) * tt);
      this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime * Math.pow(0.88D, tt));
      this.vertAngleYSlime = (float)((double)this.vertAngleYSlime + (double)this.vertVelocityYSlime * tt);
      matrices.method_46416(0.0F, this.vertAngleY * -1.0F, 0.0F);
      matrices.method_22904(0.0D, Math.sin((double)player.field_6012 * 0.1D) * 0.007D * (double)kj, 0.0D);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(0.15F * class_3532.method_15374((float)player.field_6012 * 0.15F) * kj));

      if (!item.method_7960() || player.method_20448() || player.method_6101() && !player.method_24828() || player.method_5681()) {
         if (player.method_6068() == class_1306.field_6182) {
            bl = !bl;
         }
         if (item.method_7976() == class_1839.field_8949) {
            matrices.method_46416(0.0F, 0.0F, 0.0F);
         } else {
            matrices.method_22904(0.0D, -0.1D, 0.1D);
         }
      }

      if (item.method_31574(class_1802.field_16539) || item.method_31574(class_1802.field_22016) || item.method_31573(class_3489.field_40108)) {
         matrices.method_22904(0.0D, 0.1D, 0.0D);
         if (player.method_5681()) {
            matrices.method_22904(0.0D, -0.1D, 0.1D);
         }
      }

      if (player.method_5681() && swingProgress == 0.0F && config.isSwimmingAnimation()) {
         double distance = (double)this.crawlCount;
         double swingAmplitude = 1.5D;
         double frequency = 2.0D;
         double s = distance * frequency;
         double handRotation = Math.sin(s) * swingAmplitude;
         double smoothRotation = handRotation * 0.8D + this.previousRotation * 0.2D;
         matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(bl ? smoothRotation : -smoothRotation)));
         matrices.method_22904(0.0D, 0.0D, smoothRotation * 0.2D);
         double k = (double)(this.crawlCount * 2.0F);
         double a = Math.cos(k);
         double b = a;
         if (a <= 0.0D) {
            b = a * 0.5D;
         }
         matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(bl ? b * 30.0D : b * 30.0D * -1.0D)));
         matrices.method_22904(0.0D, 0.0D, a * 0.2D);
         if (item.method_7960() && !bl && !player.method_5767()) {
            float l = bl ? 1.0F : -1.0F;
            matrices.method_22904((double)(1.0F * l), 0.0D - (double)equipProgress * 0.3D, 0.3D);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * l));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(-40.0F * l));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
            this.altSwing(matrices, arm, swingProgress, item);
            matrices.method_22905(0.9F, 0.9F, 0.9F);
            this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
         }
         this.previousRotation = smoothRotation;
      }

      if ((player.method_6101() && !player.method_24828() || player.method_20448() && swingProgress == 0.0F) && !player.method_6115()) {
         double s = (double)this.climbCount;
         float a = class_3532.method_15362((float)s * 2.0F);
         float leftVal = bl ? 1.0F : -1.0F;
         if (player.method_6101()) {
            if (!item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016)) {
               matrices.method_22907(class_7833.field_40714.rotationDegrees(20.0F * a * leftVal));
            } else {
               matrices.method_22907(class_7833.field_40714.rotationDegrees(1.0F * a * leftVal));
            }
         }
         if (player.method_20448() && !player.method_6115() && swingProgress == 0.0F) {
            float crawlProgress = class_3532.method_15374(this.directionalCrawlCount * 4.0F * this.mouseHolding);
            float upAndDown = class_3532.method_15362(this.directionalCrawlCount * 4.0F * this.mouseHolding);
            if (item.method_31574(class_1802.field_16539) || item.method_31574(class_1802.field_22016)) {
               crawlProgress *= 0.14F;
               upAndDown *= 0.14F;
            }
            matrices.method_22904((double)(0.2F * crawlProgress), (double)(0.3F * crawlProgress) * (double)leftVal, (double)(-0.2F * crawlProgress) * (double)leftVal * (double)al);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(25.0F * crawlProgress));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_15363(20.0F * upAndDown * leftVal, 0.0F, 20.0F)));
         }
         if (item.method_7960() && !bl && !player.method_5767() && (!player.method_24828() && player.method_6101() || player.method_20448())) {
            float l = bl ? 1.0F : -1.0F;
            matrices.method_22904((double)(1.0F * l), 0.0D - (double)equipProgress * 0.3D, 0.3D);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * l));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(-40.0F * l));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
            this.altSwing(matrices, arm, swingProgress, item);
            matrices.method_22905(0.9F, 0.9F, 0.9F);
            this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
         }
      }

      if (item.method_7960()) {
         if (bl && !player.method_5767()) {
            if ((player.method_24828() || !player.method_6101()) && !player.method_5681() && !player.method_20448()) {
               if (player.method_6068() == class_1306.field_6182) {
                  bl = !bl;
               }
               float ll = bl ? 1.0F : -1.0F;
               matrices.method_22904(0.0D, (double)(0.2F * swing_rot), (double)(0.15F * swing_rot));
               matrices.method_22904((double)(0.1F * ll) * (double)swing, (double)(0.15F * swing), (double)(-0.45F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(35.0F * swing * ll));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-30.0F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-10 * swing_rot) * ll));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F * swing_rot));
               this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
            } else {
               float l = bl ? 1.0F : -1.0F;
               matrices.method_22904((double)(1.0F * l), 0.0D - (double)equipProgress * 0.3D, 0.3D);
               matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * l));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-40.0F * l));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
               this.altSwing(matrices, arm, swingProgress, item);
               matrices.method_22905(0.9F, 0.9F, 0.9F);
               this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
            }
         }
      } else if (item.method_57826(class_9334.field_49646)) {
         if (bl && this.offHand.method_7960()) {
            matrices.method_22904(0.0D, 0.1D, 0.0D);
            this.renderMapInBothHands(matrices, vertexConsumers, light, pitch, equipProgress, swingProgress);
         } else {
            matrices.method_22904(bl ? -0.1D : 0.1D, 0.1D, 0.0D);
            this.renderMapInOneHand(matrices, vertexConsumers, light, equipProgress, arm, swingProgress, item);
         }
      } else if (item.method_7976() == class_1839.field_8947) {
         matrices.method_22903();
         boolean bl2 = class_1764.method_7781(item);
         boolean bl3 = arm == class_1306.field_6183;
         int i = bl3 ? 1 : -1;
         if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
            this.applyEquipOffset(matrices, arm, equipProgress);
            matrices.method_22904((double)((float)i * -0.4785682F), -0.24387D, 0.05731531D);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-11.935F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 65.3F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * 9.785F));
            float f = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
            float g = f / (float)class_1764.method_7775(item, player);
            if (g > 1.0F) { g = 1.0F; }
            if (g > 0.1F) {
               float h = class_3532.method_15374((f - 0.1F) * 1.3F);
               float j = g - 0.1F;
               float k = h * j;
               matrices.method_22904((double)(k * 0.0F), (double)(k * 0.004F), (double)(k * 0.0F));
            }
            matrices.method_22904((double)(g * 0.0F), (double)(g * 0.0F), (double)(g * 0.04F));
            matrices.method_22905(1.0F, 1.0F, 1.0F);
            matrices.method_22907(class_7833.field_40715.rotationDegrees((float)i * 45.0F));
         } else {
            this.swingArm(swingProgress, matrices, i, arm);
            if (bl2 && swingProgress < 0.001F && bl) {
               matrices.method_22904((double)((float)i * -0.341864F), 0.0D, 0.0D);
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 10.0F));
            }
         }
         float l = bl ? 1.0F : -1.0F;
         matrices.method_46416(0.0F, 0.0F, -1.0F);
         matrices.method_22904((double)(-0.45F * (float)i), 0.45D, 1.7D);
         matrices.method_22904((double)(1.0F * l), 0.0D - (double)equipProgress * 0.3D, 0.3D);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * l));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(-40.0F * l));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
         this.altSwing(matrices, arm, swingProgress, item);
         matrices.method_22905(0.9F, 0.9F, 0.9F);
         this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
         matrices.method_22904((double)(-0.25F * (float)i), 1.25D, 0.05D);
         matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-90 * i)));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(77.0F));
         matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(85 * i)));
         matrices.method_22905(1.2F, 1.2F, 1.2F);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-10.0F));
         matrices.method_22904(0.0D, -0.15D, 0.15D);
         this.renderItem(player, item, bl3 ? class_811.field_4322 : class_811.field_4321, matrices, vertexConsumers, light);
         matrices.method_22909();
         if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
            float f = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
            float g = f / (float)class_1764.method_7775(item, player);
            if (g > 1.0F) { g = 1.0F; }
            if (g > 0.1F) {
               float h = class_3532.method_15374((f - 0.1F) * 1.3F);
               float j = g - 0.1F;
               float k = h * j;
               matrices.method_22904((double)(k * 0.0F), (double)(k * 0.004F), (double)(k * 0.0F));
            }
            matrices.method_22907(class_7833.field_40715.rotationDegrees((double)g <= 0.2D ? 75.0F * g * 5.0F * (float)i : (float)(75 * i)));
            matrices.method_22907(class_7833.field_40713.rotationDegrees(10.0F * g * 1.5F));
            matrices.method_22904((double)(-0.37F * (float)i), 0.0D, 0.6D);
            matrices.method_22904((double)(0.15F * g) * (double)i, 0.0D, 0.0D);
            this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, swingProgress, arm.method_5928());
         }
      } else {
         boolean bl2 = arm == class_1306.field_6183;
         int l = bl2 ? 1 : -1;
         if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
            switch (item.method_7976()) {
               case field_8952:
                  this.applyEquipOffset(matrices, arm, equipProgress);
                  break;
               case field_8950:
               case field_8946:
                  float u = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                  float y = u / 5.0F;
                  if (y > 1.0F) { y = 1.0F; }
                  float q = class_3532.method_15374(u / 2.0F * 3.14F);
                  q /= 10.0F;
                  matrices.method_22904((double)(1 * l), 0.1D, 0.3D);
                  matrices.method_22904((double)(0.2F * (float)l) * (double)y, (double)(-0.7F * y), (double)(-0.2F * y));
                  matrices.method_22904(0.0D, (double)(-0.2F * q), (double)(-0.2F * q));
                  matrices.method_22904(0.0D, (double)(0.1F * this.easeInOutBack(class_3532.method_15374(y * 3.14F))), 0.0D);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(45 * l)));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(-40 * l)));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
                  this.altSwing(matrices, arm, swingProgress, item);
                  matrices.method_22905(0.9F, 0.9F, 0.9F);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * y * (float)l));
                  this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, swingProgress, arm);
                  break;
               case field_8949:
                  float k = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                  float s = k / 4.0F;
                  float s2 = k / 6.0F;
                  if (s > 1.0F) { s = 1.0F; }
                  if (s2 > 1.0F) { s2 = 1.0F; }
                  matrices.method_22904(0.0D, -0.2D, 0.0D);
                  matrices.method_22904((double)(1 * l), 0.0D, 0.3D);
                  matrices.method_22904((double)(0.7F * s) * (double)l, 0.0D, (double)(-1.3F * s));
                  matrices.method_22904((double)(-0.2F * (float)l) * (double)s2, 0.0D, 0.0D);
                  matrices.method_22907(class_7833.field_40714.rotationDegrees((float)(10.0F * Math.sin((double)s2 * Math.PI))));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(70.0F * s * (float)l));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(45 * l)));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(-40 * l)));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(5 * l) * s));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-10.0F * s));
                  matrices.method_22904(0.0D, 0.0D, (double)(-0.2F * s));
                  this.altSwing(matrices, arm, swingProgress, item);
                  matrices.method_22905(0.9F, 0.9F, 0.9F);
                  this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, swingProgress, arm);
                  matrices.method_22904((double)(0.35F * (float)l), -0.13D, -0.12D);
                  matrices.method_22907(class_7833.field_40718.rotationDegrees(10.0F * (float)l));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(10.0F * (float)l));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(0.0F));
                  matrices.method_22904((double)(-0.2F * (float)l), -0.04D, 0.15D);
                  matrices.method_22905(1.0F, 1.0F, 1.0F);
                  break;
               case field_8953:
                  matrices.method_22903();
                  if (player.method_6068() == class_1306.field_6182) { bl = !bl; }
                  float m1 = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                  float f1 = m1 / 20.0F;
                  float f = (f1 * f1 + f1 * 2.0F) / 3.0F;
                  if (f1 > 1.0F) { f1 = 1.0F; }
                  if (f1 > 0.1F) {
                     float g1 = class_3532.method_15374((m1 - 0.1F) * 1.3F);
                     float j1 = g1 * f1;
                     matrices.method_22904((double)(j1 * 0.0F), (double)(j1 * 0.004F), (double)(j1 * 0.0F));
                  }
                  matrices.method_22904(bl ? -0.1D : 0.1D, 0.0D, (double)f1 * 0.15D);
                  this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, swingProgress, arm);
                  matrices.method_22909();
                  matrices.method_22904(bl ? -0.5D : 0.5D, -0.45D, 0.1D);
                  matrices.method_22907(class_7833.field_40714.rotation(0.3F));
                  if (bl) {
                     matrices.method_22907(class_7833.field_40717.rotation(-0.3F));
                     matrices.method_22907(class_7833.field_40715.rotation(1.0F));
                  } else {
                     matrices.method_22907(class_7833.field_40718.rotation(-0.3F));
                     matrices.method_22907(class_7833.field_40716.rotation(1.0F));
                  }
                  this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, swingProgress, arm.method_5928());
                  if (bl) {
                     matrices.method_22907(class_7833.field_40715.rotation(2.5F));
                  } else {
                     matrices.method_22907(class_7833.field_40716.rotation(2.5F));
                  }
                  matrices.method_22904(bl ? -0.65D : 0.65D, -0.35D, 0.27D);
                  matrices.method_22909();
                  if (config.isMb3DCompat()) {
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(10 * l)));
                  }
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(75.0F));
                  matrices.method_22907(class_7833.field_40717.rotationDegrees((float)(-15 * l)));
                  matrices.method_22904((double)(0.8F * (float)l), (double)(0.0F - equipProgress * 0.3F), -0.1D);
                  matrices.method_22903();
                  break;
            }
         } else if (player.method_6123() && item.method_7976() == class_1839.field_8951) {
            this.riptideCounter = (float)((double)this.riptideCounter + 0.15D * tt);
            float m = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
            float f = m / 10.0F;
            if (f > 1.0F) { f = 1.0F; }
            if (f > 0.1F) {
               float g = class_3532.method_15374((m - 0.1F) * 1.3F);
               float h = f - 0.1F;
               float j = g * h;
               matrices.method_22904((double)(j * 0.0F), (double)(j * 0.004F), (double)(j * 0.0F));
            }
            matrices.method_22907(class_7833.field_40714.rotationDegrees(45.0F - this.riptideCounter * 2.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(25 * l)));
            matrices.method_22904((double)(0.2F * (float)l), 0.0D, 0.75D);
            matrices.method_22904(0.0D, 0.0D, (double)(0.01F * class_3532.method_15374(this.riptideCounter * 6.28F)));
            this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, swingProgress, arm);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(135.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(-65 * l)));
            matrices.method_22904((double)(0.65F * (float)l), -1.0D, -0.6D);
         } else {
            this.riptideCounter = 0.0F;
            if (!item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016) && !item.method_31573(class_3489.field_40108)) {
               if (item.method_7976() == class_1839.field_8949) {
                  matrices.method_22904(0.0D, -0.2D, 0.0D);
               }
            } else {
               matrices.method_22904((double)(0.1F * (float)l), 0.0D, -0.1D);
               matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F));
            }
            matrices.method_22904((double)(1 * l), 0.0D - (double)equipProgress * 0.3D, 0.3D);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(45 * l)));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(-40 * l)));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
            this.altSwing(matrices, arm, swingProgress, item);
            matrices.method_22905(0.9F, 0.9F, 0.9F);
            this.renderArmHoldingItem(matrices, vertexConsumers, light, 0.0F, 0.0F, arm);
         }
         matrices.method_22904((double)(-0.3F * (float)l), 0.65D, -0.1D);
         matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-65 * l)));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F));
         if (item.method_31573(class_3489.field_15542)) {
            matrices.method_22904((double)(0.2F * (float)l), -0.1D, 0.0D);
         }
         if (class_2248.method_9503(item.method_7909()) != class_2246.field_10124 && item.method_7976() != class_1839.field_8950 && !item.method_31573(ConventionalItemTags.BUCKETS)) {
            if (item.method_7964().toString().toLowerCase().contains("torch")) {
               matrices.method_22905(1.5F, 1.5F, 1.5F);
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(25 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(5.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(75 * l)));
               matrices.method_22904((double)(0.2F * (float)l), 0.2D, 0.05D);
            } else if ((item.method_31574(class_1802.field_8276) || item.method_31574(class_1802.field_8725) || item.method_31574(class_1802.field_8865) || item.method_31574(class_1802.field_8366) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(ConventionalBlockTags.GLASS_PANES) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15463) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_22414) || item.method_31573(class_3489.field_15553)) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15503) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_43170) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15501)) {
               matrices.method_22904(0.0D, 0.0D, -0.1D);
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(5 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(15.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(75 * l)));
            } else if (!item.method_31574(class_1802.field_16539) && !item.method_31574(class_1802.field_22016) && !item.method_31573(class_3489.field_40108)) {
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(25 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(5.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(75 * l)));
               matrices.method_22904((double)(0.2F * (float)l), 0.2D, 0.05D);
               if (class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15501)) {
                  matrices.method_22904((double)(-0.2F * (float)l), 0.0D, 0.0D);
                  matrices.method_22905(1.1F, 1.1F, 1.1F);
               }
            } else {
               float dt = (float)(com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
               float yawDelta = player.field_6259 - player.method_5791();
               float pitchDelta = player.field_6004 - player.method_36455();
               this.swingVelocityY += yawDelta * 0.015F * dt;
               this.swingVelocityY += swingProgress * 2.0F * dt;
               this.swingVelocityX += pitchDelta * 0.015F * dt;
               this.swingVelocityY -= 0.1F * this.swingAngleY * dt;
               this.swingVelocityX -= 0.1F * this.swingAngleX * dt;
               this.swingVelocityY = (float)((double)this.swingVelocityY * Math.pow(0.88D, dt));
               this.swingVelocityX = (float)((double)this.swingVelocityX * Math.pow(0.88D, dt));
               this.swingAngleY += this.swingVelocityY * dt;
               this.swingAngleX += this.swingVelocityX * dt;
               double currentSpeed = player.method_18798().method_1033();
               this.swingVelocityZ = (float)((double)this.swingVelocityZ + (bl ? (currentSpeed * -1.0D * 15.0D - (double)this.swingVelocityZ) * 0.1D * dt : (currentSpeed * 15.0D - (double)this.swingVelocityZ) * 0.1D * dt));
               if ((currentSpeed > 0.09D && player.method_24828() || player.method_5681() || player.method_6101() && !player.method_24828()) && this.client.field_1690.method_42448().method_41753()) {
                  Random random = new Random();
                  boolean randomBoolean = random.nextBoolean();
                  this.swingVelocityY += (float)(randomBoolean ? -5.5D * currentSpeed * dt : 5.5D * currentSpeed * dt);
               }
               matrices.method_22904(0.0D, 0.0D, -0.1D);
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(35 * l) + this.swingAngleY));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(15.0F + this.swingAngleX));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(75 * l) + this.swingVelocityZ));
               if (item.method_31573(class_3489.field_40108)) {
                  matrices.method_22904(0.0D, -0.1D, 0.0D);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-45 * l)));
               }
               matrices.method_22904((double)(0.3F * (float)l), -0.35D, 0.0D);
               matrices.method_22904(0.0D, 0.0D, 0.1D);
               matrices.method_22905(1.5F, 1.5F, 1.5F);
            }
         } else {
            if ((!item.method_31573(ConventionalItemTags.TOOLS) || item.method_31573(class_3489.field_41890) || item.method_31573(class_3489.field_40109) || item.method_7976() == class_1839.field_8950 || !item.method_7923()) && item.method_7976() != class_1839.field_8953 && item.method_7976() != class_1839.field_27079 && !this.isWeaponLikeItem(item) && item.method_7976() != class_1839.field_8949 && !item.method_31574(class_1802.field_23254) && !item.method_31574(class_1802.field_8184) && !item.method_31574(class_1802.field_8378) && !item.method_31574(class_1802.field_8868) && !item.method_31573(class_3489.field_42613) && !config.isMb3DCompat()) {
               if (item.method_7976() == class_1839.field_42717) {
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(25.0F));
                  matrices.method_22904(bl ? 0.0D : 0.35D, bl ? 0.0D : 0.25D, bl ? 0.0D : 0.37D);
                  if (!bl) { matrices.method_22905(0.75F, 0.75F, 0.75F); }
                  matrices.method_22907(class_7833.field_40717.rotationDegrees((float)(-75 * l)));
                  matrices.method_22907(class_7833.field_40713.rotationDegrees(35.0F));
                  matrices.method_22904(bl ? -0.05D : 0.85D, bl ? 0.0D : 0.05D, bl ? 0.08D : -0.2D);
               } else {
                  matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(5 * l)));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(15.0F));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(75 * l)));
                  matrices.method_22904(0.0D, -0.05D, -0.1D);
                  matrices.method_22905(0.7F, 0.7F, 0.7F);
               }
               if (item.method_31574(class_1802.field_8153) || item.method_31574(class_1802.field_8777) || item.method_31574(class_1802.field_8323)) {
                  this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime + (double)swingProgress * 0.03D * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
                  if ((player.method_18798().method_1033() > 0.09D && player.method_24828() || player.method_5681() || player.method_20448() || player.method_6101() && !player.method_24828()) && this.client.field_1690.method_42448().method_41753()) {
                     Random random = new Random();
                     boolean randomBoolean = random.nextBoolean();
                     this.vertVelocityYSlime += (float)(-0.05D * player.method_18798().method_1033() * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
                  }
                  matrices.method_22905(1.0F, 1.0F + this.vertAngleYSlime * -2.0F, 1.0F);
               }
            } else if (item.method_7976() == class_1839.field_8949 && item.method_7976() != class_1839.field_8951) {
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(160 * l)));
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-60 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-70.0F));
               matrices.method_22905(0.75F, 0.75F, 0.75F);
               matrices.method_22904((double)(0.15F * (float)l), bl ? 0.35D : 0.45D, bl ? -0.15D : -0.1D);
               matrices.method_22904((double)(0.17F * (float)l), 0.0D, 0.3D);
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(-90 * l)));
            } else if (item.method_7976() == class_1839.field_8951) {
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(75 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(45 * l)));
               matrices.method_22904((double)(-0.3F * (float)l), 0.0D, 0.0D);
            } else if (item.method_7976() != class_1839.field_8951) {
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)(75 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(70.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(45 * l)));
            }
            if (item.method_7976() != class_1839.field_8949) {
               matrices.method_22905(1.2F, 1.2F, 1.2F);
            }
            if (item.method_7976() == class_1839.field_8953 && !player.method_6115()) {
               matrices.method_22904((double)(-0.1F * (float)l), -0.2D, 0.0D);
            }
            if (item.method_31574(class_1802.field_49814)) {
               if (config.isMb3DCompat()) {
                  matrices.method_22904(-0.08D, 0.17D, 0.0D);
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(40.0F));
               }
               matrices.method_22904((double)(0.1F * (float)l), 0.0D, 0.0D);
               matrices.method_22905(0.9F, 0.9F, 0.9F);
            }
         }
         if (item.method_7909() instanceof class_1747 && (!item.method_31573(ConventionalItemTags.BUCKETS) && item.method_7976() != class_1839.field_8950 && !item.method_31573(class_3489.field_15556) && !item.method_31574(class_1802.field_8276) && !item.method_31574(class_1802.field_8725) && !item.method_31574(class_1802.field_8865) && !item.method_31574(class_1802.field_8366) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(ConventionalBlockTags.GLASS_PANES) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15463) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_22414) && !item.method_31573(class_3489.field_15553) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15503)) && !class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_43170)) {
            class_1747 blockItem = (class_1747)item.method_7909();
            class_776 blockRenderManager = class_310.method_1551().method_1541();
            matrices.method_22903();
            if (!bl2) { matrices.method_46416(-0.4F, 0.0F, 0.0F); }
            matrices.method_22905(0.4F, 0.4F, 0.4F);
            matrices.method_22904((double)(-0.9F * (float)l), -0.45D, -0.5D);
            if (class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15493)) {
               matrices.method_22904((double)(0.2F * (float)l), -0.15D, -0.2D);
            }
            if (class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_24076)) {
               matrices.method_22904(0.0D, 0.1D, 0.0D);
            }
            if (item.method_31574(class_1802.field_8828) || item.method_31574(class_1802.field_21086) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_20339) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15503) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_15462) || class_2248.method_9503(item.method_7909()).method_9564().method_26164(class_3481.field_44469)) {
               this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime + (double)swingProgress * 0.03D * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
               if ((player.method_18798().method_1033() > 0.09D && player.method_24828() || player.method_5681() || player.method_20448() || player.method_6101() && !player.method_24828()) && this.client.field_1690.method_42448().method_41753()) {
                  Random random = new Random();
                  boolean randomBoolean = random.nextBoolean();
                  this.vertVelocityYSlime += (float)(-0.05D * player.method_18798().method_1033() * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
               }
               matrices.method_22905(1.0F, 1.0F + this.vertAngleYSlime * -2.0F, 1.0F);
            }
            class_2680 blockState = blockItem.method_7711().method_9564();
            if ((float)player.field_6012 - this.prevAge >= 100.0F) {
               this.repPower = !this.repPower;
               this.prevAge = (float)player.field_6012;
            }
            if (blockItem.method_7711() == class_2246.field_10450 && this.repPower) {
               blockState = blockState.method_11657(class_2462.field_10911, true);
            }
            if (blockItem.method_7711() == class_2246.field_10377 && this.repPower) {
               blockState = blockState.method_11657(class_2286.field_10911, true);
            }
            if (blockItem.method_7711() == class_2246.field_10523 && player.method_5869()) {
               blockState = blockState.method_11657(class_2459.field_11446, false);
            }
            if ((blockItem.method_7711() == class_2246.field_17350 || blockItem.method_7711() == class_2246.field_23860) && player.method_5869()) {
               blockState = blockState.method_11657(class_3922.field_17352, false);
            }
            if (item.method_31573(class_3489.field_16444)) {
               if (bl) { matrices.method_22904(0.9D, 0.0D, 0.8D); }
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(90 * l)));
            }
             class_2680 capturedState = blockState;
             class_1921 blockLayer = class_4696.method_23683(capturedState);
             vertexConsumers.method_73483(matrices, blockLayer, (entry, consumer) -> {
                class_4587 renderMatrices = new class_4587();
                renderMatrices.method_34425(entry.method_23761());
                class_4597 provider = ignoredLayer -> consumer;
                blockRenderManager.method_3353(
                   capturedState,
                   renderMatrices,
                   provider,
                   light,
                   class_4608.field_21444
                );
             });
             matrices.method_22909();
         } else {
            if (item.method_31573(ConventionalItemTags.TOOLS) && !item.method_31573(class_3489.field_41890) && !item.method_31573(class_3489.field_40109) && item.method_7976() != class_1839.field_8950 && item.method_7923() || item.method_7976() == class_1839.field_8953 || item.method_7976() == class_1839.field_27079 || this.isWeaponLikeItem(item) || item.method_7976() == class_1839.field_8949 || item.method_31574(class_1802.field_23254) || item.method_31574(class_1802.field_8184) || item.method_31574(class_1802.field_8378) || item.method_31574(class_1802.field_8868)) {
               if (item.method_31573(class_3489.field_42611)) {
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-60.0F * swing));
                  matrices.method_22904(0.0D, (double)(0.1F * swing), (double)(-0.1F * swing));
               }
               if (item.method_31573(class_3489.field_42615)) {
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F * swing_rot));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F * swing));
               } else if (item.method_7976() == class_1839.field_8951) {
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-40.0F * swing_rot));
                  matrices.method_22904(0.0D, (double)(0.1F * swing_rot), (double)(-0.1F * swing_rot));
               } else if (item.method_7976() != class_1839.field_8949) {
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-25.0F * swing));
                  matrices.method_22904(0.0D, (double)(0.05F * swing), (double)(-0.05F * swing));
               }
            }
            if (!item.method_31574(class_1802.field_8137) && (!item.method_31574(class_1802.field_8301) || !config.isMb3DCompat())) {
               this.netherCounter = 0.0F;
            } else {
               this.netherCounter = (float)((double)this.netherCounter + 0.9D * tt);
               matrices.method_22904(0.0D, (double)(0.25F + 0.02F * class_3532.method_15374(this.netherCounter * 0.1F)), 0.0D);
               matrices.method_22907(class_7833.field_40714.rotationDegrees(3.0F * class_3532.method_15374(this.netherCounter * 0.2F)));
               matrices.method_22905(1.0F + 0.01F * class_3532.method_15374(this.netherCounter), 1.0F + 0.01F * class_3532.method_15374(this.netherCounter), 1.0F + 0.01F * class_3532.method_15374(this.netherCounter));
            }
            if (config.isMb3DCompat()) {
               if (item.method_31573(class_3489.field_42611)) {
                  matrices.method_22904(0.0D, 0.2D, 0.0D);
               }
               if (item.method_31574(class_1802.field_8153) || item.method_31574(class_1802.field_8777) || item.method_31574(class_1802.field_8323)) {
                  this.vertVelocityYSlime = (float)((double)this.vertVelocityYSlime + (double)swingProgress * 0.03D * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
                  if ((player.method_18798().method_1033() > 0.09D && player.method_24828() || player.method_5681() || player.method_20448() || player.method_6101() && !player.method_24828()) && this.client.field_1690.method_42448().method_41753()) {
                     Random random = new Random();
                     boolean randomBoolean = random.nextBoolean();
                     this.vertVelocityYSlime += (float)(-0.05D * player.method_18798().method_1033() * com.holdmyitems.HoldMyItems.deltaTime * 30.0D);
                  }
                  matrices.method_22905(1.0F, 1.0F + this.vertAngleYSlime * -2.0F, 1.0F);
               }
            }
            if (item.method_31573(class_3489.field_42615)) {
               matrices.method_22904((double)(0.07F * (float)l), 0.0D, 0.05D);
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(90 * l)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
            }
            if (item.method_31574(class_1802.field_8810)) {
               player.method_73183().method_8406(class_2398.field_11246, player.method_73189().method_10216(), player.method_73189().method_10214(), player.method_73189().method_10215(), 0.1D, 0.1D, 0.1D);
            }
            this.renderItem(player, item, bl2 ? class_811.field_4322 : class_811.field_4321, matrices, vertexConsumers, light);
         }
      }
      matrices.method_22909();
      matrices.method_22909();
      this.isAttacking = this.client.field_1690.field_1886.method_1434();
      } finally {
      }
   }

   @Unique
   private void feverVisual$renderLuaHmi(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress,
                                         class_1799 item, float equipProgress, class_4587 matrices,
                                         class_11659 queue, int light) throws ScriptException, NoSuchMethodException {
      if (player.method_31550()) {
         this.invokeRenderFirstPersonItem(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, queue, light);
         return;
      }

      LuaTestHMI.deltaTime = (float) com.holdmyitems.HoldMyItems.deltaTime;
      LuaTestHMI.tickProgress = tickDelta;
      ((ItemStackAccessor)(Object)item).hMI5_0$setTransform(-1);

      boolean mainHand = hand == class_1268.field_5808;
      if (mainHand) {
         this.feverVisual$mainHandSwitchEvent = item.method_7909() != this.feverVisual$prevMainHand;
      } else {
         this.feverVisual$offHandSwitchEvent = item.method_7909() != this.feverVisual$prevOffHand;
      }

      boolean interact = false;
      boolean blockBreaking = false;
      if (player instanceof LivingEntityAccessor accessor) {
         this.feverVisual$mainHandSwingProgress = accessor.hMI5_0$getMainHandSwingProgress(tickDelta);
         this.feverVisual$offHandSwingProgress = accessor.hMI5_0$getOffHandSwingProgress(tickDelta);
         swingProgress = mainHand ? this.feverVisual$mainHandSwingProgress : this.feverVisual$offHandSwingProgress;
         this.feverVisual$swingMHand = accessor.hMI5_0$getMHandEvent();
         this.feverVisual$swingOHand = accessor.hMI5_0$getOHandEvent();
         interact = mainHand ? accessor.hMI5_0$getMInteract() : accessor.hMI5_0$getOInteract();
         blockBreaking = accessor.hMI5_0$getBlockBreak();
      }

      class_1306 arm = mainHand ? player.method_6068() : player.method_6068().method_5928();
      boolean rightArm = arm == class_1306.field_6183;
      matrices.method_22903();
      var config = this.getConfig();
      if (config != null) {
         float offsetSide = mainHand ? 1.0F : -1.0F;
         matrices.method_46416(config.getViewmodelXOffset() * offsetSide, config.getViewmodelYOffset(), config.getViewmodelZOffset());
         LuaScriptCache.swingSpeed = Math.max(1, config.getSwingSpeed());
      }

      this.feverVisual$scenePose(matrices, item, rightArm, swingProgress, equipProgress, player, mainHand, hand,
              this.feverVisual$mainHandSwingProgress, this.feverVisual$offHandSwingProgress,
              this.feverVisual$mainHandSwitchEvent, this.feverVisual$offHandSwitchEvent,
              this.feverVisual$swingMHand, this.feverVisual$swingOHand, interact, blockBreaking, this.feverVisual$hmiParticles);

      matrices.method_22903();
      this.feverVisual$handRelativePose(matrices, item, rightArm, swingProgress, equipProgress, player, mainHand, hand,
              this.feverVisual$mainHandSwingProgress, this.feverVisual$offHandSwingProgress,
              this.feverVisual$mainHandSwitchEvent, this.feverVisual$offHandSwitchEvent,
              this.feverVisual$swingMHand, this.feverVisual$swingOHand, interact, blockBreaking, this.feverVisual$hmiParticles);
      int combinedLight = class_765.method_62228(light, class_2248.method_9503(item.method_7909()).method_9564().method_26213());
       if (!player.method_5767() && !item.method_57826(class_9334.field_49646)) {
          this.renderArmHoldingItem(matrices, queue, combinedLight, 0.0F, 0.0F, arm);
       }
      matrices.method_22909();

      matrices.method_22903();
      this.feverVisual$itemPose(matrices, item, rightArm, swingProgress, player, mainHand, hand, equipProgress,
              this.feverVisual$mainHandSwingProgress, this.feverVisual$offHandSwingProgress,
              this.feverVisual$mainHandSwitchEvent, this.feverVisual$offHandSwitchEvent,
              this.feverVisual$swingMHand, this.feverVisual$swingOHand, interact, blockBreaking, this.feverVisual$hmiParticles);

      if (item.method_57826(class_9334.field_49646)) {
         matrices.method_22903();
         matrices.method_22904(rightArm ? -0.05D : 0.05D, 0.2D, 0.1D);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(rightArm ? -12.0F : 12.0F));
         this.renderMapInOneHand(matrices, queue, light, equipProgress, arm, swingProgress, item);
         matrices.method_22909();
      } else if (!item.method_7960()) {
         class_1799 renderStack = mainHand ? GlobalsStorage.mainHandItem : GlobalsStorage.offHandItem;
         if (renderStack.method_31574(class_1802.field_8162)) {
            renderStack = item;
         }
         DispatcherStorage.setItem(item);
         ItemModelStorage.addData(new ItemModelContext(rightArm, swingProgress, player, hand, mainHand, LuaTestHMI.deltaTime, equipProgress,
                 this.feverVisual$mainHandSwingProgress, this.feverVisual$offHandSwingProgress,
                 this.feverVisual$mainHandSwitchEvent, this.feverVisual$offHandSwitchEvent,
                 this.feverVisual$swingMHand, this.feverVisual$swingOHand, interact, blockBreaking, item), item);
         this.renderItem(player, renderStack, rightArm ? class_811.field_4320 : class_811.field_4323, matrices, queue, light);
      }

      if (rightArm) {
         LuaTestHMI.matricesMain.set(matrices.method_23760().method_23761());
      } else {
         LuaTestHMI.matricesOff.set(matrices.method_23760().method_23761());
      }
      matrices.method_22903();
      ParticleRenderManager.draw(this.feverVisual$hmiParticles, matrices, queue, "ITEM", hand, light, player, tickDelta);
      matrices.method_22909();
      matrices.method_22909();

      matrices.method_22903();
      ParticleRenderManager.draw(this.feverVisual$hmiParticles, matrices, queue, "SCREEN", hand, light, player, tickDelta);
      matrices.method_22909();

      matrices.method_22909();
      if (mainHand) {
         this.feverVisual$prevMainHand = item.method_7909();
      } else {
         this.feverVisual$prevOffHand = item.method_7909();
      }
      GlobalsStorage.offHandItem = class_1802.field_8162.method_7854();
      GlobalsStorage.mainHandItem = class_1802.field_8162.method_7854();
   }

   @Unique
   private void feverVisual$itemPose(class_4587 matrices, class_1799 item, boolean rightArm, float swingProgress,
                                     class_742 player, boolean mainHand, class_1268 hand, float equipProgress,
                                     float mainHandSwingProgress, float offHandSwingProgress, boolean mainHandSwitchEvent,
                                     boolean offHandSwitchEvent, boolean swingMHand, boolean swingOHand, boolean interact,
                                     boolean blockBreaking, List<Particle> particles) throws ScriptException, NoSuchMethodException {
      int side = rightArm ? 1 : -1;
      matrices.method_22904(0.5D * side, -0.15D, -0.85D);
      matrices.method_49278(class_7833.field_40714.rotationDegrees(15.0F), 0.5F, 0.5F, 0.5F);
      matrices.method_22905(0.9F, 0.9F, 0.9F);
      ScriptHolder.itemScriptCache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
              LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
              offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      for (LuaScriptCache cache : ScriptHolder.itemAddonsCache) {
         cache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
                 LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
                 offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      }
   }

   @Unique
   private void feverVisual$handRelativePose(class_4587 matrices, class_1799 item, boolean rightArm, float swingProgress,
                                             float equipProgress, class_742 player, boolean mainHand, class_1268 hand,
                                             float mainHandSwingProgress, float offHandSwingProgress, boolean mainHandSwitchEvent,
                                             boolean offHandSwitchEvent, boolean swingMHand, boolean swingOHand, boolean interact,
                                             boolean blockBreaking, List<Particle> particles) throws ScriptException, NoSuchMethodException {
      int side = rightArm ? 1 : -1;
      ScriptHolder.handRelativeScriptCache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
              LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
              offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      for (LuaScriptCache cache : ScriptHolder.handRelativeAddonsCache) {
         cache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
                 LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
                 offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      }
      if (!item.method_7960()) {
         matrices.method_22904(1.5D * side, -0.3D, -0.6D);
         matrices.method_49278(class_7833.field_40714.rotationDegrees(15.0F), 0.5F * side, 0.5F, 0.5F);
         matrices.method_49278(class_7833.field_40716.rotationDegrees(35.0F * side), 0.5F * side, 0.5F, 0.5F);
         matrices.method_49278(class_7833.field_40718.rotationDegrees(-65.0F * side), 0.5F * side, 0.5F, 0.5F);
         matrices.method_22905(0.9F, 0.9F, 0.9F);
      }
   }

   @Unique
   private void feverVisual$scenePose(class_4587 matrices, class_1799 item, boolean rightArm, float swingProgress,
                                      float equipProgress, class_742 player, boolean mainHand, class_1268 hand,
                                      float mainHandSwingProgress, float offHandSwingProgress, boolean mainHandSwitchEvent,
                                      boolean offHandSwitchEvent, boolean swingMHand, boolean swingOHand, boolean interact,
                                      boolean blockBreaking, List<Particle> particles) throws ScriptException, NoSuchMethodException {
      ScriptHolder.handScriptCache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
              LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
              offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      for (LuaScriptCache cache : ScriptHolder.handAddonsCache) {
         cache.execute(matrices, rightArm, GlobalsStorage.registry, swingProgress, item, player, hand, mainHand,
                 LuaTestHMI.deltaTime, equipProgress, mainHandSwingProgress, offHandSwingProgress, mainHandSwitchEvent,
                 offHandSwitchEvent, swingMHand, swingOHand, interact, blockBreaking, particles);
      }
      if (!item.method_7960()) {
         matrices.method_22904(0.0D, -0.35D, 0.2D);
      }
   }
}
