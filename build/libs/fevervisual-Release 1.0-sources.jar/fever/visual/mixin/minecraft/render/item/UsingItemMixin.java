package fever.visual.mixin.minecraft.render.item;

import com.holdmylua.source.global.GlobalsStorage;
import net.minecraft.class_10468;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_638;
import net.minecraft.class_811;
import com.hmi.HandMyItemsRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_10468.class)
public class UsingItemMixin {
   @Inject(method = "test", at = @At("RETURN"), cancellable = true)
   private void feverVisual$hmiUsingItem(class_1799 stack, class_638 world, class_1309 entity, int seed, class_811 displayContext, CallbackInfoReturnable<Boolean> cir) {
      if (HandMyItemsRuntime.isActive()
              && entity != null
              && entity.method_6030() == stack
              && GlobalsStorage.usingItem.containsKey(stack.method_7909().toString())) {
         cir.setReturnValue((Boolean) GlobalsStorage.usingItem.get(stack.method_7909().toString()));
      }
   }
}
