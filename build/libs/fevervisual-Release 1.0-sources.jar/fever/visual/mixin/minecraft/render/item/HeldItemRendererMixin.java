package fever.visual.mixin.minecraft.render.item;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.render.GlassHandsRenderEvent;
import fever.visual.systems.event.impl.render.HandRenderEvent;
import fever.visual.systems.modules.modules.visuals.AspectRatio;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
   @Unique
   private boolean feverVisual$handMatrixPushed;
   @Unique
   private boolean feverVisual$handPassCaptureActive;

   @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("HEAD"))
   private void onRenderItemPre(float tickProgress, class_4587 matrices, class_11659 queue, class_746 player, int light, CallbackInfo ci) {
      FeverVisual.getInstance().getEventManager().triggerEvent(new GlassHandsRenderEvent(GlassHandsRenderEvent.Phase.PRE, matrices, tickProgress));
   }

   @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("TAIL"))
   private void onRenderItemPost(float tickProgress, class_4587 matrices, class_11659 queue, class_746 player, int light, CallbackInfo ci) {
      FeverVisual.getInstance().getEventManager().triggerEvent(new GlassHandsRenderEvent(GlassHandsRenderEvent.Phase.POST, matrices, tickProgress));
   }

   @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
   private void onRenderFirstPersonItem(
           class_742 player,
           float tickDelta,
           float pitch,
           class_1268 hand,
           float swingProgress,
           class_1799 item,
           float equipProgress,
           class_4587 matrices,
           class_11659 queue,
           int light,
      CallbackInfo ci) {
      AspectRatio.setRenderingHands(true);
      matrices.method_22903();
      this.feverVisual$handMatrixPushed = true;
      boolean isMainHand = hand == class_1268.field_5808;
      class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
      boolean isRightArm = arm == class_1306.field_6183;
      HandRenderEvent event = new HandRenderEvent(arm, swingProgress, item, equipProgress, matrices);
      FeverVisual.getInstance().getEventManager().triggerEvent(event);
      if (event.isCancelled()) {
         ci.cancel();
         if (!event.isFullTransform()) {
            float f = -0.4F * class_3532.method_15374(class_3532.method_15355(0.0F) * (float) Math.PI);
            float g = 0.2F * class_3532.method_15374(class_3532.method_15355(0.0F) * (float) (Math.PI * 2));
            float h = -0.2F * class_3532.method_15374(0.0F);
            matrices.method_46416((arm == class_1306.field_6183 ? 1 : -1) * f, g, h);
            int i = arm == class_1306.field_6183 ? 1 : -1;
            matrices.method_46416(i * 0.56F, -0.52F, -0.72F);
         }
         if (!item.method_7960()) {
            class_759 rendererInstance = (class_759) (Object) this;
            rendererInstance.method_3233(
                    player,
                    item,
                    isRightArm ? class_811.field_4322
                            : class_811.field_4321,
                    matrices,
                    queue,
                    light);
         }

         matrices.method_22909();
         this.feverVisual$handMatrixPushed = false;
         AspectRatio.setRenderingHands(false);
      }
   }

   @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
   private void onRenderFirstPersonItemEnd(
           class_742 player,
           float tickDelta,
           float pitch,
           class_1268 hand,
           float swingProgress,
           class_1799 item,
           float equipProgress,
           class_4587 matrices,
           class_11659 queue,
           int light,
           CallbackInfo ci) {
      if (this.feverVisual$handMatrixPushed) {
         matrices.method_22909();
         this.feverVisual$handMatrixPushed = false;
      }
      AspectRatio.setRenderingHands(false);
   }
}
