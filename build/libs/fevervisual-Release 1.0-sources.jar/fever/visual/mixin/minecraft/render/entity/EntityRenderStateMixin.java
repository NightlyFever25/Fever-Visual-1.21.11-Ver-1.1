package fever.visual.mixin.minecraft.render.entity;

import fever.visual.utility.mixins.EntityRenderStateAddition;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10017.class)
public abstract class EntityRenderStateMixin implements EntityRenderStateAddition {
   @Unique
   private class_1297 fevervisual$entity;

   @Unique
   @Override
   public void fevervisual$setEntity(class_1297 entity) {
      this.fevervisual$entity = entity;
   }

   @Unique
   @Override
   public class_1297 fevervisual$getEntity() {
      return this.fevervisual$entity;
   }
}
