package fever.visual.mixin.minecraft.render;

import fever.visual.utility.mixins.EntityRenderStateAddition;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import fever.visual.systems.modules.modules.visuals.GlowEsp;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297, S extends class_10017> {
   @Inject(method = "updateRenderState", at = @At("HEAD"))
   private void updateRenderingEntity(T entity, S state, float tickDelta, CallbackInfo ci) {
      ((EntityRenderStateAddition)state).fevervisual$setEntity(entity);
   }

   @Inject(method = "updateRenderState", at = @At("RETURN"))
   private void fevervisual$applyGlowEspColor(T entity, S state, float tickDelta, CallbackInfo ci) {
      Integer color = GlowEsp.outlineColorFor(entity);
      if (color != null) {
         state.field_61821 = color;
      }
   }
}
