package fever.visual.mixin.minecraft.render.entity.feature;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_10042;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_583;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3887.class)
public abstract class FeatureRendererMixin {

   private static void changeModelColor(
      class_583<?> instance,
      class_4587 matrixStack,
      class_4588 vertexConsumer,
      int light,
      int overlay,
      int color,
      Operation<Void> original,
      @Local(argsOnly = true) class_10042 state
   ) {
      original.call(new Object[]{instance, matrixStack, vertexConsumer, light, overlay, color});
   }

}
