package fever.visual.mixin.minecraft.render.item;

import fever.visual.systems.modules.modules.visuals.CustomSwords;
import java.util.List;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_811;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_10442.class)
public abstract class ItemModelResolverMixin {
   @ModifyArg(
      method = "clearAndUpdate",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/item/ItemModelManager;update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/world/World;Lnet/minecraft/util/HeldItemContext;I)V"
      ),
      index = 1,
      require = 0
   )
   private class_1799 fevervisual$replaceSwordModel(
      class_10444 renderState,
      class_1799 stack,
      class_811 displayContext,
      class_1937 world,
      class_11566 itemOwner,
      int seed
   ) {
      CustomSwords module = CustomSwords.getModule();
      if (module == null || !module.isEnabled() || !this.isSword(stack)) {
         return stack;
      }
      if (itemOwner == null) {
         return stack;
      }
      if (module.isSelfOnly() && itemOwner.method_72393() != net.minecraft.class_310.method_1551().field_1724) {
         return stack;
      }
      class_1799 renderedStack = stack.method_7972();
      renderedStack.method_57379(
         class_9334.field_49637,
         new class_9280(List.of(), List.of(), List.of(module.getSelectedWeapon()), List.of())
      );
      return renderedStack;
   }

   private boolean isSword(class_1799 stack) {
      return stack.method_31574(class_1802.field_8091)
         || stack.method_31574(class_1802.field_8528)
         || stack.method_31574(class_1802.field_61338)
         || stack.method_31574(class_1802.field_8371)
         || stack.method_31574(class_1802.field_8845)
         || stack.method_31574(class_1802.field_8802)
         || stack.method_31574(class_1802.field_22022);
   }
}
