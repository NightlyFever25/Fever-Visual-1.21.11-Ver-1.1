package fever.visual.mixin.minecraft.render.entity;

import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_897.class})
public class EntityRendererMixin<T extends class_1297> {
}
