package fever.visual.mixin.minecraft.render.item;

import com.holdmylua.source.global.GlobalsStorage;
import net.minecraft.class_10485;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_638;
import com.hmi.HandMyItemsRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_10485.class)
public class UseDurationMixin {
   @Inject(method = "getValue", at = @At("RETURN"), cancellable = true)
   private void feverVisual$hmiUseDuration(class_1799 stack, class_638 world, class_11566 context, int seed, CallbackInfoReturnable<Float> cir) {
      if (HandMyItemsRuntime.isActive()
              && class_310.method_1551().field_1724 != null
              && class_310.method_1551().field_1724.method_6030() == stack
              && GlobalsStorage.useDuration.containsKey(stack.method_7909().toString())) {
         cir.setReturnValue(Float.parseFloat(GlobalsStorage.useDuration.get(stack.method_7909().toString()).toString()));
      }
   }
}
