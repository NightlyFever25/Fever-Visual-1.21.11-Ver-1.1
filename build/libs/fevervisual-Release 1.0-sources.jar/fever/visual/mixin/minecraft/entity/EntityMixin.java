package fever.visual.mixin.minecraft.entity;

import fever.visual.systems.modules.modules.player.Freelook;
import fever.visual.utility.game.PlatformUtility;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class EntityMixin {
   @Inject(method = "changeLookDirection(DD)V", at = @At("HEAD"), cancellable = true)
   private void fevervisual$preventLunarFreelookBodyRotation(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
      if (PlatformUtility.isLunarClient() && Freelook.isActive && (Object)this == class_310.method_1551().field_1724) {
         ci.cancel();
      }
   }
}
