package fever.visual.mixin.minecraft.entity;

import fever.visual.FeverVisual;
import fever.visual.systems.event.impl.game.FireworkEvent;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1671.class)
public abstract class FireworkRocketEntityMixin implements IMinecraft {
   @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V"))
   private void redirectSetVelocity(class_1309 shooter, class_243 velocity) {
      class_1671 rocketEntity = (class_1671) (Object) this;
      FireworkEvent event = new FireworkEvent(shooter, velocity, rocketEntity);
      FeverVisual.getInstance().getEventManager().triggerEvent(event);
      shooter.method_18799(event.getVelocity());
   }

}
