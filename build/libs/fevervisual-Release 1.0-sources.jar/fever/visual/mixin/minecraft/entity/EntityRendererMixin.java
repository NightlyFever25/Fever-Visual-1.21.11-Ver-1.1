package fever.visual.mixin.minecraft.entity;

import fever.visual.systems.modules.modules.other.Optimization;
import fever.visual.systems.modules.modules.visuals.NameTags;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import fever.visual.systems.event.RenderedEntityTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297, S extends class_10017> {
   @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
   private void onRenderLabel(T entity, CallbackInfoReturnable<class_2561> cir) {
      if (NameTags.shouldHideVanilla(entity)) {
         cir.setReturnValue(null);
      }
   }

   @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
   private void fevervisual$skipOptimizedEntities(T entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      Optimization optimization = Optimization.getInstanceSafe();
      if (optimization != null && optimization.shouldSkipEntity(entity, x, y, z)) {
         cir.setReturnValue(false);
      }
   }

   @Inject(method = "shouldRender", at = @At("RETURN"))
   private void fevervisual$trackRenderedEntity(T entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      if (cir.getReturnValueZ()) {
         RenderedEntityTracker.mark(entity);
      }
   }
}
