package fever.visual.mixin.minecraft.world.chunk;

import com.llamalad7.mixinextras.sugar.Local;
import fever.visual.utility.game.WorldUtility;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2818.class)
public abstract class WorldChunkMixin {
   @Shadow
   public abstract class_1937 getWorld();

   @Inject(method = "setBlockEntity", at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"))
   private void onLoadBlockEntity(class_2586 blockEntity, CallbackInfo ci, @Local(ordinal = 0, argsOnly = true) class_2586 removedBlockEntity) {
      if (!WorldUtility.blockEntities.contains(blockEntity)) {
      }
   }

   @Inject(method = "removeBlockEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/entity/BlockEntity;markRemoved()V"))
   private void onRemoveBlockEntity(class_2338 pos, CallbackInfo ci, @Local @Nullable class_2586 removed) {
      if (removed != null) {
         WorldUtility.blockEntities.remove(removed);
      }
   }
}
