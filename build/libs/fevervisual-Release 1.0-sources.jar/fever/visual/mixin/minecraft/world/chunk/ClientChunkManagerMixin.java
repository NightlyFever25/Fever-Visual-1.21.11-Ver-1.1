package fever.visual.mixin.minecraft.world.chunk;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1923;
import net.minecraft.class_2540;
import net.minecraft.class_2818;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_631;
import net.minecraft.class_6603.class_6605;
import fever.visual.utility.chunkanimator.ChunkAnimator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_631.class)
public class ClientChunkManagerMixin {
   @Inject(method = "loadChunkFromPacket", at = @At("TAIL"))
   private void onChunkLoad(
      int x,
      int z,
      class_2540 buf,
      Map<class_2903, long[]> heightmaps,
      Consumer<class_6605> consumer,
      CallbackInfoReturnable<class_2818> cir
   ) {
      class_1923 pos = new class_1923(x, z);
      class_2818 chunk = (class_2818)cir.getReturnValue();
      if (chunk != null) {
         float surfaceY = this.getSurfaceY(chunk);
         ChunkAnimator.startAnimation(pos, surfaceY);
      }
   }

   private float getSurfaceY(class_2818 chunk) {
      int totalHeight = 0;
      int count = 0;

      for (int x = 0; x < 16; x++) {
         for (int z = 0; z < 16; z++) {
            int height = chunk.method_12032(class_2903.field_13202).method_12603(x, z);
            totalHeight += height;
            count++;
         }
      }

      return count > 0 ? (float)totalHeight / count : 64.0F;
   }
}
