package fever.visual.mixin.minecraft.world.explosion;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_9892;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventManager;
import fever.visual.systems.event.impl.game.AncientDebrisEvent;
import fever.visual.utility.interfaces.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9892.class)
public abstract class ExplosionImplMixin implements IMinecraft {
   @Inject(method = "getBlocksToDestroy", at = @At("RETURN"))
   private void onBlocksToDestroyCalculated(CallbackInfoReturnable<List<class_2338>> cir) {
      class_9892 self = (class_9892) (Object) this;
      List<class_2338> affectedBlocks = cir.getReturnValue();
      if (affectedBlocks == null || affectedBlocks.isEmpty() || self.method_64504().method_27983() != class_1937.field_25180) {
         return;
      }

      List<class_2338> debris = affectedBlocks.stream()
            .filter(pos -> self.method_64504().method_8320(pos).method_27852(class_2246.field_22109)).toList();
      EventManager eventManager = FeverVisual.getInstance().getEventManager();
      if (!debris.isEmpty() && eventManager != null) {
         eventManager.triggerEvent(new AncientDebrisEvent(debris, self.method_55109()));
      }
   }
}
