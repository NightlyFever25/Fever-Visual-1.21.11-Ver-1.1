package fever.visual.mixin.minecraft.world;

import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1937.class)
public abstract class WorldMixin {
}
