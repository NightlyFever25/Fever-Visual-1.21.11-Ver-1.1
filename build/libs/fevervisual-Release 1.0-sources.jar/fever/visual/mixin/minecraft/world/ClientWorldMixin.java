package fever.visual.mixin.minecraft.world;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.modules.visuals.NoRender;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public abstract class ClientWorldMixin {
   @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true)
   private void fevervisual$suppressBlockBreakParticles(class_2338 pos, class_2680 state, CallbackInfo ci) {
      NoRender noRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
      if (noRender.isEnabled() && noRender.getBreakParticles().isSelected()) {
         ci.cancel();
      }
   }

   @Inject(method = "spawnBlockBreakingParticle", at = @At("HEAD"), cancellable = true)
   private void fevervisual$suppressBlockBreakingParticle(class_2338 pos, class_2350 direction, CallbackInfo ci) {
      NoRender noRender = FeverVisual.getInstance().getModuleManager().getModule(NoRender.class);
      if (noRender.isEnabled() && noRender.getBreakParticles().isSelected()) {
         ci.cancel();
      }
   }

   @Inject(method = "handleBlockUpdate", at = @At("HEAD"))
   private void onHandleBlockUpdate(class_2338 pos, class_2680 state, int flags, CallbackInfo ci) {
   }
}
