package fever.visual.mixin.accessors;

import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_572.class)
public interface BipedEntityModelAccessor {
   @Accessor("head")
   class_630 fevervisual$getHead();

   @Accessor("hat")
   class_630 fevervisual$getHat();

   @Accessor("leftArm")
   class_630 fevervisual$getLeftArm();

   @Accessor("rightArm")
   class_630 fevervisual$getRightArm();

   @Accessor("leftLeg")
   class_630 fevervisual$getLeftLeg();

   @Accessor("rightLeg")
   class_630 fevervisual$getRightLeg();
}