package fever.visual.mixin.accessors;

import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAccessor {
   @Accessor("children")
   List<class_364> getChildren();

   @Invoker("addDrawableChild")
   <T extends class_364 & class_4068 & class_6379> T invokeAddDrawableChild(T var1);
}
