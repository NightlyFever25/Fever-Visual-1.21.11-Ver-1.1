package fever.visual.mixin.accessors;

import net.minecraft.class_1671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1671.class)
public interface FireworkRocketEntityAccessor {
   @Accessor("life")
   int getLife();

   @Accessor("life")
   void setLife(int var1);

   @Accessor("lifeTime")
   int getLifeTime();

   @Accessor("lifeTime")
   void setLifeTime(int var1);
}
