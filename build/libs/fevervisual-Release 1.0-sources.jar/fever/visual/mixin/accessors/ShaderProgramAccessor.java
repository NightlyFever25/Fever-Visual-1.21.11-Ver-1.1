package fever.visual.mixin.accessors;

import java.util.Map;
import net.minecraft.class_284;
import net.minecraft.class_5944;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5944.class)
public interface ShaderProgramAccessor {
   @Accessor
   Map<String, class_284> getUniformsByName();
}
