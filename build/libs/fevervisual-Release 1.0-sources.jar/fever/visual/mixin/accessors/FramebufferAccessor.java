package fever.visual.mixin.accessors;

import net.minecraft.class_276;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_276.class)
public interface FramebufferAccessor {
   @Accessor("depthAttachment")
   int getDepthAttachment();

   @Accessor("depthAttachment")
   void setDepthAttachment(int var1);
}
