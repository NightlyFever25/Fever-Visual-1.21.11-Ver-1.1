package fever.visual.mixin.accessors;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface HandledScreenAccessor {
   @Accessor("x")
   int getX();

   @Accessor("y")
   int getY();

   @Accessor("backgroundWidth")
   int getBackgroundWidth();

   @Accessor("backgroundHeight")
   int getBackgroundHeight();
}
