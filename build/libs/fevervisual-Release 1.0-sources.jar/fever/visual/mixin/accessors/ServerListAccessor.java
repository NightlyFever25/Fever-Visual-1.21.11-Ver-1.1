package fever.visual.mixin.accessors;

import java.util.List;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_641.class)
public interface ServerListAccessor {
   @Accessor("servers")
   List<class_642> feverVisual$getServers();

   @Accessor("hiddenServers")
   List<class_642> feverVisual$getHiddenServers();
}
