package fever.visual.mixin.accessors;

import net.minecraft.class_2684;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2684.class)
public interface EntityS2CPacketAccessor {
   @Accessor("id")
   int getId();
}
