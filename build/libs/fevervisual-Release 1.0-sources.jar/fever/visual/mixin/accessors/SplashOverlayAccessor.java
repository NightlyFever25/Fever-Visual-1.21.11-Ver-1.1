package fever.visual.mixin.accessors;

import net.minecraft.class_310;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_425.class)
public interface SplashOverlayAccessor {
   @Accessor("reload")
   class_4011 getReload();

   @Accessor("client")
   class_310 getClient();

   @Accessor("reloadCompleteTime")
   long getReloadCompleteTime();

   @Accessor("reloadCompleteTime")
   void setReloadCompleteTime(long var1);
}
