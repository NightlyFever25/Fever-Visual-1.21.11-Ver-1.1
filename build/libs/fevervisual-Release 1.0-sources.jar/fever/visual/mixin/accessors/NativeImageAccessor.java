package fever.visual.mixin.accessors;

import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1011.class)
public interface NativeImageAccessor {
   @Accessor("pointer")
   long getPointer();

   @Invoker("setColor")
   void invokeSetColor(int var1, int var2, int var3);
}
