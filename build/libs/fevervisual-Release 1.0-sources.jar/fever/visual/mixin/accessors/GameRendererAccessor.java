package fever.visual.mixin.accessors;

import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_757.class)
public interface GameRendererAccessor {
   @Accessor("buffers")
   class_4599 buffers();

   @Accessor("lightmapTextureManager")
   class_765 lightmapTextureManager();

   @Accessor("fogRenderer")
   class_758 fogRenderer();

   @Invoker("getProjectionMatrix")
   Matrix4f invokeGetProjectionMatrix(float tickProgress);
}
