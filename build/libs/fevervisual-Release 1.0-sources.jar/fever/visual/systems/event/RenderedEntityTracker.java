package fever.visual.systems.event;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1297;

/** Entities accepted by Minecraft's frustum/entity renderer in the current world frame. */
public final class RenderedEntityTracker {
   private static final Set<Integer> RENDERED = new HashSet<>();

   private RenderedEntityTracker() {
   }

   public static void beginFrame() {
      RENDERED.clear();
   }

   public static void mark(class_1297 entity) {
      if (entity != null) {
         RENDERED.add(entity.method_5628());
      }
   }

   public static boolean contains(class_1297 entity) {
      return entity != null && RENDERED.contains(entity.method_5628());
   }
}
