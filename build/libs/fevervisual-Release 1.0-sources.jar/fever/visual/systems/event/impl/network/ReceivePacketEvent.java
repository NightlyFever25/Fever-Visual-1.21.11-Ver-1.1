package fever.visual.systems.event.impl.network;

import lombok.Generated;
import net.minecraft.class_2596;
import fever.visual.systems.event.EventCancellable;

public class ReceivePacketEvent extends EventCancellable {
   private final class_2596<?> packet;

   @Generated
   public class_2596<?> getPacket() {
      return this.packet;
   }

   @Generated
   public ReceivePacketEvent(class_2596<?> packet) {
      this.packet = packet;
   }
}
