package fever.visual.systems.event.impl.render;

import lombok.Generated;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import fever.visual.systems.event.EventCancellable;

public class HandRenderEvent extends EventCancellable {
   private final class_1306 arm;
   private final float swingProgress;
   private final class_1799 itemStack;
   private final float equipProgress;
   private final class_4587 matrices;
   private boolean fullTransform;
   @Generated
   public class_1306 getArm() {
      return this.arm;
   }

   @Generated
   public float getSwingProgress() {
      return this.swingProgress;
   }

   @Generated
   public class_1799 getItemStack() {
      return this.itemStack;
   }

   @Generated
   public float getEquipProgress() {
      return this.equipProgress;
   }
   @Generated
   public class_4587 getMatrices() {
      return this.matrices;
   }

   public boolean isFullTransform() {
      return this.fullTransform;
   }

   public void setFullTransform(boolean fullTransform) {
      this.fullTransform = fullTransform;
   }

   @Generated
   public HandRenderEvent(class_1306 arm, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 matrices) {
      this.arm = arm;
      this.swingProgress = swingProgress;
      this.itemStack = itemStack;
      this.equipProgress = equipProgress;
      this.matrices = matrices;
      this.fullTransform = false;
   }
}
