package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_437;
import fever.visual.systems.event.Event;

public class CloseScreenEvent extends Event {
   private final class_437 screen;

   @Generated
   public class_437 getScreen() {
      return this.screen;
   }

   @Generated
   public CloseScreenEvent(class_437 screen) {
      this.screen = screen;
   }
}
