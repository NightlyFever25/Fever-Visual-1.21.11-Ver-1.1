package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_2338;
import fever.visual.systems.event.EventCancellable;

public class StartBreakBlockEvent extends EventCancellable {
   private final class_2338 blockPos;

   public StartBreakBlockEvent(class_2338 blockPos) {
      this.blockPos = blockPos;
   }

   @Generated
   public class_2338 getBlockPos() {
      return this.blockPos;
   }
}
