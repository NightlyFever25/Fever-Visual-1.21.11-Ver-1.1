package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1297;
import fever.visual.systems.event.Event;

public class PostAttackEvent extends Event {
   private final class_1297 entity;

   public PostAttackEvent(class_1297 entity) {
      this.entity = entity;
   }

   @Generated
   public class_1297 getEntity() {
      return this.entity;
   }
}
