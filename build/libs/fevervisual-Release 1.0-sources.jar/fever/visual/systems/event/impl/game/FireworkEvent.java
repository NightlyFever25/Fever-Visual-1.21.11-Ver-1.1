package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import fever.visual.systems.event.Event;

public class FireworkEvent extends Event {
   private final class_1309 entity;
   private class_243 velocity;
   private final class_1671 rocketEntity;

   @Generated
   public class_1309 getEntity() {
      return this.entity;
   }

   @Generated
   public class_243 getVelocity() {
      return this.velocity;
   }

   @Generated
   public class_1671 getRocketEntity() {
      return this.rocketEntity;
   }

   @Generated
   public void setVelocity(class_243 velocity) {
      this.velocity = velocity;
   }

   @Generated
   public FireworkEvent(class_1309 entity, class_243 velocity, class_1671 rocketEntity) {
      this.entity = entity;
      this.velocity = velocity;
      this.rocketEntity = rocketEntity;
   }
}
