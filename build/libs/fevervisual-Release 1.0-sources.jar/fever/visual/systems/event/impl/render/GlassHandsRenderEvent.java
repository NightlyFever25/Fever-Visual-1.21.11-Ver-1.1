package fever.visual.systems.event.impl.render;

import fever.visual.systems.event.EventCancellable;
import net.minecraft.class_4587;

public class GlassHandsRenderEvent extends EventCancellable {
   private final Phase phase;
   private final class_4587 matrices;
   private final float tickDelta;

   public GlassHandsRenderEvent(Phase phase, class_4587 matrices, float tickDelta) {
      this.phase = phase;
      this.matrices = matrices;
      this.tickDelta = tickDelta;
   }

   public Phase getPhase() {
      return this.phase;
   }

   public class_4587 getMatrices() {
      return this.matrices;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public enum Phase {
      PRE,
      POST
   }
}
