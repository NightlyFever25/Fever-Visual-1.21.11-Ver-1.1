package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1297;
import fever.visual.systems.event.EventCancellable;

public class InternalAttackEvent extends EventCancellable {
   private final class_1297 entity;

   @Generated
   public class_1297 getEntity() {
      return this.entity;
   }

   @Generated
   public InternalAttackEvent(class_1297 entity) {
      this.entity = entity;
   }
}
