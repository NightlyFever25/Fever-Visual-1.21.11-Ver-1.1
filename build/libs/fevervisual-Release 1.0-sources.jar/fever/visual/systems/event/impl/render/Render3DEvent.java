package fever.visual.systems.event.impl.render;

import lombok.Generated;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import fever.visual.systems.event.Event;
import org.joml.Matrix4f;

public class Render3DEvent extends Event {
   private final class_4587 matrices;
   private final Matrix4f positionMatrix;
   private final Matrix4f projectionMatrix;
   private final class_4184 camera;
   private final float tickDelta;

   @Generated
   public class_4587 getMatrices() {
      return this.matrices;
   }

   @Generated
   public Matrix4f getPositionMatrix() {
      return this.positionMatrix;
   }

   @Generated
   public Matrix4f getProjectionMatrix() {
      return this.projectionMatrix;
   }

   @Generated
   public class_4184 getCamera() {
      return this.camera;
   }

   @Generated
   public float getTickDelta() {
      return this.tickDelta;
   }

   @Generated
   public Render3DEvent(class_4587 matrices, Matrix4f positionMatrix, Matrix4f projectionMatrix, class_4184 camera, float tickDelta) {
      this.matrices = matrices;
      this.positionMatrix = positionMatrix;
      this.projectionMatrix = projectionMatrix;
      this.camera = camera;
      this.tickDelta = tickDelta;
   }
}
