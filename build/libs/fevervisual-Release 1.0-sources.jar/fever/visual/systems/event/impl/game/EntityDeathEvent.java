package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import fever.visual.systems.event.Event;
import org.jetbrains.annotations.Nullable;

public class EntityDeathEvent extends Event {
   private final class_1309 entity;
   private final class_1282 source;

   public EntityDeathEvent(class_1309 entity, class_1282 source) {
      this.entity = entity;
      this.source = source;
   }

   @Nullable
   public class_1309 getKillerEntity() {
      return this.entity.method_6124();
   }

   @Generated
   public class_1309 getEntity() {
      return this.entity;
   }

   @Generated
   public class_1282 getSource() {
      return this.source;
   }
}
