package fever.visual.systems.event.impl.network;

import lombok.Generated;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import fever.visual.systems.event.Event;

public class ServerConnectionEvent extends Event {
   private final class_639 address;
   private final class_642 info;
   private final class_9112 cookieStorage;

   @Generated
   public class_639 getAddress() {
      return this.address;
   }

   @Generated
   public class_642 getInfo() {
      return this.info;
   }

   @Generated
   public class_9112 getCookieStorage() {
      return this.cookieStorage;
   }

   @Generated
   public ServerConnectionEvent(class_639 address, class_642 info, class_9112 cookieStorage) {
      this.address = address;
      this.info = info;
      this.cookieStorage = cookieStorage;
   }
}
