package fever.visual.systems.event.impl.network;

import lombok.Generated;
import net.minecraft.class_2596;
import fever.visual.systems.event.EventCancellable;

public class SendPacketEvent extends EventCancellable {
   private class_2596<?> packet;

   @Generated
   public class_2596<?> getPacket() {
      return this.packet;
   }

   @Generated
   public void setPacket(class_2596<?> packet) {
      this.packet = packet;
   }

   @Generated
   public SendPacketEvent(class_2596<?> packet) {
      this.packet = packet;
   }
}
