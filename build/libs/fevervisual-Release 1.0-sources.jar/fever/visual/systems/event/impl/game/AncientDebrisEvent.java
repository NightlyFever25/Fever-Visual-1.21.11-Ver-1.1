package fever.visual.systems.event.impl.game;

import java.util.Collections;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import fever.visual.systems.event.Event;

public class AncientDebrisEvent extends Event {
   private final List<class_2338> positions;
   private final class_243 explosionCenter;

   public AncientDebrisEvent(List<class_2338> positions, class_243 center) {
      this.positions = Collections.unmodifiableList(positions);
      this.explosionCenter = center;
   }

   @Generated
   public List<class_2338> getPositions() {
      return this.positions;
   }

   @Generated
   public class_243 getExplosionCenter() {
      return this.explosionCenter;
   }
}
