package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1799;
import fever.visual.systems.event.Event;

public class PickupEvent extends Event {
   public class_1799 itemStack;
   public int count;

   public PickupEvent(class_1799 itemStack, int count) {
      this.itemStack = itemStack;
      this.count = count;
   }

   @Generated
   public class_1799 getItemStack() {
      return this.itemStack;
   }

   @Generated
   public int getCount() {
      return this.count;
   }
}
