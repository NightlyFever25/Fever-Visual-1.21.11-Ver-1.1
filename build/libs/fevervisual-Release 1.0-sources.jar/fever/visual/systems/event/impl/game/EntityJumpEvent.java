package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1309;
import fever.visual.systems.event.EventCancellable;

public class EntityJumpEvent extends EventCancellable {
   private final class_1309 entity;

   @Generated
   public class_1309 getEntity() {
      return this.entity;
   }

   @Generated
   public EntityJumpEvent(class_1309 entity) {
      this.entity = entity;
   }
}
