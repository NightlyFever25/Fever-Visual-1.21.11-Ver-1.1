package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1113;
import fever.visual.systems.event.Event;

public class SoundEvent extends Event {
   public class_1113 sound;

   public SoundEvent(class_1113 sound) {
      this.sound = sound;
   }

   @Generated
   public class_1113 getSound() {
      return this.sound;
   }
}
