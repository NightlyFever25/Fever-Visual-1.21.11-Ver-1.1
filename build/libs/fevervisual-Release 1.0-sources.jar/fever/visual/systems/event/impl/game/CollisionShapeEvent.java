package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import fever.visual.systems.event.EventCancellable;

public class CollisionShapeEvent extends EventCancellable {
   private final class_2680 state;
   private final class_2338 pos;
   private class_265 shape;

   @Generated
   public CollisionShapeEvent(class_2680 state, class_2338 pos, class_265 shape) {
      this.state = state;
      this.pos = pos;
      this.shape = shape;
   }

   @Generated
   public class_2680 getState() {
      return this.state;
   }

   @Generated
   public class_2338 getPos() {
      return this.pos;
   }

   @Generated
   public class_265 getShape() {
      return this.shape;
   }

   @Generated
   public void setShape(class_265 shape) {
      this.shape = shape;
   }
}
