package fever.visual.systems.event.impl.game;

import lombok.Generated;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import fever.visual.systems.event.Event;

public class FinishEatEvent extends Event {
   private final class_1657 user;
   private final class_1799 stack;

   @Generated
   public class_1657 getUser() {
      return this.user;
   }

   @Generated
   public class_1799 getStack() {
      return this.stack;
   }

   @Generated
   public FinishEatEvent(class_1657 user, class_1799 stack) {
      this.user = user;
      this.stack = stack;
   }
}
