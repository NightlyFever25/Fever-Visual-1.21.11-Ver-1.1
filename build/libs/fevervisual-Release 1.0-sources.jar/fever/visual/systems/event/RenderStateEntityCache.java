package fever.visual.systems.event;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_10042;
import net.minecraft.class_1309;

public final class RenderStateEntityCache {
    private static final Map<class_10042, class_1309> STATE_ENTITY = Collections.synchronizedMap(new WeakHashMap<>());

    private RenderStateEntityCache() {
    }

    public static void put(class_10042 state, class_1309 entity) {
        if (state == null || entity == null) {
            return;
        }
        STATE_ENTITY.put(state, entity);
    }

    public static class_1309 get(class_10042 state) {
        if (state == null) {
            return null;
        }
        return STATE_ENTITY.get(state);
    }
}