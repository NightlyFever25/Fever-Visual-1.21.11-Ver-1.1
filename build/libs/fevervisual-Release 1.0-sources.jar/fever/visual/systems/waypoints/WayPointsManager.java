package fever.visual.systems.waypoints;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import java.util.Map.Entry;
import fever.visual.systems.localization.Localizator;
import fever.visual.utility.game.MessageUtility;

public class WayPointsManager {
   private final Map<String, class_243> waypoints = new HashMap<>();

   public void add(String name, int x, int y, int z) {
      class_243 pos = new class_243(x, y, z);
      if (this.waypoints.containsKey(name)) {
         MessageUtility.error(class_2561.method_30163(Localizator.translate("modules.waypoints.exists", name)));
      } else {
         this.waypoints.put(name, pos);
         MessageUtility.info(class_2561.method_30163(Localizator.translate("modules.waypoints.added", name, x, y, z)));
      }
   }

   public void del(String name) {
      if (this.waypoints.remove(name) != null) {
         MessageUtility.info(class_2561.method_30163(Localizator.translate("modules.waypoints.deleted", name)));
      } else {
         MessageUtility.info(class_2561.method_30163(Localizator.translate("modules.waypoints.not_found", name)));
      }
   }

   public void clear() {
      this.waypoints.clear();
      MessageUtility.info(class_2561.method_30163(Localizator.translate("modules.waypoints.cleared")));
   }

   public boolean contains(String name) {
      return this.waypoints.containsKey(name);
   }

   public Set<Entry<String, class_243>> getEntries() {
      return this.waypoints.entrySet();
   }
}
