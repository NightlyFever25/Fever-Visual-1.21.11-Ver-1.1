package fever.visual.systems.policy;

import java.nio.charset.StandardCharsets;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record FeatureControlPayload(String json) implements class_8710 {
   public static final class_2960 CHANNEL = class_2960.method_60655("liteapi", "feature-control");
   public static final class_8710.class_9154<FeatureControlPayload> ID = new class_8710.class_9154<>(CHANNEL);
   public static final class_9139<class_2540, FeatureControlPayload> CODEC = class_9139.method_56437(
         FeatureControlPayload::write,
         FeatureControlPayload::read
   );
   private static final int MAX_BYTES = 262_144;

   private static void write(class_2540 buffer, FeatureControlPayload payload) {
      buffer.method_52983(payload.json.getBytes(StandardCharsets.UTF_8));
   }

   private static FeatureControlPayload read(class_2540 buffer) {
      try {
         int length = buffer.readableBytes();
         if (length <= 0 || length > MAX_BYTES) {
            if (length > 0) {
               buffer.method_52994(length);
            }
            return new FeatureControlPayload("");
         }
         byte[] bytes = new byte[length];
         buffer.method_52979(bytes);
         return new FeatureControlPayload(new String(bytes, StandardCharsets.UTF_8));
      } catch (RuntimeException exception) {
         if (buffer.isReadable()) {
            buffer.method_52994(buffer.readableBytes());
         }
         return new FeatureControlPayload("");
      }
   }

   @Override
   public class_9154<? extends class_8710> method_56479() {
      return ID;
   }
}
