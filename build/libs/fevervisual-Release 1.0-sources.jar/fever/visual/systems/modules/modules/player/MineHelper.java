package fever.visual.systems.modules.modules.player;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.StartBreakBlockEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import net.minecraft.class_1799;
import net.minecraft.class_3489;

@ModuleInfo(name = "Mine Helper", category = ModuleCategory.MISC, desc = "modules.descriptions.mine_helper")
public class MineHelper extends BaseModule {
   private final BooleanSetting save = new BooleanSetting(this, "modules.settings.mine_helper.save", "modules.settings.mine_helper.save.description").enable();
   public final SliderSetting percent = new SliderSetting(this, "modules.settings.mine_helper.percent").step(1.0F).min(1.0F).max(70.0F).currentValue(10.0F).suffix("%");
   private final EventListener<StartBreakBlockEvent> onStartBreakBlockEvent = event -> {
      if (mc.field_1724 != null) {
         class_1799 currentStack = mc.field_1724.method_6047();
         if (this.isValidPickaxe(currentStack)) {
            double durabilityPercent = this.getDurabilityPercent(currentStack);
            if (this.save.isEnabled() && !(durabilityPercent >= this.percent.getCurrentValue())) {
               event.cancel();
               this.handleLowDurability(currentStack);
            }
         }
      }
   };

   private void handleLowDurability(class_1799 currentStack) {
   }

   private boolean isValidPickaxe(class_1799 stack) {
      return stack != null && stack.method_7963() && stack.method_31573(class_3489.field_42614);
   }

   private double getDurabilityPercent(class_1799 stack) {
      return (double)(stack.method_7936() - stack.method_7919()) / stack.method_7936() * 100.0;
   }
}
