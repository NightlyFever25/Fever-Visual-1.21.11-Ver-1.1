package fever.visual.systems.modules.modules.visuals.littlePet;

import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.FeverVisual;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import fever.visual.utility.render.compat.BufferRenderer;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public final class ChinaHat {
    private static final int SEGMENTS = 32;
    private static final float[] UNIT_X = createCircleAxis(true);
    private static final float[] UNIT_Z = createCircleAxis(false);
    private static final float SETTING_MIN_RADIUS = 1.2F;
    private static final float SETTING_MAX_RADIUS = 2.1F;
    private static final float MAX_RADIUS = 1.2F;
    private static final float MIN_RADIUS = 0.3F;

    public static void renderAttachedToHead(
            class_4587 matrices,
            float radius,
            float coneHeight,
            float yOffset,
            ColorRGBA hatColor,
            float alpha
    ) {
        if (matrices == null) {
            return;
        }

        ColorRGBA finalColor = hatColor != null ? hatColor : getDefaultColor();
        float mappedRadius = mapRadius(radius);
        float mappedHeight = mapHeight(coneHeight);

        matrices.method_22903();
        matrices.method_22904(0.0D, -0.25D - yOffset, 0.0D);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));

        drawConeHat(matrices, finalColor, mappedRadius, -mappedHeight, alpha, false);

        matrices.method_22909();
    }

    private static float mapRadius(float inputRadius) {
        float normalized = (inputRadius - SETTING_MIN_RADIUS) / (SETTING_MAX_RADIUS - SETTING_MIN_RADIUS);
        normalized = class_3532.method_15363(normalized, 0.0F, 1.0F);
        float eased = (float) Math.pow(normalized, 1.5);
        return MIN_RADIUS + eased * (MAX_RADIUS - MIN_RADIUS);
    }
    private static float mapHeight(float inputHeight) {
        float normalized = (inputHeight - 0.05F) / (0.8F - 0.05F);
        return 0.15F + normalized * 0.5F;
    }

    private static void drawConeHat(
            class_4587 matrices,
            ColorRGBA color,
            float radius,
            float coneHeight,
            float alpha,
            boolean writeConeDepth
    ) {
        float r = color.getRed() / 255.0F;
        float g = color.getGreen() / 255.0F;
        float b = color.getBlue() / 255.0F;
        float a = Math.min(1.0F, alpha);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(writeConeDepth);
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.lineWidth(2.0F);

        Matrix4f matrix = matrices.method_23760().method_23761();
        class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27379, class_290.field_1576);

        for (int i = 0; i < SEGMENTS; i++) {
            float x1 = radius * UNIT_X[i];
            float z1 = radius * UNIT_Z[i];
            float x2 = radius * UNIT_X[i + 1];
            float z2 = radius * UNIT_Z[i + 1];

            buffer.method_22918(matrix, x1, 0, z1).method_22915(r, g, b, a);
            buffer.method_22918(matrix, x2, 0, z2).method_22915(r, g, b, a);
            buffer.method_22918(matrix, 0, coneHeight, 0).method_22915(r, g, b, a);

            buffer.method_22918(matrix, 0, 0, 0).method_22915(r, g, b, a);
            buffer.method_22918(matrix, x2, 0, z2).method_22915(r, g, b, a);
            buffer.method_22918(matrix, x1, 0, z1).method_22915(r, g, b, a);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
        buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29345, class_290.field_1576);
        matrix = matrices.method_23760().method_23761();

        for (int i = 0; i <= SEGMENTS; i++) {
            buffer.method_22918(matrix, radius * UNIT_X[i], 0, radius * UNIT_Z[i]).method_22915(r, g, b, 1.0F);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.method_60800());

        RenderSystem.lineWidth(1.0F);
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static float[] createCircleAxis(boolean cosine) {
        float[] values = new float[SEGMENTS + 1];
        for (int i = 0; i <= SEGMENTS; i++) {
            double angle = Math.PI * 2.0 * i / SEGMENTS;
            values[i] = (float)(cosine ? Math.cos(angle) : Math.sin(angle));
        }
        return values;
    }

    private static ColorRGBA getDefaultColor() {
        return FeverVisual.getInstance()
                .getThemeManager()
                .getCurrentTheme()
                .getAdditionalColor();
    }

}
