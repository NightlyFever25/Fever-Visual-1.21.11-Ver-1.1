package fever.visual.systems.modules.modules.visuals.cosmetic;
//Да давай пасти бездарность :)
//Made by FeverVisuals (NightlyFever)
import fever.visual.FeverVisual;
import net.minecraft.class_2960;

public enum CustomModelType {
    CRAZY_RABBIT("Безумный кролик", FeverVisual.id("custom_models/rabbit.png"), ModelKey.RABBIT),
    WHITE_DEMON("Белый демон", FeverVisual.id("custom_models/whitedemon.png"), ModelKey.DEMON),
    RED_DEMON("Красный демон", FeverVisual.id("custom_models/reddemon.png"), ModelKey.DEMON),
    FREDDY_BEAR("Фредди медведь", FeverVisual.id("custom_models/freddy.png"), ModelKey.FREDDY),
    AMOGUS("Амогус", FeverVisual.id("custom_models/amogus.png"), ModelKey.AMOGUS);

    private final String displayName;
    private final class_2960 texture;
    private final ModelKey modelKey;

    CustomModelType(String displayName, class_2960 texture, ModelKey modelKey) {
        this.displayName = displayName;
        this.texture = texture;
        this.modelKey = modelKey;
    }

    public String getDisplayName() {
        return displayName;
    }

    public class_2960 getTexture() {
        return texture;
    }

    public ModelKey getModelKey() {
        return modelKey;
    }

    public enum ModelKey {
        RABBIT, DEMON, FREDDY, AMOGUS
    }
}