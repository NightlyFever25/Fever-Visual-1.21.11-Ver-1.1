package fever.visual.systems.modules.modules.visuals;

import fever.visual.framework.msdf.Fonts;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.PreHudRenderEvent;
import fever.visual.systems.localization.Localizator;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.render.Utils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1802;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@ModuleInfo(name = "TNT Timer", category = ModuleCategory.VISUALS, desc = "modules.descriptions.tnt_timer")
public class TNTTimer extends BaseModule {
   private final List<class_1541> visibleTnt = new ArrayList<>();
   private final EventListener<PreHudRenderEvent> onHudRenderEvent = event -> {
      class_4587 matrices = event.getContext().getMatrices();
      this.visibleTnt.clear();
      for (class_1297 entity : mc.field_1687.method_18112()) {
         if (entity instanceof class_1541 tnt) {
            this.visibleTnt.add(tnt);
         }
      }

      for (class_1541 tnt : this.visibleTnt) {
         this.renderBack(event, matrices, tnt);
      }
      for (class_1541 tnt : this.visibleTnt) {
         this.renderText(event, matrices, tnt);
      }

   };

   private void renderBack(PreHudRenderEvent event, class_4587 matrices, class_1541 entity) {
      String text = this.getTimerText(entity);
      class_243 renderPos = entity.method_30950(event.getTickDelta()).method_1031(0.0, 0.5, 0.0);
      class_241 screenPos = Utils.worldToScreen(renderPos);
      if (screenPos != null) {
         float distance = (float)mc.field_1724.method_73189().method_1022(renderPos);
         float scale = class_3532.method_15363(1.0F - distance / 20.0F, 0.5F, 1.0F);
         matrices.method_22903();
         matrices.method_46416(screenPos.field_1343 - 6.0F, screenPos.field_1342, 0.0F);
         matrices.method_22905(scale, scale, 1.0F);
         int width = (int)Fonts.MEDIUM.getFont(11.0F).width(text);
         int x = -width / 2;
         event.getContext().drawRect(x - 3, 1.0F, width + 26, Fonts.MEDIUM.getFont(11.0F).height() + 8.0F, new ColorRGBA(0.0F, 0.0F, 0.0F, 100.0F));
         matrices.method_22909();
      }
   }

   private void renderText(PreHudRenderEvent event, class_4587 matrices, class_1541 entity) {
      String text = this.getTimerText(entity);
      class_243 renderPos = entity.method_30950(event.getTickDelta()).method_1031(0.0, 0.5, 0.0);
      class_241 screenPos = Utils.worldToScreen(renderPos);
      if (screenPos != null) {
         float distance = (float)mc.field_1724.method_73189().method_1022(renderPos);
         float scale = class_3532.method_15363(1.0F - distance / 20.0F, 0.5F, 1.0F);
         matrices.method_22903();
         matrices.method_46416(screenPos.field_1343 - 6.0F, screenPos.field_1342, 0.0F);
         matrices.method_22905(scale, scale, 1.0F);
         int width = (int)Fonts.MEDIUM.getFont(11.0F).width(text);
         int x = -width / 2;
         event.getContext().drawText(Fonts.MEDIUM.getFont(11.0F), text, x + 16, 5.0F, ColorRGBA.WHITE);
         event.getContext().drawItem(class_1802.field_8626, (float)x, 3.0F, 0.75F);
         matrices.method_22909();
      }
   }

   private String getTimerText(class_1541 entity) {
      float seconds = Math.max(0.0F, entity.method_6969() / 20.0F);
      return String.format(Locale.ROOT, "%.1f %s", seconds, Localizator.translate("sec"));
   }
}
