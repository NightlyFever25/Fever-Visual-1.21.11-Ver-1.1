package fever.visual.systems.modules.modules.other;

import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.event.impl.player.InputEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.notifications.NotificationType;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.utility.game.ItemUtility;
import fever.visual.utility.game.server.ServerUtility;
import fever.visual.utility.inventory.InventoryUtility;
import fever.visual.utility.inventory.ItemSlot;
import fever.visual.utility.inventory.slots.HotbarSlot;
import fever.visual.utility.time.Timer;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2856;
import net.minecraft.class_2856.class_2857;
import net.minecraft.class_310;
import net.minecraft.class_3944;
import net.minecraft.class_7439;
import net.minecraft.class_8673.class_9058;

@ModuleInfo(name = "Server Helper", category = ModuleCategory.MISC, desc = "modules.descriptions.server_helper")
public class ServerHelper extends BaseModule {
   private final BooleanSupplier rwCondition = () -> ServerUtility.isHW()
           || ServerUtility.isPastaFT()
           || ServerUtility.isCM()
           || ServerUtility.isSaturn()
           || ServerUtility.isIntave();
   private final BooleanSupplier ftCondition = () -> ServerUtility.isHW()
           || ServerUtility.isRW()
           || ServerUtility.isCM()
           || ServerUtility.isSaturn()
           || ServerUtility.isIntave();
   private final BooleanSupplier hwCondition = () -> ServerUtility.isPastaFT()
           || ServerUtility.isRW()
           || ServerUtility.isCM()
           || ServerUtility.isSaturn()
           || ServerUtility.isIntave();
   private final BooleanSetting spoof = new BooleanSetting(this, "modules.settings.server_helper.spoof", "modules.settings.server_helper.spoof.description", this.rwCondition);
   private final BooleanSetting closeMenu = new BooleanSetting(this, "modules.settings.server_helper.close_menu", "modules.settings.server_helper.close_menu.description", this.rwCondition)
           .enable();
   private final BooleanSetting autoFix = new BooleanSetting(this, "modules.settings.server_helper.auto_fix", this.rwCondition);
   private final BooleanSetting warnArmor = new BooleanSetting(this, "modules.settings.server_helper.warn_armor", "modules.settings.server_helper.warn_armor.description");
   private final BooleanSetting autoZako = new BooleanSetting(this, "modules.settings.server_helper.auto_zako", this.hwCondition);
   private final Timer timer = new Timer();
   private boolean zakoCommandSent = true;
   private boolean visible;
   private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
      if (this.autoZako.isEnabled() && event.getPacket() instanceof class_7439 packetx) {
         String message = packetx.comp_763().getString();
         if (message.contains("Вы уже активировали этот промокод")) {
            this.zakoCommandSent = false;
            this.timer.reset();
         } else if (message.contains("Прямо сейчас идет набор")) {
            this.zakoCommandSent = true;
         }
      }

      if (this.closeMenu.isEnabled() && event.getPacket() instanceof class_3944 packetxxx) {
         String title = packetxxx.method_17594().getString();
         if (title.contains("Меню") || title.contains("ꈁꀀꈂꌁꈂꀁ")) {
            mc.field_1724.method_3137();
            event.cancel();
         }
      }
   };
   private Timer chargeTimer = new Timer();
   private ItemSlot previousSlot = null;
   private boolean isCharging = false;
   private boolean needsSlotSwapBack = false;
   private final EventListener<ClientPlayerTickEvent> onTick = event -> {};

   @Override
   public void tick() {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (this.warnArmor.isEnabled()) {
            float armorPoint = 1.0F;

            for (int armorSlot = 36; armorSlot < 40; armorSlot++) {
               class_1799 stack = mc.field_1724.method_31548().method_5438(armorSlot);
               if (!stack.method_7960()) {
                  float maxDamage = stack.method_7936();
                  float currentDamage = maxDamage - stack.method_7919();
                  armorPoint = currentDamage / maxDamage;
               }
            }

            if (armorPoint < 0.36) {
               if (this.visible) {
                  FeverVisual.getInstance().getNotificationManager().addNotificationOther(NotificationType.INFO, "modules.server_helper.armor_break_title", "modules.server_helper.armor_break_message");
                  this.visible = false;
               }}}
         if (this.autoFix.isEnabled() && !ServerUtility.hasCT) {
            class_1661 inventory = mc.field_1724.method_31548();

            for (int i = 0; i < inventory.method_5439(); i++) {
               class_1799 stackx = inventory.method_5438(i);
               if (!stackx.method_7960() && stackx.method_7963()) {
                  float maxDamage = stackx.method_7936();
                  float currentDamage = maxDamage - stackx.method_7919();
                  if (currentDamage / maxDamage > 0.5F && mc.field_1724.field_6012 % 25 == 0) {
                     mc.field_1724.field_3944.method_45730("fix all");
                     break;
                  }
               }
            }
         }

         if (this.spoof.isEnabled() && this.spoof.isVisible() && mc.field_1724.field_6012 > 20 && mc.field_1755 instanceof class_9058) {
            mc.field_1724.field_3944.method_52787(new class_2856(mc.field_1724.method_5667(), class_2857.field_13016));
            mc.field_1724.field_3944.method_52787(new class_2856(mc.field_1724.method_5667(), class_2857.field_13017));
            mc.field_1724.method_3137();
         }

         if (this.autoZako.isEnabled() && this.timer.finished(500L) && this.zakoCommandSent) {
            this.zakoCommandSent = false;
            mc.field_1724.field_3944.method_45730("zako");
         }

         super.tick();
      }
   }

   public void stop() {
      if (this.isCharging) {
         class_310.method_1551().field_1690.field_1904.method_23481(false);
         this.isCharging = false;
      }

      if (this.previousSlot != null && this.previousSlot instanceof HotbarSlot hotbarSlot) {
         InventoryUtility.selectHotbarSlot(hotbarSlot);
         this.previousSlot = null;
      }

      this.needsSlotSwapBack = false;
   }
}
