package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.BufferRenderer;
import fever.visual.utility.render.compat.GlStateManager;
import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.EntityDeathEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import net.minecraft.class_10042;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import net.minecraft.class_922;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(name = "Model Collapse", category = ModuleCategory.VISUALS, desc = "Entity model collapse")
public class ModelCollapse extends BaseModule {
   private final ModeSetting breakMode = new ModeSetting(this, "Break Direction");
   private final ModeSetting.Value bottomUp = new ModeSetting.Value(this.breakMode, "Bottom Up").select();
   private final ModeSetting.Value topDown = new ModeSetting.Value(this.breakMode, "Top Down");
   private final SliderSetting waveTime = new SliderSetting(this, "Wave")
           .min(100.0F).max(1000.0F).step(25.0F).currentValue(350.0F);
   private final SliderSetting cubeSize = new SliderSetting(this, "Cube Size")
           .min(0.03F).max(0.12F).step(0.005F).currentValue(0.055F);
   private final SliderSetting impulse = new SliderSetting(this, "Impulse")
           .min(0.0F).max(3.0F).step(0.05F).currentValue(1.0F);
   private final SliderSetting lifeTime = new SliderSetting(this, "Lifetime")
           .min(1.0F).max(15.0F).step(0.5F).currentValue(6.0F);

   private final List<Collapse> collapses = new CopyOnWriteArrayList<>();

   private final EventListener<EntityDeathEvent> onDeath = event -> {
      class_1309 entity = event.getEntity();
      if (entity == null || entity == mc.field_1724 || this.isInvisible(entity)) {
         return;
      }
      this.collapses.add(Collapse.create(entity, this.cubeSize.getCurrentValue()));
      while (this.collapses.size() > 8) {
         this.collapses.remove(0);
      }
   };

   private final EventListener<Render3DEvent> onRender = event -> {
      if (this.collapses.isEmpty()) {
         return;
      }
      class_4587 matrices = event.getMatrices();
      class_243 cameraPos = event.getCamera().method_71156();
      long now = System.currentTimeMillis();
      float lifeMs = this.lifeTime.getCurrentValue() * 1000.0F;
      float force = this.impulse.getCurrentValue();
      float waveMs = this.waveTime.getCurrentValue();
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      RenderSystem.enableDepthTest();
      RenderSystem.depthFunc(GL11.GL_LEQUAL);
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      try {
         for (Collapse collapse : this.collapses) {
            float t = (now - collapse.startedAt) / Math.max(1.0F, lifeMs);
            if (t >= 1.0F) {
               this.collapses.remove(collapse);
               continue;
            }
            collapse.render(matrices, cameraPos, class_3532.method_15363(t, 0.0F, 1.0F), lifeMs, waveMs, force, this.topDown.isSelected());
         }
      } finally {
         RenderSystem.depthMask(true);
         RenderSystem.defaultBlendFunc();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
      }
   };

   @Override
   public void onDisable() {
      this.collapses.clear();
   }

   private boolean isInvisible(class_1309 entity) {
      return entity.method_6059(class_1294.field_5905)
              || entity.method_5767()
              || mc.field_1724 != null && entity.method_5756(mc.field_1724);
   }

   private static final class Collapse {
      private final class_243 pos;
      private final float bodyYaw;
      private final float width;
      private final float height;
      private final class_2960 texture;
      private final Part[] parts;
      private final long startedAt = System.currentTimeMillis();

      private Collapse(class_243 pos, float bodyYaw, float width, float height, class_2960 texture, Part[] parts) {
         this.pos = pos;
         this.bodyYaw = bodyYaw;
         this.width = width;
         this.height = height;
         this.texture = texture;
         this.parts = parts;
      }

      static Collapse create(class_1309 entity, float cubeSize) {
         float width = Math.max(entity.method_17681(), 0.35F);
         float height = Math.max(entity.method_17682(), 0.6F);
         class_2960 texture = resolveTexture(entity);
         ThreadLocalRandom random = ThreadLocalRandom.current();
         List<Part> generated = new ArrayList<>();
         addCuboid(generated, random, new class_243(0.0D, 1.68D, 0.0D), new class_243(0.50D, 0.50D, 0.50D), width, height, cubeSize, 8.0F / 64.0F, 8.0F / 64.0F, 16.0F / 64.0F, 16.0F / 64.0F);
         addCuboid(generated, random, new class_243(0.0D, 1.15D, 0.0D), new class_243(0.60D, 0.55D, 0.28D), width, height, cubeSize, 20.0F / 64.0F, 20.0F / 64.0F, 28.0F / 64.0F, 32.0F / 64.0F);
         addCuboid(generated, random, new class_243(-0.48D, 1.14D, 0.0D), new class_243(0.22D, 0.50D, 0.24D), width, height, cubeSize, 44.0F / 64.0F, 20.0F / 64.0F, 48.0F / 64.0F, 32.0F / 64.0F);
         addCuboid(generated, random, new class_243(0.48D, 1.14D, 0.0D), new class_243(0.22D, 0.50D, 0.24D), width, height, cubeSize, 36.0F / 64.0F, 52.0F / 64.0F, 40.0F / 64.0F, 64.0F / 64.0F);
         addCuboid(generated, random, new class_243(-0.16D, 0.43D, 0.0D), new class_243(0.26D, 0.90D, 0.24D), width, height, cubeSize, 4.0F / 64.0F, 20.0F / 64.0F, 8.0F / 64.0F, 32.0F / 64.0F);
         addCuboid(generated, random, new class_243(0.16D, 0.43D, 0.0D), new class_243(0.26D, 0.90D, 0.24D), width, height, cubeSize, 20.0F / 64.0F, 52.0F / 64.0F, 24.0F / 64.0F, 64.0F / 64.0F);
         Part[] parts = generated.toArray(Part[]::new);
         return new Collapse(entity.method_73189(), entity.field_6283, width, height, texture, parts);
      }

      void render(class_4587 matrices, class_243 cameraPos, float t, float lifeMs, float waveMs, float force, boolean topDown) {
         float elapsedMs = t * lifeMs;
         float alpha = class_3532.method_15363((1.0F - t) / 0.18F, 0.0F, 1.0F);
         if (alpha <= 0.01F || this.parts.length == 0) {
            return;
         }
         RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
         RenderSystem.setShaderTexture(0, this.texture);
         class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
         Matrix4f matrix = matrices.method_23760().method_23761();
         for (int i = 0; i < this.parts.length; i++) {
            Part part = this.parts[i];
            float heightProgress = class_3532.method_15363((float)(part.local.field_1351 / Math.max(0.01F, this.height)), 0.0F, 1.0F);
            float releaseMs = waveMs * (topDown ? 1.0F - heightProgress : heightProgress);
            float seconds = Math.max(0.0F, elapsedMs - releaseMs) / 1000.0F;
            class_243 local = part.local;
            if (seconds > 0.0F) {
               float landingSeconds = landingTime(part, force);
               float simulatedSeconds = Math.min(seconds, landingSeconds);
               local = local.method_1019(part.velocity.method_1021(simulatedSeconds * 0.95D * force))
                     .method_1031(0.0D, -5.4D * simulatedSeconds * simulatedSeconds, 0.0D);
            }
            class_243 world = transform(this.pos, this.bodyYaw, local);
            class_243 radial = new class_243(world.field_1352 - this.pos.field_1352, 0.0D, world.field_1350 - this.pos.field_1350);
            double maxRadius = Math.max(0.65D, this.width * 1.45D);
            if (radial.method_1027() > maxRadius * maxRadius) {
               radial = radial.method_1029().method_1021(maxRadius);
               world = new class_243(this.pos.field_1352 + radial.field_1352, world.field_1351, this.pos.field_1350 + radial.field_1350);
            }
            double floor = this.pos.field_1351 + part.size.field_1351 * 0.5D;
            if (world.field_1351 < floor) {
               world = new class_243(world.field_1352, floor, world.field_1350);
            }
            class_243 center = world.method_1020(cameraPos);
            class_243 size = part.size.method_1021(1.0D - t * 0.10D);
            emitTexturedCube(buffer, matrix, center, size, part.u1, part.v1, part.u2, part.v2, new ColorRGBA(255.0F, 255.0F, 255.0F, 255.0F * alpha));
         }
         class_9801 built = buffer.method_60794();
         if (built != null) {
            BufferRenderer.drawWithGlobalProgram(built);
         }
      }

      private static float landingTime(Part part, float force) {
         double start = Math.max(0.0D, part.local.field_1351 - part.size.field_1351 * 0.5D);
         double verticalVelocity = part.velocity.field_1351 * 0.95D * force;
         double discriminant = verticalVelocity * verticalVelocity + 21.6D * start;
         return (float)Math.max(0.0D, (verticalVelocity + Math.sqrt(Math.max(0.0D, discriminant))) / 10.8D);
      }

      private static void addCuboid(List<Part> parts, ThreadLocalRandom random, class_243 center, class_243 size, float width, float height, float cubeSize, float minU, float minV, float maxU, float maxV) {
         double w = width / 0.6D;
         double h = height / 1.95D;
         class_243 scaledCenter = new class_243(center.field_1352 * w, center.field_1351 * h, center.field_1350 * w);
         class_243 scaledSize = new class_243(size.field_1352 * w, size.field_1351 * h, Math.max(size.field_1350 * w, width * 0.16D));
         int xCount = class_3532.method_15340((int)Math.ceil(scaledSize.field_1352 / cubeSize), 1, 12);
         int yCount = class_3532.method_15340((int)Math.ceil(scaledSize.field_1351 / cubeSize), 1, 20);
         int zCount = class_3532.method_15340((int)Math.ceil(scaledSize.field_1350 / cubeSize), 1, 10);
         class_243 cell = new class_243(scaledSize.field_1352 / xCount, scaledSize.field_1351 / yCount, scaledSize.field_1350 / zCount);
         for (int xi = 0; xi < xCount; xi++) {
            for (int yi = 0; yi < yCount; yi++) {
               for (int zi = 0; zi < zCount; zi++) {
                  class_243 local = scaledCenter.method_1031(
                     -scaledSize.field_1352 * 0.5D + cell.field_1352 * (xi + 0.5D),
                     -scaledSize.field_1351 * 0.5D + cell.field_1351 * (yi + 0.5D),
                     -scaledSize.field_1350 * 0.5D + cell.field_1350 * (zi + 0.5D)
                  );
                  class_243 outward = new class_243(local.field_1352, local.field_1351 - scaledCenter.field_1351, local.field_1350);
                  if (outward.method_1027() < 1.0E-5D) {
                     outward = new class_243(random.nextDouble(-0.5D, 0.5D), random.nextDouble(0.0D, 0.5D), random.nextDouble(-0.5D, 0.5D));
                  }
                  outward = outward.method_1029();
                  class_243 velocity = outward.method_1021(random.nextDouble(0.035D, 0.13D)).method_1031(
                     random.nextDouble(-0.025D, 0.025D),
                     random.nextDouble(0.045D, 0.17D),
                     random.nextDouble(-0.025D, 0.025D)
                  );
                  float u1 = class_3532.method_16439((float)xi / xCount, minU, maxU);
                  float u2 = class_3532.method_16439((float)(xi + 1) / xCount, minU, maxU);
                  float v1 = class_3532.method_16439((float)yi / yCount, minV, maxV);
                  float v2 = class_3532.method_16439((float)(yi + 1) / yCount, minV, maxV);
                  parts.add(new Part(local, cell.method_1021(0.92D), velocity, random.nextFloat() * 140.0F - 70.0F, u1, v1, u2, v2, random.nextDouble()));
               }
            }
         }
      }

      @SuppressWarnings({"unchecked", "rawtypes"})
      private static class_2960 resolveTexture(class_1309 entity) {
         class_897 renderer = mc.method_1561().method_3953(entity);
         if (renderer instanceof class_922<?, ?, ?> livingRendererRaw) {
            class_922 livingRenderer = livingRendererRaw;
            class_10042 state = (class_10042)livingRenderer.method_55269();
            livingRenderer.method_62355(entity, state, mc.method_61966().method_60637(false));
            return livingRenderer.method_3885(state);
         }
         return class_2960.method_60656("textures/entity/player/wide/steve.png");
      }

      private static void emitTexturedCube(class_287 buffer, Matrix4f matrix, class_243 c, class_243 s, float u1, float v1, float u2, float v2, ColorRGBA color) {
         float x1 = (float)(c.field_1352 - s.field_1352 * 0.5D);
         float y1 = (float)(c.field_1351 - s.field_1351 * 0.5D);
         float z1 = (float)(c.field_1350 - s.field_1350 * 0.5D);
         float x2 = (float)(c.field_1352 + s.field_1352 * 0.5D);
         float y2 = (float)(c.field_1351 + s.field_1351 * 0.5D);
         float z2 = (float)(c.field_1350 + s.field_1350 * 0.5D);
         int rgba = color.getRGB();
         quad(buffer, matrix, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, u1, v1, u2, v2, rgba);
         quad(buffer, matrix, x2, y1, z1, x1, y1, z1, x1, y2, z1, x2, y2, z1, u1, v1, u2, v2, rgba);
         quad(buffer, matrix, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, u1, v1, u2, v2, rgba);
         quad(buffer, matrix, x2, y1, z2, x2, y1, z1, x2, y2, z1, x2, y2, z2, u1, v1, u2, v2, rgba);
         quad(buffer, matrix, x1, y2, z2, x2, y2, z2, x2, y2, z1, x1, y2, z1, u1, v1, u2, v2, rgba);
         quad(buffer, matrix, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, u1, v1, u2, v2, rgba);
      }

      private static void quad(class_287 buffer, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float u1, float v1, float u2, float v2, int color) {
         buffer.method_22918(matrix, x1, y1, z1).method_22913(u1, v2).method_39415(color);
         buffer.method_22918(matrix, x2, y2, z2).method_22913(u2, v2).method_39415(color);
         buffer.method_22918(matrix, x3, y3, z3).method_22913(u2, v1).method_39415(color);
         buffer.method_22918(matrix, x4, y4, z4).method_22913(u1, v1).method_39415(color);
      }

      private static class_243 transform(class_243 origin, float yaw, class_243 local) {
         float radians = (float)Math.toRadians(yaw);
         class_243 forward = new class_243(-class_3532.method_15374(radians), 0.0D, class_3532.method_15362(radians));
         class_243 right = new class_243(class_3532.method_15362(radians), 0.0D, class_3532.method_15374(radians));
         return origin.method_1019(right.method_1021(local.field_1352)).method_1031(0.0D, local.field_1351, 0.0D).method_1019(forward.method_1021(local.field_1350));
      }

   }

   private record Part(class_243 local, class_243 size, class_243 velocity, float spin, float u1, float v1, float u2, float v2, double bouncePhase) {
   }
}
