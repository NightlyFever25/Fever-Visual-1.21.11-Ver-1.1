package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.render.Utils;
import fever.visual.utility.game.EntityUtility;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import fever.visual.utility.render.compat.BufferRenderer;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5498;

@ModuleInfo(
        name = "Custom Hitbox",
        category = ModuleCategory.COMBAT,
        desc = "modules.descriptions.custom_hitbox"
)
public class CustomHitbox extends BaseModule implements IMinecraft {

    private final ModeSetting hitboxColorMode = new ModeSetting(this, "modules.settings.custom_hitbox.hitbox_color_mode");
    private final ModeSetting.Value hitboxColorTheme = new ModeSetting.Value(this.hitboxColorMode, "modules.settings.custom_hitbox.color_mode.theme").select();
    private final ModeSetting.Value hitboxColorCustom = new ModeSetting.Value(this.hitboxColorMode, "modules.settings.custom_hitbox.color_mode.custom");
    private final ColorSetting hitboxColor = new ColorSetting(this, "modules.settings.custom_hitbox.hitbox_color", () -> !this.hitboxColorCustom.isSelected())
            .color(new ColorRGBA(253.0F, 0.0F, 0.0F, 144.0F))
            .alpha(true);
    private final ColorSetting hitboxColorSecond = new ColorSetting(this, "modules.settings.custom_hitbox.hitbox_color_second", () -> !this.hitboxColorCustom.isSelected())
            .color(new ColorRGBA(255.0F, 96.0F, 96.0F, 160.0F))
            .alpha(true);
    private final ModeSetting boxColorMode = new ModeSetting(this, "modules.settings.custom_hitbox.box_color_mode");
    private final ModeSetting.Value boxColorTheme = new ModeSetting.Value(this.boxColorMode, "modules.settings.custom_hitbox.color_mode.theme").select();
    private final ModeSetting.Value boxColorCustom = new ModeSetting.Value(this.boxColorMode, "modules.settings.custom_hitbox.color_mode.custom");
    private final ColorSetting boxColor1 = new ColorSetting(this, "modules.settings.custom_hitbox.box_color", () -> !this.boxColorCustom.isSelected())
            .color(new ColorRGBA(253.0F, 0.0F, 0.0F, 96.0F))
            .alpha(true);
    private final ColorSetting boxColor2 = new ColorSetting(this, "modules.settings.custom_hitbox.box_color_second", () -> !this.boxColorCustom.isSelected())
            .color(new ColorRGBA(255.0F, 96.0F, 96.0F, 160.0F))
            .alpha(true);
    private final SelectSetting entitySelection = new SelectSetting(this, "modules.settings.custom_hitbox.entity_types").min(1);
    private final SelectSetting.Value self        = new SelectSetting.Value(this.entitySelection, "modules.settings.custom_hitbox.entity_types.self").select();
    private final SelectSetting.Value players     = new SelectSetting.Value(this.entitySelection, "modules.settings.custom_hitbox.entity_types.players").select();
    private final SelectSetting.Value mobs        = new SelectSetting.Value(this.entitySelection, "modules.settings.custom_hitbox.entity_types.mobs").select();
    private final SelectSetting.Value animals     = new SelectSetting.Value(this.entitySelection, "modules.settings.custom_hitbox.entity_types.animals").select();
    private final SelectSetting.Value armorStands = new SelectSetting.Value(this.entitySelection, "modules.settings.custom_hitbox.entity_types.armor_stands").select();
    private final List<class_1297> visibleEntities = new ArrayList<>();

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (!EntityUtility.isInGame()) return;
        if (this.hasVisionBlockingEffect()) return;

        class_4587 matrices = event.getMatrices();
        matrices.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);

        this.visibleEntities.clear();
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (this.shouldRenderHitbox(entity) && this.isInFieldOfView(entity, event.getTickDelta())) {
                this.visibleEntities.add(entity);
            }
        }

        if (!this.visibleEntities.isEmpty()) {
            ColorRGBA[] gradientColors = this.createGradientColors();
            ColorRGBA[] hitboxColors = this.createHitboxColors();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            class_287 fillBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);
            for (class_1297 entity : this.visibleEntities) {
                this.appendBox(matrices, entity, event.getTickDelta(), fillBuffer, gradientColors, false);
            }
            BufferRenderer.drawWithGlobalProgram(fillBuffer.method_60800());

            RenderSystem.lineWidth(3.0F);
            class_287 lineBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);
            for (class_1297 entity : this.visibleEntities) {
                this.appendBox(matrices, entity, event.getTickDelta(), lineBuffer, hitboxColors, true);
            }
            BufferRenderer.drawWithGlobalProgram(lineBuffer.method_60800());
        }

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1.0F);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        matrices.method_22909();
    };

    public ColorRGBA getHitboxColor() {
        return this.getHitboxColor(0.0F);
    }

    public ColorRGBA getBoxColor1() {
        return this.getBoxColor(0.0F);
    }

    public ColorRGBA getBoxColor2() {
        return this.getBoxColor(20.0F);
    }

    public boolean shouldRenderHitbox(class_1297 entity) {
        if (entity instanceof class_1309 living && entity != mc.field_1724 && this.isInvisible(living)) {
            return false;
        }

        if (entity instanceof class_1657 player) {
            if (entity == mc.field_1724 && mc.field_1690.method_31044() == class_5498.field_26664) {
                return false;
            }
            return (this.self.isSelected() && entity == mc.field_1724)
                    || (this.players.isSelected() && entity != mc.field_1724);
        }
        if (entity instanceof class_1296) return this.animals.isSelected();
        if (entity instanceof class_1308)    return this.mobs.isSelected();
        if (entity instanceof class_1531) return this.armorStands.isSelected();
        return false;
    }

    private boolean isInvisible(class_1309 entity) {
        if (entity.method_6059(class_1294.field_5905)) return true;
        if (entity.method_5767()) return true;
        if (mc.field_1724 != null && entity.method_5756(mc.field_1724)) return true;
        return false;
    }

    private boolean hasVisionBlockingEffect() {
        return mc.field_1724 != null
                && (mc.field_1724.method_6059(class_1294.field_5919)
                || mc.field_1724.method_6059(class_1294.field_38092));
    }

    @Nullable
    public static CustomHitbox getModule() {
        if (FeverVisual.getInstance().getModuleManager() == null) return null;
        return FeverVisual.getInstance().getModuleManager().getModuleSafe(CustomHitbox.class);
    }

    private boolean isInFieldOfView(class_1297 entity, float partialTicks) {
        class_4184 camera = mc.field_1773.method_19418();
        double ex = entity.field_6038 + (entity.method_23317() - entity.field_6038) * partialTicks;
        double ey = entity.field_5971 + (entity.method_23318() - entity.field_5971) * partialTicks + entity.method_17682() * 0.5;
        double ez = entity.field_5989 + (entity.method_23321() - entity.field_5989) * partialTicks;
        return Utils.isInViewCone(camera, ex, ey, ez, 0.20, Math.max(1.0, entity.method_17681()));
    }

    private void appendBox(class_4587 matrices, class_1297 target, float partialTicks, class_287 buffer, ColorRGBA[] colors, boolean outline) {
        if (target == null) return;

        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        double x = target.field_6038 + (target.method_23317() - target.field_6038) * partialTicks;
        double y = target.field_5971 + (target.method_23318() - target.field_5971) * partialTicks;
        double z = target.field_5989 + (target.method_23321() - target.field_5989) * partialTicks;

        class_238 bb = target.method_5829();
        double minX = bb.field_1323 - target.method_23317() + x - cameraPos.field_1352;
        double minY = bb.field_1322 - target.method_23318() + y - cameraPos.field_1351;
        double minZ = bb.field_1321 - target.method_23321() + z - cameraPos.field_1350;
        double maxX = bb.field_1320 - target.method_23317() + x - cameraPos.field_1352;
        double maxY = bb.field_1325 - target.method_23318() + y - cameraPos.field_1351;
        double maxZ = bb.field_1324 - target.method_23321() + z - cameraPos.field_1350;

        Matrix4f matrix = matrices.method_23760().method_23761();
        if (outline) {
            drawBoxOutline(buffer, matrix, minX, minY + 0.01, minZ, maxX, maxY, maxZ, colors);
        } else {
            drawBoxFill(buffer, matrix, minX, minY + 0.01, minZ, maxX, maxY, maxZ, colors, 85);
        }
    }

    private ColorRGBA[] createGradientColors() {
        ColorRGBA start = this.getBoxColor(0.0F);
        ColorRGBA end = this.getBoxColor(20.0F);
        return new ColorRGBA[] {
                start.withAlpha(start.getAlpha() * 0.35F), end.withAlpha(end.getAlpha() * 0.60F),
                start.withAlpha(start.getAlpha() * 0.35F), end.withAlpha(end.getAlpha() * 0.60F)
        };
    }

    private ColorRGBA[] createHitboxColors() {
        return new ColorRGBA[] {
                this.getHitboxColor(0.0F), this.getHitboxColor(20.0F),
                this.getHitboxColor(40.0F), this.getHitboxColor(60.0F)
        };
    }

    private ColorRGBA getHitboxColor(float index) {
        if (this.hitboxColorCustom.isSelected()) {
            return this.hitboxColor.getColorSafe().mix(this.hitboxColorSecond.getColorSafe(), (index % 60.0F) / 59.0F);
        }

        return Colors.getAccentColor(index * 6.0F);
    }

    private ColorRGBA getBoxColor(float index) {
        if (this.boxColorCustom.isSelected()) {
            return this.boxColor1.getColorSafe().mix(this.boxColor2.getColorSafe(), (index % 40.0F) / 39.0F);
        }

        return Colors.getAccentColor(index * 6.0F);
    }

    private void drawBoxFill(class_287 buffer, Matrix4f matrix,
                             double minX, double minY, double minZ,
                             double maxX, double maxY, double maxZ,
                             ColorRGBA[] colors, int fillAlpha) {
        int c0 = replAlpha(colors[0].getRGB(), fillAlpha);
        int c1 = replAlpha(colors[1].getRGB(), fillAlpha);
        int c2 = replAlpha(colors[2].getRGB(), fillAlpha);
        int c3 = replAlpha(colors[3].getRGB(), fillAlpha);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)maxZ).method_39415(c2);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)maxZ).method_39415(c2);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)maxZ).method_39415(c2);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)maxZ).method_39415(c2);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)minX, (float)minY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)maxZ).method_39415(c3);
        buffer.method_22918(matrix, (float)minX, (float)maxY, (float)minZ).method_39415(c0);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)maxZ).method_39415(c2);
        buffer.method_22918(matrix, (float)maxX, (float)minY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)minZ).method_39415(c1);
        buffer.method_22918(matrix, (float)maxX, (float)maxY, (float)maxZ).method_39415(c2);
    }

    private void drawBoxOutline(class_287 buffer, Matrix4f matrix,
                                double minX, double minY, double minZ,
                                double maxX, double maxY, double maxZ,
                                ColorRGBA[] colors) {
        int c0 = replAlpha(colors[0].getRGB(), 255);
        int c1 = replAlpha(colors[1].getRGB(), 255);
        int c2 = replAlpha(colors[2].getRGB(), 255);
        int c3 = replAlpha(colors[3].getRGB(), 255);
        drawLine(buffer, matrix, minX, minY, minZ, maxX, minY, minZ, c0, c1);
        drawLine(buffer, matrix, maxX, minY, minZ, maxX, minY, maxZ, c1, c2);
        drawLine(buffer, matrix, maxX, minY, maxZ, minX, minY, maxZ, c2, c3);
        drawLine(buffer, matrix, minX, minY, maxZ, minX, minY, minZ, c3, c0);
        drawLine(buffer, matrix, minX, maxY, minZ, maxX, maxY, minZ, c0, c1);
        drawLine(buffer, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, c1, c2);
        drawLine(buffer, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, c2, c3);
        drawLine(buffer, matrix, minX, maxY, maxZ, minX, maxY, minZ, c3, c0);
        drawLine(buffer, matrix, minX, minY, minZ, minX, maxY, minZ, c0, c0);
        drawLine(buffer, matrix, maxX, minY, minZ, maxX, maxY, minZ, c1, c1);
        drawLine(buffer, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, c2, c2);
        drawLine(buffer, matrix, minX, minY, maxZ, minX, maxY, maxZ, c3, c3);
    }

    private void drawLine(class_287 buffer, Matrix4f matrix,
                          double x1, double y1, double z1,
                          double x2, double y2, double z2,
                          int color1, int color2) {
        buffer.method_22918(matrix, (float)x1, (float)y1, (float)z1)
                .method_1336(color1 >> 16 & 0xFF, color1 >> 8 & 0xFF, color1 & 0xFF, color1 >> 24 & 0xFF);
        buffer.method_22918(matrix, (float)x2, (float)y2, (float)z2)
                .method_1336(color2 >> 16 & 0xFF, color2 >> 8 & 0xFF, color2 & 0xFF, color2 >> 24 & 0xFF);
    }

    private int replAlpha(int color, int alpha) {
        return alpha << 24 | (color >> 16 & 0xFF) << 16 | (color >> 8 & 0xFF) << 8 | (color & 0xFF);
    }
}
