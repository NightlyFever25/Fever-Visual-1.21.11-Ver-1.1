package fever.visual.systems.modules.modules.visuals.littlePet;

import net.minecraft.class_1299;
import net.minecraft.class_1493;
import net.minecraft.class_1937;
import net.minecraft.class_4048;
import net.minecraft.class_4050;

public class GhostWolfEntity extends class_1493 {
    public GhostWolfEntity(class_1299<? extends class_1493> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected class_4048 method_55694(class_4050 pose) {
        return class_4048.method_18385(0.0F, 0.0F);
    }


    @Override
    public boolean method_5732() {
        return false;
    }

    @Override
    public boolean method_5863() {
        return false;
    }
}
