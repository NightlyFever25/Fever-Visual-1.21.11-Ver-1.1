package fever.visual.systems.modules.modules.other;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.WorldChangeEvent;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.utility.time.Timer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_640;
import net.minecraft.class_7439;

@ModuleInfo(name = "Auto Duels", category = ModuleCategory.MISC, desc = "modules.descriptions.auto_duels")
public class AutoDuels extends BaseModule {
   private final ModeSetting mode = new ModeSetting(this, "modules.settings.auto_duels.mode");
   private final ModeSetting.Value anSoft = new ModeSetting.Value(this.mode, "modules.settings.auto_duels.mode.ansofters");
   private final ModeSetting.Value random = new ModeSetting.Value(this.mode, "modules.settings.auto_duels.mode.random");
   private final ModeSetting kit = new ModeSetting(this, "modules.settings.auto_duels.kit");
   private final ModeSetting.Value shield = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.shield");
   private final ModeSetting.Value shipi = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.shipi");
   private final ModeSetting.Value bow = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.bow");
   private final ModeSetting.Value totem = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.totem");
   private final ModeSetting.Value noDebaff = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.nodebaff");
   private final ModeSetting.Value balls = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.balls");
   private final ModeSetting.Value classik = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.classik");
   private final ModeSetting.Value cheats = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.cheats");
   private final ModeSetting.Value nezer = new ModeSetting.Value(this.kit, "modules.settings.auto_duels.kit.nezer");
   private final Timer count = new Timer();
   private final List<String> sent = new ArrayList<>();
   private final EventListener<ReceivePacketEvent> onReceive = event -> {
      if (event.getPacket() instanceof class_7439 packet) {
         String msg = packet.comp_763().getString();
         if (msg.contains("принял") && !msg.contains("не принял") || msg.contains("команды")) {
            this.sent.clear();
            this.toggle();
         }

         if (msg.contains("Баланс") || msg.contains("отключил запросы")) {
            event.cancel();
         }
      }
   };
   private final EventListener<WorldChangeEvent> world = e -> this.disable();

   @Override
   public void tick() {
      List<String> playerNames = new ArrayList<>();

      for (class_640 entry : mc.field_1724.field_3944.method_2880()) {
         playerNames.add(entry.method_2966().name());
      }

      if (this.random.isSelected()) {
         Collections.shuffle(playerNames);
      }

      for (String name : playerNames) {
         if (this.count.finished(750L) && !this.sent.contains(name) && !name.equals(mc.field_1724.method_5820())) {
            mc.field_1724.field_3944.method_45730("duel " + name);
            this.sent.add(name);
            this.count.reset();
         }
      }

      if (mc.field_1724.field_7512 instanceof class_1707) {
         String title = mc.field_1755.method_25440().getString();
         if (title.contains("Выбор набора")) {
            mc.field_1761
                    .method_2906(
                            mc.field_1724.field_7512.field_7763, this.kit.getValues().indexOf(this.kit.getRandomEnabledElement()), 0, class_1713.field_7790, mc.field_1724
                    );
            mc.field_1724.field_7512.method_7593(this.kit.getValues().indexOf(this.kit.getRandomEnabledElement()), 0, class_1713.field_7790, mc.field_1724);
         } else if (title.contains("Настройка поединка")) {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 0, 0, class_1713.field_7790, mc.field_1724);
            mc.field_1724.field_7512.method_7593(0, 0, class_1713.field_7790, mc.field_1724);
         }
      }

      super.tick();
   }

   @Override
   public void onEnable() {
      this.count.reset();
      super.onEnable();
   }
}
