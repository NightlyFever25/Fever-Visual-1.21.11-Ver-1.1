package fever.visual.systems.modules.modules.other;

import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_315;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_6597;

@ModuleInfo(name = "Optimization", category = ModuleCategory.MISC, desc = "modules.descriptions.optimization")
public class Optimization extends BaseModule {
    private final BooleanSetting vanillaParticles = new BooleanSetting(this, "modules.settings.optimization.vanilla_particles").enable();
    private final BooleanSetting farParticles = new BooleanSetting(this, "modules.settings.optimization.far_particles").enable();
    private final SliderSetting particleDistance = new SliderSetting(this, "modules.settings.optimization.particle_distance", () -> !this.farParticles.isEnabled())
            .min(16.0F).max(128.0F).step(1.0F).currentValue(48.0F).suffix("m");
    private final BooleanSetting rainParticles = new BooleanSetting(this, "modules.settings.optimization.rain_particles").enable();
    private final SliderSetting rainParticleDensity = new SliderSetting(this, "modules.settings.optimization.rain_particle_density", () -> !this.rainParticles.isEnabled())
            .min(5.0F).max(100.0F).step(5.0F).currentValue(35.0F).suffix("%");
    private final BooleanSetting cullFarEntities = new BooleanSetting(this, "modules.settings.optimization.cull_far_entities").enabled(false);
    private final SliderSetting entityDistance = new SliderSetting(this, "modules.settings.optimization.entity_distance", () -> !this.cullFarEntities.isEnabled())
            .min(32.0F).max(192.0F).step(1.0F).currentValue(96.0F).suffix("m");
    private final BooleanSetting wallEntityCulling = new BooleanSetting(this, "modules.settings.optimization.wall_entity_culling").enabled(false);
    private final SliderSetting wallEntityDistance = new SliderSetting(this, "modules.settings.optimization.wall_entity_distance", () -> !this.wallEntityCulling.isEnabled())
            .min(8.0F).max(96.0F).step(1.0F).currentValue(48.0F).suffix("m");
    private final BooleanSetting entityDistanceOption = new BooleanSetting(this, "modules.settings.optimization.entity_distance_option").enabled(false);
    private final SliderSetting entityDistanceScale = new SliderSetting(this, "modules.settings.optimization.entity_distance_scale", () -> !this.entityDistanceOption.isEnabled())
            .min(0.5F).max(1.0F).step(0.05F).currentValue(0.75F);
    private final BooleanSetting disableEntityShadows = new BooleanSetting(this, "modules.settings.optimization.entity_shadows").enabled(false);
    private final BooleanSetting fastClouds = new BooleanSetting(this, "modules.settings.optimization.fast_clouds").enabled(false);
    private final BooleanSetting asynchronousChunkUpdates = new BooleanSetting(this, "modules.settings.optimization.async_chunk_updates").enable();
    private final BooleanSetting reduceViewDistance = new BooleanSetting(this, "modules.settings.optimization.view_distance").enabled(false);
    private final SliderSetting viewDistance = new SliderSetting(this, "modules.settings.optimization.view_distance_value", () -> !this.reduceViewDistance.isEnabled())
            .min(4.0F).max(16.0F).step(1.0F).currentValue(10.0F);
    private final BooleanSetting reduceSimulationDistance = new BooleanSetting(this, "modules.settings.optimization.simulation_distance").enabled(false);
    private final SliderSetting simulationDistance = new SliderSetting(this, "modules.settings.optimization.simulation_distance_value", () -> !this.reduceSimulationDistance.isEnabled())
            .min(5.0F).max(16.0F).step(1.0F).currentValue(6.0F);
    private final BooleanSetting hideWeather = new BooleanSetting(this, "modules.settings.optimization.hide_weather").enabled(false);

    private class_4066 oldParticles;
    private Double oldEntityDistanceScale;
    private Boolean oldEntityShadows;
    private class_4063 oldCloudRenderMode;
    private class_6597 oldChunkBuilderMode;
    private Integer oldViewDistance;
    private Integer oldSimulationDistance;
    private boolean appliedParticles;
    private boolean appliedEntityDistance;
    private boolean appliedEntityShadows;
    private boolean appliedClouds;
    private boolean appliedChunkBuilderMode;
    private boolean appliedViewDistance;
    private boolean appliedSimulationDistance;
    private int particleCounter;
    private final Map<Integer, OcclusionCacheEntry> occlusionCache = new HashMap<>();

    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        this.applyOptions();
        if (!this.wallEntityCulling.isEnabled() || this.occlusionCache.size() > 2048) {
            this.occlusionCache.clear();
        }
    };

    @Override
    public void onEnable() {
        this.captureOptions();
        this.applyOptions();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.occlusionCache.clear();
        this.restoreOptions();
        super.onDisable();
    }

    private void captureOptions() {
        if (mc.field_1690 == null) {
            return;
        }

        class_315 options = mc.field_1690;
        this.oldParticles = options.method_42475().method_41753();
        this.oldEntityDistanceScale = options.method_42517().method_41753();
        this.oldEntityShadows = options.method_42435().method_41753();
        this.oldCloudRenderMode = options.method_42528().method_41753();
        this.oldChunkBuilderMode = options.method_41798().method_41753();
        this.oldViewDistance = options.method_42503().method_41753();
        this.oldSimulationDistance = options.method_42510().method_41753();
    }

    private void applyOptions() {
        if (mc.field_1690 == null) {
            return;
        }

        class_315 options = mc.field_1690;
        if (this.vanillaParticles.isEnabled()) {
            this.appliedParticles = true;
            if (options.method_42475().method_41753() == class_4066.field_18197) {
                options.method_42475().method_41748(class_4066.field_18198);
            }
        } else {
            this.restoreParticles(options);
        }

        if (this.entityDistanceOption.isEnabled()) {
            this.appliedEntityDistance = true;
            double target = this.entityDistanceScale.getCurrentValue();
            if (Math.abs(options.method_42517().method_41753() - target) > 0.001D) {
                options.method_42517().method_41748(target);
            }
        } else {
            this.restoreEntityDistance(options);
        }

        if (this.disableEntityShadows.isEnabled()) {
            this.appliedEntityShadows = true;
            if (options.method_42435().method_41753()) {
                options.method_42435().method_41748(false);
            }
        } else {
            this.restoreEntityShadows(options);
        }

        if (this.fastClouds.isEnabled()) {
            this.appliedClouds = true;
            if (options.method_42528().method_41753() == class_4063.field_18164) {
                options.method_42528().method_41748(class_4063.field_18163);
            }
        } else {
            this.restoreClouds(options);
        }

        if (this.asynchronousChunkUpdates.isEnabled()) {
            if (options.method_41798().method_41753() == class_6597.field_34790) {
                this.appliedChunkBuilderMode = true;
                options.method_41798().method_41748(class_6597.field_34789);
            }
        } else {
            this.restoreChunkBuilderMode(options);
        }

        if (this.reduceViewDistance.isEnabled()) {
            this.appliedViewDistance = true;
            int target = (int)this.viewDistance.getCurrentValue();
            if (options.method_42503().method_41753() > target) {
                options.method_42503().method_41748(target);
            }
        } else {
            this.restoreViewDistance(options);
        }

        if (this.reduceSimulationDistance.isEnabled()) {
            this.appliedSimulationDistance = true;
            int target = (int)this.simulationDistance.getCurrentValue();
            if (options.method_42510().method_41753() > target) {
                options.method_42510().method_41748(target);
            }
        } else {
            this.restoreSimulationDistance(options);
        }
    }

    private void restoreOptions() {
        if (mc.field_1690 == null) {
            return;
        }

        class_315 options = mc.field_1690;
        this.restoreParticles(options);
        this.restoreEntityDistance(options);
        this.restoreEntityShadows(options);
        this.restoreClouds(options);
        this.restoreChunkBuilderMode(options);
        this.restoreViewDistance(options);
        this.restoreSimulationDistance(options);
    }

    private void restoreParticles(class_315 options) {
        if (this.appliedParticles && this.oldParticles != null) {
            options.method_42475().method_41748(this.oldParticles);
        }
        this.appliedParticles = false;
    }

    private void restoreEntityDistance(class_315 options) {
        if (this.appliedEntityDistance && this.oldEntityDistanceScale != null) {
            options.method_42517().method_41748(this.oldEntityDistanceScale);
        }
        this.appliedEntityDistance = false;
    }

    private void restoreEntityShadows(class_315 options) {
        if (this.appliedEntityShadows && this.oldEntityShadows != null) {
            options.method_42435().method_41748(this.oldEntityShadows);
        }
        this.appliedEntityShadows = false;
    }

    private void restoreClouds(class_315 options) {
        if (this.appliedClouds && this.oldCloudRenderMode != null) {
            options.method_42528().method_41748(this.oldCloudRenderMode);
        }
        this.appliedClouds = false;
    }

    private void restoreChunkBuilderMode(class_315 options) {
        if (this.appliedChunkBuilderMode && this.oldChunkBuilderMode != null) {
            options.method_41798().method_41748(this.oldChunkBuilderMode);
        }
        this.appliedChunkBuilderMode = false;
    }

    private void restoreViewDistance(class_315 options) {
        if (this.appliedViewDistance && this.oldViewDistance != null) {
            options.method_42503().method_41748(this.oldViewDistance);
        }
        this.appliedViewDistance = false;
    }

    private void restoreSimulationDistance(class_315 options) {
        if (this.appliedSimulationDistance && this.oldSimulationDistance != null) {
            options.method_42510().method_41748(this.oldSimulationDistance);
        }
        this.appliedSimulationDistance = false;
    }

    public boolean shouldSkipParticle(class_2394 parameters, double x, double y, double z) {
        if (!this.isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }

        if (parameters.method_10295() == class_2398.field_11248) {
            return false;
        }

        if (this.farParticles.isEnabled()) {
            double distance = this.particleDistance.getCurrentValue();
            if (mc.field_1724.method_5649(x, y, z) > distance * distance) {
                return true;
            }
        }

        if (this.rainParticles.isEnabled() && parameters.method_10295() == class_2398.field_11242) {
            this.particleCounter = (this.particleCounter + 1) & 1023;
            float density = Math.max(0.05F, this.rainParticleDensity.getCurrentValue() / 100.0F);
            int keepEvery = Math.max(1, Math.round(1.0F / density));
            return this.particleCounter % keepEvery != 0;
        }

        return false;
    }

    public boolean shouldSkipWeatherRendering() {
        return this.isEnabled() && this.hideWeather.isEnabled();
    }

    public boolean shouldSkipEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ) {
        if (!this.isEnabled() || mc.field_1724 == null || entity == null || entity == mc.field_1724) {
            return false;
        }
        if (!this.cullFarEntities.isEnabled() && !this.wallEntityCulling.isEnabled()) {
            return false;
        }
        if (entity.method_5821(mc.field_1724)) {
            return false;
        }

        double squaredDistance = entity.method_5649(cameraX, cameraY, cameraZ);
        double farDistance = this.entityDistance.getCurrentValue();
        if (this.cullFarEntities.isEnabled() && squaredDistance > farDistance * farDistance) {
            return true;
        }

        return this.shouldSkipOccludedEntity(entity, cameraX, cameraY, cameraZ);
    }

    private boolean shouldSkipOccludedEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ) {
        if (!this.wallEntityCulling.isEnabled() || mc.field_1687 == null || mc.field_1724 == null) {
            return false;
        }

        double distance = this.wallEntityDistance.getCurrentValue();
        if (entity.method_5649(cameraX, cameraY, cameraZ) > distance * distance) {
            return false;
        }

        class_243 cameraPos = mc.field_1773 != null && mc.field_1773.method_19418() != null
                ? mc.field_1773.method_19418().method_71156()
                : new class_243(cameraX, cameraY, cameraZ);
        if (cameraPos.method_1025(entity.method_73189()) < 4.0D) {
            return false;
        }

        int tick = mc.field_1724.field_6012;
        int entityId = entity.method_5628();
        OcclusionCacheEntry cached = this.occlusionCache.get(entityId);
        double entityX = entity.method_23317();
        double entityY = entity.method_23318();
        double entityZ = entity.method_23321();
        if (cached != null
                && tick - cached.tick <= 3
                && squaredDistance(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350, cached.cameraX, cached.cameraY, cached.cameraZ) < 0.25D
                && squaredDistance(entityX, entityY, entityZ, cached.entityX, cached.entityY, cached.entityZ) < 0.25D) {
            return cached.occluded;
        }

        boolean occluded = this.isEntityFullyBlocked(entity, cameraPos);
        this.occlusionCache.put(entityId, new OcclusionCacheEntry(
                tick, occluded,
                cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350,
                entityX, entityY, entityZ
        ));
        return occluded;
    }

    private static double squaredDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double x = x1 - x2;
        double y = y1 - y2;
        double z = z1 - z2;
        return x * x + y * y + z * z;
    }

    private boolean isEntityFullyBlocked(class_1297 entity, class_243 cameraPos) {
        class_238 box = entity.method_5829();
        double centerX = (box.field_1323 + box.field_1320) * 0.5D;
        double centerY = (box.field_1322 + box.field_1325) * 0.5D;
        double centerZ = (box.field_1321 + box.field_1324) * 0.5D;
        double insetX = Math.min((box.field_1320 - box.field_1323) * 0.25D, 0.35D);
        double insetZ = Math.min((box.field_1324 - box.field_1321) * 0.25D, 0.35D);

        return this.isBlocked(cameraPos, new class_243(centerX, centerY, centerZ))
                && this.isBlocked(cameraPos, new class_243(centerX, box.field_1325 - 0.05D, centerZ))
                && this.isBlocked(cameraPos, new class_243(centerX, box.field_1322 + 0.1D, centerZ))
                && this.isBlocked(cameraPos, new class_243(centerX + insetX, centerY, centerZ + insetZ))
                && this.isBlocked(cameraPos, new class_243(centerX - insetX, centerY, centerZ - insetZ));
    }

    private boolean isBlocked(class_243 from, class_243 to) {
        class_243 delta = to.method_1020(from);
        double length = delta.method_1033();
        if (length <= 0.001D) {
            return false;
        }

        class_243 step = delta.method_1029().method_1021(0.25D);
        int steps = Math.max(1, (int)Math.ceil(length / 0.25D));
        class_2338.class_2339 pos = new class_2338.class_2339();
        int lastX = Integer.MIN_VALUE;
        int lastY = Integer.MIN_VALUE;
        int lastZ = Integer.MIN_VALUE;

        for (int i = 1; i < steps; i++) {
            class_243 sample = from.method_1019(step.method_1021(i));
            pos.method_10102(sample.field_1352, sample.field_1351, sample.field_1350);
            if (pos.method_10263() == lastX && pos.method_10264() == lastY && pos.method_10260() == lastZ) {
                continue;
            }

            lastX = pos.method_10263();
            lastY = pos.method_10264();
            lastZ = pos.method_10260();
            class_2680 state = mc.field_1687.method_8320(pos);
            if (this.blocksEntityView(state, pos)) {
                return true;
            }
        }

        return false;
    }

    private boolean blocksEntityView(class_2680 state, class_2338 pos) {
        return !state.method_26215()
                && state.method_26216()
                && state.method_26230(mc.field_1687, pos)
                && state.method_26234(mc.field_1687, pos);
    }

    public static Optimization getInstanceSafe() {
        if (FeverVisual.getInstance() == null || FeverVisual.getInstance().getModuleManager() == null) {
            return null;
        }
        return FeverVisual.getInstance().getModuleManager().getModuleSafe(Optimization.class);
    }

    private record OcclusionCacheEntry(
            int tick, boolean occluded,
            double cameraX, double cameraY, double cameraZ,
            double entityX, double entityY, double entityZ
    ) {
    }
}
