package fever.visual.systems.modules.modules.visuals;

import lombok.Generated;
import net.minecraft.class_2761;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.game.EntityUtility;

@ModuleInfo(name = "Ambience", category = ModuleCategory.VISUALS, desc = "modules.descriptions.ambience")
public class   Ambience extends BaseModule {
   public final BooleanSetting endSky = new BooleanSetting(this, "modules.settings.ambience.end_sky");
   private final BooleanSetting customTime = new BooleanSetting(this, "modules.settings.ambience.custom_time");
   private final SliderSetting time = new SliderSetting(this, "modules.settings.ambience.time", () -> !this.customTime.isEnabled())
      .step(1000.0F)
      .min(0.0F)
      .max(24000.0F)
      .currentValue(12000.0F);
   private long oldTime;
   private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {
      if (event.getPacket() instanceof class_2761 && this.customTime.isEnabled()) {
         event.cancel();
      }
   };

   @Override
   public void tick() {
      if (mc.field_1687 != null) {
         if (this.customTime.isEnabled()) {
            mc.field_1687.method_28104().method_165((long)this.time.getCurrentValue());
         }

         super.tick();
      }
   }

   @Override
   public void onEnable() {
      if (EntityUtility.isInGame() && mc.field_1687 != null) {
         this.oldTime = mc.field_1687.method_75260();
         super.onEnable();
      }
   }

   @Override
   public void onDisable() {
      if (EntityUtility.isInGame() && mc.field_1687 != null) {
         mc.field_1687.method_28104().method_165(this.oldTime);
         super.onDisable();
      }
   }

   @Generated
   public BooleanSetting getEndSky() {
      return this.endSky;
   }

   @Generated
   public BooleanSetting getCustomTime() {
      return this.customTime;
   }

   @Generated
   public SliderSetting getTime() {
      return this.time;
   }

   @Generated
   public long getOldTime() {
      return this.oldTime;
   }

   @Generated
   public EventListener<ReceivePacketEvent> getOnReceivePacket() {
      return this.onReceivePacket;
   }
}
