package fever.visual.systems.modules.modules.visuals.cosmetic;
//Да давай пасти бездарность :)
//Made by FeverVisuals (NightlyFever)

import fever.visual.mixin.accessors.BipedEntityModelAccessor;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public final class CustomModelsRenderer {

    private static final RabbitModel RABBIT_MODEL = new RabbitModel(RabbitModel.createModel());
    private static final DemonModel DEMON_MODEL = new DemonModel(DemonModel.createModel());
    private static final FreddyModel FREDDY_MODEL = new FreddyModel(FreddyModel.createModel());
    private static final AmogusModel AMOGUS_MODEL = new AmogusModel(AmogusModel.createModel());

    private CustomModelsRenderer() {}

    public static boolean render(CustomModelType type, class_583<?> baseModel, class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
        if (type == null || !(baseModel instanceof class_572)) {
            return false;
        }
        BipedEntityModelAccessor accessor = (BipedEntityModelAccessor) baseModel;
        class_630 head = accessor.fevervisual$getHead();
        class_630 leftArm = accessor.fevervisual$getLeftArm();
        class_630 rightArm = accessor.fevervisual$getRightArm();
        class_630 leftLeg = accessor.fevervisual$getLeftLeg();
        class_630 rightLeg = accessor.fevervisual$getRightLeg();

        CustomModel model = getModel(type.getModelKey());
        if (model == null) return false;

        model.applyAngles(head, leftArm, rightArm, leftLeg, rightLeg);

        matrices.method_22903();
        applyTransform(type.getModelKey(), matrices);
        model.render(matrices, vertices, light, overlay, color);
        matrices.method_22909();
        return true;
    }

    private static CustomModel getModel(CustomModelType.ModelKey key) {
        return switch (key) {
            case RABBIT -> RABBIT_MODEL;
            case DEMON -> DEMON_MODEL;
            case FREDDY -> FREDDY_MODEL;
            case AMOGUS -> AMOGUS_MODEL;
        };
    }

    private static void applyTransform(CustomModelType.ModelKey key, class_4587 matrices) {
        switch (key) {
            case RABBIT -> {
                matrices.method_22905(1.25f, 1.25f, 1.25f);
                matrices.method_46416(0.0f, -0.3f, 0.0f);
            }
            case FREDDY -> {
                matrices.method_22905(0.75f, 0.65f, 0.75f);
                matrices.method_46416(0.0f, 0.85f, 0.0f);
            }
            case AMOGUS -> {
                matrices.method_46416(0.0f, -0.5f, 0.0f);
            }
        }
    }

    private static void copyAngles(class_630 source, class_630 target, float extraPitch, float extraYaw, float extraRoll) {
        target.field_3654 = source.field_3654 + extraPitch;
        target.field_3675 = source.field_3675 + extraYaw;
        target.field_3674 = source.field_3674 + extraRoll;
    }

    private interface CustomModel {
        void applyAngles(class_630 head, class_630 leftArm, class_630 rightArm, class_630 leftLeg, class_630 rightLeg);
        void render(class_4587 matrices, class_4588 vertices, int light, int overlay, int color);
    }


    private static final class RabbitModel
            implements CustomModel {
        private final class_630 root;
        private final class_630 rabbitHead;
        private final class_630 rabbitLarm;
        private final class_630 rabbitRarm;
        private final class_630 rabbitLleg;
        private final class_630 rabbitRleg;

        private RabbitModel(class_630 root) {
            this.root = root;
            class_630 rabbitBone = root.method_32086("rabbit_bone");
            this.rabbitHead = rabbitBone.method_32086("rabbit_head");
            this.rabbitLarm = rabbitBone.method_32086("rabbit_larm");
            this.rabbitRarm = rabbitBone.method_32086("rabbit_rarm");
            this.rabbitLleg = rabbitBone.method_32086("rabbit_lleg");
            this.rabbitRleg = rabbitBone.method_32086("rabbit_rleg");
        }

        @Override
        public void applyAngles(class_630 head, class_630 leftArm, class_630 rightArm, class_630 leftLeg, class_630 rightLeg) {
            CustomModelsRenderer.copyAngles(head, this.rabbitHead, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(leftArm, this.rabbitLarm, 0.0f, 0.0f, -0.0873f);
            CustomModelsRenderer.copyAngles(rightArm, this.rabbitRarm, 0.0f, 0.0f, 0.0873f);
            CustomModelsRenderer.copyAngles(leftLeg, this.rabbitLleg, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightLeg, this.rabbitRleg, 0.0f, 0.0f, 0.0f);
        }

        @Override
        public void render(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
            this.root.method_22699(matrices, vertices, light, overlay, color);
        }

        private static class_630 createModel() {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();
            class_5610 rabbitBone = root.method_32117("rabbit_bone", class_5606.method_32108().method_32101(28, 45).method_32097(-5.0f, -13.0f, -5.0f, 10.0f, 11.0f, 8.0f), class_5603.method_32090((float)0.0f, (float)24.0f, (float)0.0f));
            rabbitBone.method_32117("rabbit_rleg", class_5606.method_32108().method_32101(0, 0).method_32097(-2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f), class_5603.method_32090((float)-3.0f, (float)-2.0f, (float)-1.0f));
            rabbitBone.method_32117("rabbit_larm", class_5606.method_32108().method_32101(0, 0).method_32097(0.0f, 0.0f, -2.0f, 2.0f, 8.0f, 4.0f), class_5603.method_32091((float)5.0f, (float)-13.0f, (float)-1.0f, (float)0.0f, (float)0.0f, (float)-0.0873f));
            rabbitBone.method_32117("rabbit_rarm", class_5606.method_32108().method_32101(0, 0).method_32097(-2.0f, 0.0f, -2.0f, 2.0f, 8.0f, 4.0f), class_5603.method_32091((float)-5.0f, (float)-13.0f, (float)-1.0f, (float)0.0f, (float)0.0f, (float)0.0873f));
            rabbitBone.method_32117("rabbit_lleg", class_5606.method_32108().method_32101(0, 0).method_32097(-2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f), class_5603.method_32090((float)3.0f, (float)-2.0f, (float)-1.0f));
            rabbitBone.method_32117("rabbit_head", class_5606.method_32108().method_32101(0, 0).method_32097(-3.0f, 0.0f, -4.0f, 6.0f, 1.0f, 6.0f).method_32101(56, 0).method_32097(-5.0f, -9.0f, -5.0f, 2.0f, 3.0f, 2.0f).method_32101(56, 0).method_32096().method_32097(3.0f, -9.0f, -5.0f, 2.0f, 3.0f, 2.0f).method_32106(false).method_32101(0, 45).method_32097(-4.0f, -11.0f, -4.0f, 8.0f, 11.0f, 8.0f).method_32101(46, 0).method_32097(1.0f, -20.0f, 0.0f, 3.0f, 9.0f, 1.0f).method_32101(46, 0).method_32097(-4.0f, -20.0f, 0.0f, 3.0f, 9.0f, 1.0f), class_5603.method_32090((float)0.0f, (float)-14.0f, (float)-1.0f));
            return class_5607.method_32110((class_5609)modelData, (int)64, (int)64).method_32109();
        }
    }

    private static final class DemonModel
            implements CustomModel {
        private final class_630 root;
        private final class_630 head;
        private final class_630 leftArm;
        private final class_630 rightArm;
        private final class_630 leftLeg;
        private final class_630 rightLeg;

        private DemonModel(class_630 root) {
            this.root = root;
            this.head = root.method_32086("demon_head");
            this.leftArm = root.method_32086("demon_left_arm");
            this.rightArm = root.method_32086("demon_right_arm");
            this.leftLeg = root.method_32086("demon_left_leg");
            this.rightLeg = root.method_32086("demon_right_leg");
        }

        @Override
        public void applyAngles(class_630 head, class_630 leftArm, class_630 rightArm, class_630 leftLeg, class_630 rightLeg) {
            CustomModelsRenderer.copyAngles(head, this.head, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(leftArm, this.leftArm, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightArm, this.rightArm, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(leftLeg, this.leftLeg, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightLeg, this.rightLeg, 0.0f, 0.0f, 0.0f);
        }

        @Override
        public void render(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
            this.root.method_22699(matrices, vertices, light, overlay, color);
        }

        private static class_630 createModel() {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();
            class_5610 head = root.method_32117("demon_head", class_5606.method_32108().method_32101(0, 0).method_32098(-4.0f, -4.0f, -3.0f, 8.0f, 8.0f, 8.0f, new class_5605(0.3f)), class_5603.method_32090((float)0.0f, (float)-6.0f, (float)-1.0f));
            head.method_32117("demon_left_horn", class_5606.method_32108().method_32101(32, 8).method_32098(13.4346f, -5.2071f, 2.7071f, 6.0f, 2.0f, 2.0f, new class_5605(0.1f)).method_32101(0, 0).method_32098(17.4346f, -10.4071f, 2.7071f, 2.0f, 5.0f, 2.0f, new class_5605(0.1f)), class_5603.method_32091((float)-8.0f, (float)8.0f, (float)0.0f, (float)-0.3927f, (float)0.3927f, (float)-0.5236f));
            head.method_32117("demon_right_horn", class_5606.method_32108().method_32101(32, 8).method_32096().method_32098(-19.4346f, -5.2071f, 2.7071f, 6.0f, 2.0f, 2.0f, new class_5605(0.1f)).method_32106(false).method_32101(0, 0).method_32096().method_32098(-19.4346f, -10.4071f, 2.7071f, 2.0f, 5.0f, 2.0f, new class_5605(0.1f)).method_32106(false), class_5603.method_32091((float)8.0f, (float)8.0f, (float)0.0f, (float)-0.3927f, (float)-0.3927f, (float)0.5236f));
            class_5610 body = root.method_32117("demon_body", class_5606.method_32108().method_32101(0, 16).method_32097(-4.5f, -1.7028f, 1.4696f, 8.0f, 12.0f, 4.0f), class_5603.method_32091((float)0.5f, (float)-0.1f, (float)-3.5f, (float)0.1745f, (float)0.0f, (float)0.0f));
            body.method_32117("demon_left_wing", class_5606.method_32108().method_32101(40, 12).method_32097(-7.0072f, -0.5972f, 0.7515f, 12.0f, 13.0f, 0.0f), class_5603.method_32091((float)8.25f, (float)-2.0f, (float)10.0f, (float)0.0873f, (float)-0.829f, (float)0.1745f));
            body.method_32117("demon_right_wing", class_5606.method_32108().method_32101(40, 12).method_32096().method_32097(-4.9928f, -0.5972f, 0.7515f, 12.0f, 13.0f, 0.0f).method_32106(false), class_5603.method_32091((float)-9.25f, (float)-2.0f, (float)10.0f, (float)0.0873f, (float)0.829f, (float)-0.1745f));
            root.method_32117("demon_left_arm", class_5606.method_32108().method_32101(24, 16).method_32097(-1.1f, -1.05f, 0.0f, 4.0f, 14.0f, 4.0f), class_5603.method_32091((float)5.4f, (float)-1.25f, (float)-2.0f, (float)0.0f, (float)0.0f, (float)-0.2182f));
            root.method_32117("demon_right_arm", class_5606.method_32108().method_32101(24, 16).method_32096().method_32097(-2.9f, -1.05f, 0.0f, 4.0f, 14.0f, 4.0f).method_32106(false), class_5603.method_32091((float)-5.4f, (float)-1.25f, (float)-2.0f, (float)0.0f, (float)0.0f, (float)0.2182f));
            class_5610 leftLeg = root.method_32117("demon_left_leg", class_5606.method_32108().method_32101(48, 22).method_32097(-3.25f, -2.25f, -1.0f, 4.0f, 9.0f, 4.0f), class_5603.method_32090((float)3.0f, (float)10.0f, (float)0.0f));
            class_5610 leftLeg1 = leftLeg.method_32117("demon_left_leg1", class_5606.method_32108().method_32101(34, 34).method_32097(0.95f, 4.6f, 8.0511f, 3.0f, 5.0f, 3.0f), class_5603.method_32091((float)-1.7f, (float)-0.1f, (float)-3.55f, (float)-0.5236f, (float)0.0f, (float)0.0f));
            leftLeg1.method_32117("demon_left_bone2", class_5606.method_32108().method_32101(26, 0).method_32097(-0.7f, -1.15f, 9.3f, 4.0f, 2.0f, 4.0f).method_32101(40, 0).method_32097(-0.7f, -1.15f, 7.3f, 4.0f, 2.0f, 2.0f), class_5603.method_32091((float)1.4f, (float)15.0f, (float)0.25f, (float)0.5236f, (float)0.0f, (float)0.0f));
            class_5610 leftBone3 = leftLeg1.method_32117("demon_left_bone3", class_5606.method_32108(), class_5603.method_32091((float)-1.0f, (float)0.0f, (float)-2.0f, (float)0.0f, (float)-0.0873f, (float)-0.2618f));
            leftBone3.method_32117("demon_left_bone7", class_5606.method_32108().method_32101(16, 34).method_32097(-0.7911f, -10.1159f, 8.0029f, 4.0f, 4.0f, 5.0f).method_32101(0, 32).method_32097(-0.7911f, -15.1159f, 4.0029f, 4.0f, 9.0f, 4.0f), class_5603.method_32090((float)1.9f, (float)12.0f, (float)0.25f));
            class_5610 rightLeg = root.method_32117("demon_right_leg", class_5606.method_32108().method_32101(48, 22).method_32096().method_32097(-0.75f, -2.25f, -1.0f, 4.0f, 9.0f, 4.0f).method_32106(false), class_5603.method_32090((float)-3.0f, (float)10.0f, (float)0.0f));
            class_5610 rightLeg3 = rightLeg.method_32117("demon_right_leg3", class_5606.method_32108().method_32101(34, 34).method_32096().method_32097(-3.95f, 4.6f, 8.0511f, 3.0f, 5.0f, 3.0f).method_32106(false), class_5603.method_32091((float)1.7f, (float)-0.1f, (float)-3.55f, (float)-0.5236f, (float)0.0f, (float)0.0f));
            rightLeg3.method_32117("demon_right_bone4", class_5606.method_32108().method_32101(26, 0).method_32096().method_32097(-3.3f, -1.15f, 9.3f, 4.0f, 2.0f, 4.0f).method_32106(false).method_32101(40, 0).method_32096().method_32097(-3.3f, -1.15f, 7.3f, 4.0f, 2.0f, 2.0f).method_32106(false), class_5603.method_32091((float)-1.4f, (float)15.0f, (float)0.25f, (float)0.5236f, (float)0.0f, (float)0.0f));
            class_5610 rightBone5 = rightLeg3.method_32117("demon_right_bone5", class_5606.method_32108(), class_5603.method_32091((float)1.0f, (float)0.0f, (float)-2.0f, (float)0.0f, (float)0.0873f, (float)0.2618f));
            rightBone5.method_32117("demon_right_bone6", class_5606.method_32108().method_32101(16, 34).method_32096().method_32097(-3.2089f, -10.1159f, 8.0029f, 4.0f, 4.0f, 5.0f).method_32106(false).method_32101(0, 32).method_32096().method_32097(-3.2089f, -15.1159f, 4.0029f, 4.0f, 9.0f, 4.0f).method_32106(false), class_5603.method_32090((float)-1.9f, (float)12.0f, (float)0.25f));
            return class_5607.method_32110((class_5609)modelData, (int)64, (int)64).method_32109();
        }
    }

    private static final class FreddyModel
            implements CustomModel {
        private final class_630 root;
        private final class_630 head;
        private final class_630 leftArm;
        private final class_630 rightArm;
        private final class_630 leftLeg;
        private final class_630 rightLeg;

        private FreddyModel(class_630 root) {
            this.root = root;
            class_630 freddyBody = root.method_32086("freddy_body");
            this.head = freddyBody.method_32086("freddy_head");
            this.leftArm = freddyBody.method_32086("freddy_left_arm");
            this.rightArm = freddyBody.method_32086("freddy_right_arm");
            this.leftLeg = freddyBody.method_32086("freddy_left_leg");
            this.rightLeg = freddyBody.method_32086("freddy_right_leg");
        }

        @Override
        public void applyAngles(class_630 head, class_630 leftArm, class_630 rightArm, class_630 leftLeg, class_630 rightLeg) {
            CustomModelsRenderer.copyAngles(head, this.head, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(leftArm, this.leftArm, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightArm, this.rightArm, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(leftLeg, this.leftLeg, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightLeg, this.rightLeg, 0.0f, 0.0f, 0.0f);
        }

        @Override
        public void render(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
            this.root.method_22699(matrices, vertices, light, overlay, color);
        }

        private static class_630 createModel() {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();
            class_5610 freddyBody = root.method_32117("freddy_body", class_5606.method_32108().method_32101(0, 0).method_32097(-1.0f, -14.0f, -1.0f, 2.0f, 24.0f, 2.0f), class_5603.method_32090((float)0.0f, (float)-9.0f, (float)0.0f));
            freddyBody.method_32117("freddy_torso", class_5606.method_32108().method_32101(8, 0).method_32097(-6.0f, -9.0f, -4.0f, 12.0f, 18.0f, 8.0f), class_5603.method_32091((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0174533f, (float)0.0f, (float)0.0f));
            class_5610 rightArm = freddyBody.method_32117("freddy_right_arm", class_5606.method_32108().method_32101(48, 0).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), class_5603.method_32091((float)-6.5f, (float)-8.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.2617994f));
            rightArm.method_32117("freddy_right_arm_pad", class_5606.method_32108().method_32101(70, 10).method_32097(-2.5f, 0.0f, -2.5f, 5.0f, 9.0f, 5.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            class_5610 rightArm2 = rightArm.method_32117("freddy_right_arm2", class_5606.method_32108().method_32101(90, 20).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), class_5603.method_32091((float)0.0f, (float)9.6f, (float)0.0f, (float)-0.17453292f, (float)0.0f, (float)0.0f));
            rightArm2.method_32117("freddy_right_arm_pad2", class_5606.method_32108().method_32101(0, 26).method_32097(-2.5f, 0.0f, -2.5f, 5.0f, 7.0f, 5.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            rightArm2.method_32117("freddy_right_hand", class_5606.method_32108().method_32101(20, 26).method_32097(-2.0f, 0.0f, -2.5f, 4.0f, 4.0f, 5.0f), class_5603.method_32091((float)0.0f, (float)8.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.05235988f));
            class_5610 leftArm = freddyBody.method_32117("freddy_left_arm", class_5606.method_32108().method_32101(62, 10).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), class_5603.method_32091((float)6.5f, (float)-8.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f));
            leftArm.method_32117("freddy_left_arm_pad", class_5606.method_32108().method_32101(38, 54).method_32097(-2.5f, 0.0f, -2.5f, 5.0f, 9.0f, 5.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            class_5610 leftArm2 = leftArm.method_32117("freddy_left_arm2", class_5606.method_32108().method_32101(90, 48).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), class_5603.method_32091((float)0.0f, (float)9.6f, (float)0.0f, (float)-0.17453292f, (float)0.0f, (float)0.0f));
            leftArm2.method_32117("freddy_left_arm_pad2", class_5606.method_32108().method_32101(0, 58).method_32097(-2.5f, 0.0f, -2.5f, 5.0f, 7.0f, 5.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            leftArm2.method_32117("freddy_left_hand", class_5606.method_32108().method_32101(58, 56).method_32097(-1.0f, 0.0f, -2.5f, 4.0f, 4.0f, 5.0f), class_5603.method_32091((float)0.0f, (float)8.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.05235988f));
            class_5610 rightLeg = freddyBody.method_32117("freddy_right_leg", class_5606.method_32108().method_32101(90, 8).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), class_5603.method_32090((float)-3.3f, (float)12.5f, (float)0.0f));
            rightLeg.method_32117("freddy_right_leg_pad", class_5606.method_32108().method_32101(73, 33).method_32097(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            class_5610 rightLeg2 = rightLeg.method_32117("freddy_right_leg2", class_5606.method_32108().method_32101(20, 35).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), class_5603.method_32091((float)0.0f, (float)9.6f, (float)0.0f, (float)0.03490659f, (float)0.0f, (float)0.0f));
            rightLeg2.method_32117("freddy_right_leg_pad2", class_5606.method_32108().method_32101(0, 39).method_32097(-2.5f, 0.0f, -3.0f, 5.0f, 7.0f, 6.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            rightLeg2.method_32117("freddy_right_foot", class_5606.method_32108().method_32101(22, 39).method_32097(-2.5f, 0.0f, -6.0f, 5.0f, 3.0f, 8.0f), class_5603.method_32091((float)0.0f, (float)8.0f, (float)0.0f, (float)-0.03490659f, (float)0.0f, (float)0.0f));
            class_5610 leftLeg = freddyBody.method_32117("freddy_left_leg", class_5606.method_32108().method_32101(54, 10).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), class_5603.method_32090((float)3.3f, (float)12.5f, (float)0.0f));
            leftLeg.method_32117("freddy_left_leg_pad", class_5606.method_32108().method_32101(48, 39).method_32097(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            class_5610 leftLeg2 = leftLeg.method_32117("freddy_left_leg2", class_5606.method_32108().method_32101(72, 48).method_32097(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), class_5603.method_32091((float)0.0f, (float)9.6f, (float)0.0f, (float)0.03490659f, (float)0.0f, (float)0.0f));
            leftLeg2.method_32117("freddy_left_leg_pad2", class_5606.method_32108().method_32101(16, 50).method_32097(-2.5f, 0.0f, -3.0f, 5.0f, 7.0f, 6.0f), class_5603.method_32090((float)0.0f, (float)0.5f, (float)0.0f));
            leftLeg2.method_32117("freddy_left_foot", class_5606.method_32108().method_32101(72, 50).method_32097(-2.5f, 0.0f, -6.0f, 5.0f, 3.0f, 8.0f), class_5603.method_32091((float)0.0f, (float)8.0f, (float)0.0f, (float)-0.03490659f, (float)0.0f, (float)0.0f));
            freddyBody.method_32117("freddy_crotch", class_5606.method_32108().method_32101(56, 0).method_32097(-5.5f, 0.0f, -3.5f, 11.0f, 3.0f, 7.0f), class_5603.method_32090((float)0.0f, (float)9.5f, (float)0.0f));
            class_5610 head = freddyBody.method_32117("freddy_head", class_5606.method_32108().method_32101(39, 22).method_32097(-5.5f, -8.0f, -4.5f, 11.0f, 8.0f, 9.0f), class_5603.method_32090((float)0.0f, (float)-13.0f, (float)-0.5f));
            head.method_32117("freddy_jaw", class_5606.method_32108().method_32101(49, 65).method_32097(-5.0f, 0.0f, -4.5f, 10.0f, 3.0f, 9.0f), class_5603.method_32091((float)0.0f, (float)0.5f, (float)0.0f, (float)0.08726646f, (float)0.0f, (float)0.0f));
            head.method_32117("freddy_nose", class_5606.method_32108().method_32101(17, 67).method_32097(-4.0f, -2.0f, -3.0f, 8.0f, 4.0f, 3.0f), class_5603.method_32090((float)0.0f, (float)-2.0f, (float)-4.5f));
            class_5610 earRight = head.method_32117("freddy_ear_right", class_5606.method_32108().method_32101(8, 0).method_32097(-1.0f, -3.0f, -0.5f, 2.0f, 3.0f, 1.0f), class_5603.method_32091((float)-4.5f, (float)-5.5f, (float)0.0f, (float)0.05235988f, (float)0.0f, (float)-1.0471976f));
            earRight.method_32117("freddy_ear_right_pad", class_5606.method_32108().method_32101(85, 0).method_32097(-2.0f, -5.0f, -1.0f, 4.0f, 4.0f, 2.0f), class_5603.method_32090((float)0.0f, (float)-1.0f, (float)0.0f));
            class_5610 earLeft = head.method_32117("freddy_ear_left", class_5606.method_32108().method_32101(40, 0).method_32097(-1.0f, -3.0f, -0.5f, 2.0f, 3.0f, 1.0f), class_5603.method_32091((float)4.5f, (float)-5.5f, (float)0.0f, (float)0.05235988f, (float)0.0f, (float)1.0471976f));
            earLeft.method_32117("freddy_ear_left_pad", class_5606.method_32108().method_32101(40, 39).method_32097(-2.0f, -5.0f, -1.0f, 4.0f, 4.0f, 2.0f), class_5603.method_32090((float)0.0f, (float)-1.0f, (float)0.0f));
            class_5610 hat = head.method_32117("freddy_hat", class_5606.method_32108().method_32101(70, 24).method_32097(-3.0f, -0.5f, -3.0f, 6.0f, 1.0f, 6.0f), class_5603.method_32091((float)0.0f, (float)-8.4f, (float)0.0f, (float)-0.0174533f, (float)0.0f, (float)0.0f));
            hat.method_32117("freddy_hat2", class_5606.method_32108().method_32101(78, 61).method_32097(-2.0f, -4.0f, -2.0f, 4.0f, 4.0f, 4.0f), class_5603.method_32091((float)0.0f, (float)0.1f, (float)0.0f, (float)-0.0174533f, (float)0.0f, (float)0.0f));
            return class_5607.method_32110((class_5609)modelData, (int)100, (int)80).method_32109();
        }
    }

    private static final class AmogusModel
            implements CustomModel {
        private final class_630 root;
        private final class_630 leftLeg;
        private final class_630 rightLeg;

        private AmogusModel(class_630 root) {
            this.root = root;
            this.leftLeg = root.method_32086("amogus_left_leg");
            this.rightLeg = root.method_32086("amogus_right_leg");
        }

        @Override
        public void applyAngles(class_630 head, class_630 leftArm, class_630 rightArm, class_630 leftLeg, class_630 rightLeg) {
            CustomModelsRenderer.copyAngles(leftLeg, this.leftLeg, 0.0f, 0.0f, 0.0f);
            CustomModelsRenderer.copyAngles(rightLeg, this.rightLeg, 0.0f, 0.0f, 0.0f);
        }

        @Override
        public void render(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
            this.root.method_22699(matrices, vertices, light, overlay, color);
        }

        private static class_630 createModel() {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();
            root.method_32117("amogus_body", class_5606.method_32108().method_32101(34, 8).method_32097(-4.0f, 6.0f, -3.0f, 8.0f, 12.0f, 6.0f).method_32101(15, 10).method_32097(-3.0f, 9.0f, 3.0f, 6.0f, 8.0f, 3.0f).method_32101(26, 0).method_32097(-3.0f, 5.0f, -3.0f, 6.0f, 1.0f, 6.0f), class_5603.method_32090((float)0.0f, (float)0.0f, (float)0.0f));
            root.method_32117("amogus_eye", class_5606.method_32108().method_32101(0, 10).method_32097(-3.0f, 7.0f, -4.0f, 6.0f, 4.0f, 1.0f), class_5603.method_32090((float)0.0f, (float)0.0f, (float)0.0f));
            root.method_32117("amogus_left_leg", class_5606.method_32108().method_32101(0, 0).method_32097(2.9f, 0.0f, -1.5f, 3.0f, 6.0f, 3.0f), class_5603.method_32090((float)-2.0f, (float)18.0f, (float)0.0f));
            root.method_32117("amogus_right_leg", class_5606.method_32108().method_32101(13, 0).method_32097(-5.9f, 0.0f, -1.5f, 3.0f, 6.0f, 3.0f), class_5603.method_32090((float)2.0f, (float)18.0f, (float)0.0f));
            return class_5607.method_32110((class_5609)modelData, (int)64, (int)64).method_32109();
        }
    }
}
