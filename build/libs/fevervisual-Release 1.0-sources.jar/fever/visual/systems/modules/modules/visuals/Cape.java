package fever.visual.systems.modules.modules.visuals;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name = "Cape", category = ModuleCategory.VISUALS, desc = "modules.descriptions.cape")
public class Cape extends BaseModule {
    private static final class_2960 FEVER_CAPE_TEXTURE = FeverVisual.id("textures/cape/cape.png");
    private static final class_2960 DEFAULT_CAPE_TEXTURE = FeverVisual.id("textures/cape/cape2.png");

    private final SelectSetting targets = new SelectSetting(this, "modules.settings.cape.targets");
    private final SelectSetting.Value targetSelf = new SelectSetting.Value(targets, "modules.settings.cape.targets.self").select();
    private final SelectSetting.Value targetFriends = new SelectSetting.Value(targets, "modules.settings.cape.targets.friends");

    private final ModeSetting style = new ModeSetting(this, "modules.settings.cape.style");
    private final ModeSetting.Value defaultCape = new ModeSetting.Value(style, "modules.settings.cape.style.default").select();
    private final ModeSetting.Value FeverCape = new ModeSetting.Value(style, "modules.settings.cape.style.white");

    private final BooleanSetting clothPhysics = new BooleanSetting(this, "modules.settings.cape.cloth_physics").enable();

    private final SliderSetting physicsStiffness = new SliderSetting(this, "modules.settings.cape.physics_stiffness", () -> !this.clothPhysics.isEnabled())
            .min(0.05F)
            .max(0.45F)
            .step(0.01F)
            .currentValue(0.22F);

    private final SliderSetting physicsDamping = new SliderSetting(this, "modules.settings.cape.physics_damping", () -> !this.clothPhysics.isEnabled())
            .min(0.55F)
            .max(0.95F)
            .step(0.01F)
            .currentValue(0.82F);

    private final SliderSetting motionInfluence = new SliderSetting(this, "modules.settings.cape.motion_influence", () -> !this.clothPhysics.isEnabled())
            .min(0.2F)
            .max(3.0F)
            .step(0.05F)
            .currentValue(1.0F);

    private final SliderSetting gravityInfluence = new SliderSetting(this, "modules.settings.cape.gravity_influence", () -> !this.clothPhysics.isEnabled())
            .min(0.0F)
            .max(3.0F)
            .step(0.05F)
            .currentValue(1.0F);

    private final SliderSetting waveAmplitude = new SliderSetting(this, "modules.settings.cape.wave_amplitude", () -> !this.clothPhysics.isEnabled())
            .min(0.0F)
            .max(7.0F)
            .step(0.1F)
            .currentValue(2.0F);

    private final SliderSetting waveSpeed = new SliderSetting(this, "modules.settings.cape.wave_speed", () -> !this.clothPhysics.isEnabled())
            .min(0.1F)
            .max(4.0F)
            .step(0.05F)
            .currentValue(1.0F);

    public class_2960 getCapeTexture() {
        if (FeverCape.isSelected()) {
            return FEVER_CAPE_TEXTURE;
        }
        return DEFAULT_CAPE_TEXTURE;
    }

    public boolean shouldRenderForPlayer(class_1657 player) {
        if (player == null) return false;

        if (player == mc.field_1724) {
            return targetSelf.isSelected();
        }

        boolean isFriend = FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString());
        if (isFriend && targetFriends.isSelected()) {
            return !isInvisible(player);
        }

        return false;
    }

    private boolean isInvisible(class_1657 player) {
        if (player.method_6059(class_1294.field_5905)) return true;
        if (player.method_5767()) return true;
        if (mc.field_1724 != null && player.method_5756(mc.field_1724)) return true;
        return false;
    }

    public boolean isClothPhysicsEnabled() {
        return this.clothPhysics.isEnabled();
    }

    public float getPhysicsStiffness() {
        return this.physicsStiffness.getCurrentValue();
    }

    public float getPhysicsDamping() {
        return this.physicsDamping.getCurrentValue();
    }

    public float getMotionInfluence() {
        return this.motionInfluence.getCurrentValue();
    }

    public float getGravityInfluence() {
        return this.gravityInfluence.getCurrentValue();
    }

    public float getWaveAmplitude() {
        return this.waveAmplitude.getCurrentValue();
    }

    public float getWaveSpeed() {
        return this.waveSpeed.getCurrentValue();
    }

    @Nullable
    public static Cape getModule() {
        if (FeverVisual.getInstance().getModuleManager() == null) {
            return null;
        }
        return FeverVisual.getInstance().getModuleManager().getModuleSafe(Cape.class);
    }
}
