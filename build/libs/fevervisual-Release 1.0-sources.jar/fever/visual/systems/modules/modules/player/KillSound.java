package fever.visual.systems.modules.modules.player;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.event.impl.game.EntityDeathEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.sounds.ClientSoundInstance;
import fever.visual.utility.sounds.ClientSounds;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@ModuleInfo(
        name = "Kill Sound",
        category = ModuleCategory.MISC,
        desc = "modules.descriptions.kill_sound"
)
public class KillSound extends BaseModule {

    private final Random random = new Random();
    private final Map<UUID, Long> playedDeaths = new HashMap<>();
    private final Map<Integer, WatchedTarget> watchedTargets = new HashMap<>();

    private final BooleanSetting playSound = new BooleanSetting(
            this, "modules.settings.kill_sound.play_sound", "modules.settings.kill_sound.play_sound.description"
    ).enabled(true);

    private final SliderSetting volume = new SliderSetting(
            this, "modules.settings.kill_sound.volume", "modules.settings.kill_sound.volume.description"
    ).min(0.0f).max(100.0f).step(1.0f).currentValue(100.0f);

    private final BooleanSetting mobs = new BooleanSetting(
            this, "modules.settings.kill_sound.mobs", "modules.settings.kill_sound.mobs.description"
    ).enabled(true);

    private final ModeSetting soundType = new ModeSetting(
            this, "modules.settings.kill_sound.sound_type", "modules.settings.kill_sound.sound_type.description"
    );

    private final ModeSetting.Value kill1 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill1");
    private final ModeSetting.Value kill2 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill2");
    private final ModeSetting.Value kill3 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill3");
    private final ModeSetting.Value kill4 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill4");
    private final ModeSetting.Value kill5 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill5");
    private final ModeSetting.Value kill6 = new ModeSetting.Value(soundType, "modules.settings.kill_sound.kill6");
    private final ModeSetting.Value randomMode = new ModeSetting.Value(soundType, "modules.settings.kill_sound.random").select();

    private final EventListener<AttackEvent> onAttack = event -> {
        if (mc.field_1687 == null || mc.field_1724 == null || !(event.getEntity() instanceof class_1309 entity)) return;
        if (!shouldTrack(entity)) return;

        this.watchedTargets.put(entity.method_5628(), new WatchedTarget(entity.method_5667(), System.currentTimeMillis()));
    };

    private final EventListener<EntityDeathEvent> onEntityDeath = event -> {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        if (!(event.getEntity() instanceof class_1309 entity)) return;
        if (!isKilledByPlayer(event, mc.field_1724)) return;
        if (!mobs.isEnabled() && !(entity instanceof class_1657)) return;
        if (entity == mc.field_1724) return;
        if (this.wasRecentlyPlayed(entity.method_5667())) return;

        this.playKillSound();
    };

    @Override
    public void tick() {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            this.watchedTargets.clear();
            return;
        }

        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, WatchedTarget>> iterator = this.watchedTargets.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, WatchedTarget> entry = iterator.next();
            WatchedTarget watched = entry.getValue();
            if (now - watched.attackTimeMs() > 4000L) {
                iterator.remove();
                continue;
            }

            class_1297 rawEntity = mc.field_1687.method_8469(entry.getKey());
            if (!(rawEntity instanceof class_1309 entity)) {
                if (!this.wasRecentlyPlayed(watched.uuid())) {
                    this.playKillSound();
                }
                iterator.remove();
                continue;
            }

            if (entity == mc.field_1724 || !shouldTrack(entity)) {
                iterator.remove();
                continue;
            }

            if (entity.method_29504() || entity.method_31481() || entity.method_6032() <= 0.0F) {
                if (!this.wasRecentlyPlayed(entity.method_5667())) {
                    this.playKillSound();
                }
                iterator.remove();
            }
        }
    }

    @Override
    public void onDisable() {
        this.playedDeaths.clear();
        this.watchedTargets.clear();
    }

    private boolean isKilledByPlayer(EntityDeathEvent event, class_1657 player) {
        if (event.getSource() != null && event.getSource().method_5529() == player) {
            return true;
        }

        return event.getKillerEntity() == player;
    }

    private boolean shouldTrack(class_1309 entity) {
        if (entity == mc.field_1724) {
            return false;
        }

        return entity instanceof class_1657 || mobs.isEnabled();
    }

    private boolean wasRecentlyPlayed(UUID uuid) {
        long now = System.currentTimeMillis();
        this.playedDeaths.entrySet().removeIf(entry -> now - entry.getValue() > 1500L);
        Long lastPlayed = this.playedDeaths.get(uuid);
        if (lastPlayed != null && now - lastPlayed <= 1500L) {
            return true;
        }

        this.playedDeaths.put(uuid, now);
        return false;
    }

    private void playKillSound() {
        if (!playSound.isEnabled()) {
            return;
        }

        ClientSoundInstance sound = getSelectedSound();
        if (sound != null) {
            sound.play(volume.getCurrentValue() / 100.0f);
        }
    }

    private ClientSoundInstance getSelectedSound() {
        if (soundType.is(kill1)) return ClientSounds.GIRL_1;
        if (soundType.is(kill2)) return ClientSounds.GIRL_2;
        if (soundType.is(kill3)) return ClientSounds.GIRL_3;
        if (soundType.is(kill4)) return ClientSounds.GIRL_4;
        if (soundType.is(kill5)) return ClientSounds.GIRL_5;
        if (soundType.is(kill6)) return ClientSounds.FRAG;
        if (soundType.is(randomMode)) {
            ClientSoundInstance[] sounds = {
                    ClientSounds.GIRL_1, ClientSounds.GIRL_2, ClientSounds.GIRL_4,
                    ClientSounds.GIRL_3, ClientSounds.GIRL_5, ClientSounds.FRAG
            };
            return sounds[random.nextInt(sounds.length)];
        }
        return ClientSounds.FRAG;
    }

    private record WatchedTarget(UUID uuid, long attackTimeMs) {
    }
}
