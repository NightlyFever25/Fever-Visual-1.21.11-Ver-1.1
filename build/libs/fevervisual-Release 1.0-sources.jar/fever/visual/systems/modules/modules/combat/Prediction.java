package fever.visual.systems.modules.modules.combat;

import fever.visual.utility.render.compat.GlStateManager.DstFactor;
import fever.visual.utility.render.compat.GlStateManager.SrcFactor;
import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.FeverVisual;
import fever.visual.framework.base.CustomDrawContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.framework.objects.BorderRadius;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.HudRenderEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.shared.PredicateValue;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.PotionUtility;
import fever.visual.utility.game.TextUtility;
import fever.visual.utility.inventory.EnchantmentUtility;
import fever.visual.utility.render.Draw3DUtility;
import fever.visual.utility.render.DrawUtility;
import fever.visual.utility.render.RenderUtility;
import fever.visual.utility.render.Utils;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1675;
import net.minecraft.class_1676;
import net.minecraft.class_1680;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1776;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_1893;
import net.minecraft.class_239.class_240;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3857;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.entity.projectile.*;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.List;

@ModuleInfo(name = "Prediction", category = ModuleCategory.COMBAT)
public class Prediction extends BaseModule {
   private static final class_2960 BLOOM_TEXTURE = FeverVisual.id("textures/bloom.png");
   private static final class_2960 HIT_TEXTURE = FeverVisual.id("textures/hit.png");

   private final List<Predicted> predicted = new ArrayList<>();
   private final List<Landed> landed = new ArrayList<>();
   private final List<class_1676> projectiles = new ArrayList<>(3);
   private final SelectSetting entities = new SelectSetting(this, "modules.settings.prediction.entities");
   private final ModeSetting renderMode = new ModeSetting(this, "modules.settings.prediction.render_mode");
   private final ModeSetting.Value defaultMode = new ModeSetting.Value(this.renderMode, "modules.settings.prediction.render_mode.default");
   private final ModeSetting.Value glowMode = new ModeSetting.Value(this.renderMode, "modules.settings.prediction.render_mode.glow").select();
   private final BooleanSetting inHand = new BooleanSetting(this, "modules.settings.prediction.hand").enable();
   private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.prediction.color_mode");
   private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.prediction.color_mode.theme").select();
   private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.prediction.color_mode.custom");
   private final ColorSetting colorFirst = new ColorSetting(this, "modules.settings.prediction.color", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(160, 115, 255, 255));
   private final ColorSetting colorSecond = new ColorSetting(this, "modules.settings.prediction.color_second", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(100, 160, 255, 255));
   private final EventListener<HudRenderEvent> onRender2D = event -> {
      CustomDrawContext context = event.getContext();
      class_4587 ms = context.getMatrices();

      for (Predicted predict : this.predicted) {
         if (predict.entity instanceof class_1676 projectile && projectile.method_24921() != mc.field_1724) {
            continue;
         }

         class_241 screenPos = Utils.worldToScreen(predict.vectors.getLast());
         if (screenPos != null) {
            float x = screenPos.field_1343;
            float y = screenPos.field_1342;
            Font font = Fonts.MEDIUM.getFont(13.0F);
            float height = font.height() + 6.0F;
            float yOff = -height;
            String name = predict.entity.method_5477().getString().replace("Брошенный эндер-жемчуг", "Эндер-жемчуг");
            if (predict.entity instanceof class_1686 potion) {
               name = potion.method_7495().method_63015().getString();
            }

            name = name.replace("] ", "").replace("[", "") + String.format(" (%s сек)", TextUtility.formatNumber(predict.ticks / 20.0F));

            class_1799 stack = switch (predict.entity) {
               case class_3857 item -> item.method_7495();
               case class_1665 itemx -> itemx.method_54759();
               case class_1542 itemxx -> itemxx.method_6983();
               default -> class_1802.field_8107.method_7854();
            };
            float distance = (float)predict.vectors.getLast().method_1022(mc.field_1724.method_33571());
            float scale = class_3532.method_15363(1.0F - distance / 20.0F, 0.5F, 1.0F);
            ms.method_22903();
            ms.method_46416(x, y, 0.0F);
            ms.method_22905(scale, scale, 1.0F);
            float firstWidth = font.width(name) + 20.0F;
            context.drawRect(-firstWidth / 2.0F, yOff, firstWidth, height, new ColorRGBA(0.0F, 0.0F, 0.0F, 100.0F));
            context.drawItem(stack, -firstWidth / 2.0F, yOff, 1.0F);
            context.drawText(font, name, -firstWidth / 2.0F + 17.0F, yOff + 3.0F, Colors.WHITE);
            yOff += height;
            if (predict.entity instanceof class_1676 projectile && projectile.method_24921() instanceof class_742 player) {
               String owner = "От " + (projectile.method_24921() == mc.field_1724 ? "Вас" : projectile.method_24921().method_5477().getString());
               float secondWidth = font.width(owner) + 22.0F;
               context.drawRect(-secondWidth / 2.0F, yOff, secondWidth, height, new ColorRGBA(0.0F, 0.0F, 0.0F, 100.0F));
               context.drawHead(player, -secondWidth / 2.0F, yOff, height, BorderRadius.ZERO, Colors.WHITE);
               context.drawText(font, owner, -secondWidth / 2.0F + 19.0F, yOff + 3.0F, Colors.WHITE);
               yOff += height;
            }

            if (predict.entity instanceof class_1686 potion) {
               for (class_1293 effect : PotionUtility.effects(potion.method_7495())) {
                  String potionName = ((class_1291)effect.method_5579().comp_349()).method_5560().getString();
                  int amplifier = effect.method_5578();
                  int duration = effect.method_5584();
                  String potionLevel = amplifier > 0 ? " " + (amplifier + 1) : "";
                  String potionTime = this.formatDuration(duration);
                  String fullPotionText = potionName + potionLevel + " (" + potionTime + ")";
                  float potionWidth = font.width(fullPotionText) + 6.0F;
                  context.drawRect(-potionWidth / 2.0F, yOff + 5.0F, potionWidth, height, new ColorRGBA(0.0F, 0.0F, 0.0F, 100.0F));
                  context.drawText(
                          font,
                          fullPotionText,
                          -potionWidth / 2.0F + 3.0F,
                          yOff + 8.0F,
                          ColorRGBA.fromInt(((class_1291)effect.method_5579().comp_349()).method_5556()).withAlpha(255.0F)
                  );
                  yOff += height;
               }
            }

            ms.method_22909();
         }
      }
   };
   private final EventListener<Render3DEvent> onRender3D = new EventListener<>() {
      @Override
      public void onEvent(Render3DEvent event) {
         Prediction.this.renderPrediction3D(event);
      }

      @Override
      public int getPriority() {
         return -100;
      }
   };

   private void renderPrediction3D(Render3DEvent event) {
      class_4587 ms = event.getMatrices();
      ms.method_22903();
      RenderUtility.setupRender3D(true);
      RenderUtility.prepareMatrices(ms);
      RenderSystem.enableDepthTest();

      if (this.defaultMode.isSelected()) {
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);

         for (Predicted predict : this.predicted) {
            if (predict.entity instanceof class_1676 projectile && projectile.method_24921() != mc.field_1724) {
               continue;
            }

            class_243 prevPos = predict.vectors.getFirst();
            Draw3DUtility.drawLine(ms, builder, Utils.getInterpolatedPos(predict.entity, event.getTickDelta()), prevPos, this.getPredictionColor(0.0F));
            int pointIndex = 0;

            for (class_243 pos : predict.vectors) {
               Draw3DUtility.drawLine(ms, builder, prevPos, pos, this.getPredictionColor(pointIndex++));
               prevPos = pos;
            }
         }

         RenderUtility.buildBuffer(builder);
      } else {
         RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
         class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

         for (Predicted predict : this.predicted) {
            if (predict.entity instanceof class_1676 projectile && projectile.method_24921() != mc.field_1724) {
               continue;
            }

            class_243 prevPos = predict.vectors.getFirst();
            class_243 entityPos = Utils.getInterpolatedPos(predict.entity, event.getTickDelta());
            if (entityPos.method_1022(mc.field_1724.method_33571()) > 2.0) {
               for (int i = 0; i < 10; i++) {
                  float t = i / 10.0F;
                  class_243 interpolatedPos = entityPos.method_1019(prevPos.method_1020(entityPos).method_1021(t));
                  this.drawGlow(ms, interpolatedPos, buffer, (float)prevPos.method_1022(entityPos) / 3.0F, 1.0F, i);
                  this.drawGlow(ms, interpolatedPos, buffer, (float)prevPos.method_1022(entityPos) * 2.0F, 0.05F, i + 20);
               }
            }

            int pointIndex = 0;
            for (class_243 pos : predict.vectors) {
               if (pos.method_1022(mc.field_1724.method_33571()) > 2.0) {
                  for (int i = 0; i < 10; i++) {
                     float t = i / 10.0F;
                     class_243 interpolatedPos = prevPos.method_1019(pos.method_1020(prevPos).method_1021(t));
                     this.drawGlow(ms, interpolatedPos, buffer, (float)pos.method_1022(prevPos) / 3.0F, 1.0F, pointIndex + i);
                     this.drawGlow(ms, interpolatedPos, buffer, (float)pos.method_1022(prevPos) * 2.0F, 0.05F, pointIndex + i + 20);
                  }
               }

               prevPos = pos;
               pointIndex++;
            }

            float size = 9.0F;
            if (predict.entity instanceof class_1686) {
               ms.method_22903();
               ms.method_61958(predict.vectors.getLast());
               ms.method_22907(class_7833.field_40713.rotationDegrees(-90.0F));
               DrawUtility.drawImage(
                       ms, buffer, (double)(-size / 2.0F), (double)(-size / 2.0F), 0.0, (double)size, (double)size, this.getPredictionColor(0.0F).withAlpha(255.0F)
               );
               ms.method_22909();
            }
         }

         RenderUtility.buildBuffer(buffer);
      }

      float size = 1.0F;
      RenderSystem.setShaderTexture(0, HIT_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      for (Landed landed : this.landed) {
         if (landed.collidedEntity == null) {
            ms.method_22903();
            ms.method_61958(landed.hitResult.method_17784());
            ms.method_22907(landed.hitResult.method_17780().method_23224());
            ms.method_22907(class_7833.field_40713.rotationDegrees(-90.0F));
            DrawUtility.drawImage(ms, buffer, (double)(-size / 2.0F), (double)(-size / 2.0F), 0.0, (double)size, (double)size, this.getPredictionColor(0.0F).withAlpha(255.0F));
            ms.method_22909();
         }
      }

      RenderUtility.buildBuffer(buffer);
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.disableCull();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      class_4184 camera = mc.field_1773.method_19418();
      class_243 cameraPos = camera.method_71156();
      class_287 quadsBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);

      for (Landed landedx : this.landed) {
         if (landedx.collidedEntity != null) {
            Draw3DUtility.renderFilledBox(ms, quadsBuffer, landedx.collidedEntity.method_5829(), this.getPredictionColor(0.0F).mulAlpha(0.5F));
         }
      }

      RenderUtility.buildBuffer(quadsBuffer);
      class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);

      for (Landed landedxx : this.landed) {
         if (landedxx.collidedEntity != null) {
            Draw3DUtility.renderOutlinedBox(ms, linesBuffer, landedxx.collidedEntity.method_5829(), this.getPredictionColor(20.0F));
         }
      }

      RenderUtility.buildBuffer(linesBuffer);
      RenderUtility.endRender3D();
      ms.method_22909();
   }

   public Prediction() {
      new PredicateValue<class_1297>(this.entities, "modules.settings.prediction.entities.pearls", entity -> entity instanceof class_1684).select();
      new PredicateValue<class_1297>(this.entities, "modules.settings.prediction.entities.tridents", entity -> entity instanceof class_1685).select();
      new PredicateValue<class_1297>(this.entities, "modules.settings.prediction.entities.snowballs", entity -> entity instanceof class_1680).select();
      new PredicateValue<class_1297>(this.entities, "modules.settings.prediction.entities.arrows", entity -> entity instanceof class_1667).select();
      new PredicateValue<class_1297>(this.entities, "modules.settings.prediction.entities.potions", entity -> entity instanceof class_1686).select();
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         return;
      }

      this.predicted.clear();
      this.landed.clear();
      this.projectiles.clear();
      if (this.inHand.isEnabled()) {
         class_1799 handStack = mc.field_1724.method_6047();
         class_1297 inHand = null;
         if (handStack.method_7909() instanceof class_1776) {
            inHand = new class_1684(mc.field_1687, mc.field_1724, handStack);
         } else if (handStack.method_7909() instanceof class_1835 && mc.field_1724.method_6115()) {
            inHand = new class_1685(mc.field_1687, mc.field_1724, handStack);
         } else if (handStack.method_7909() instanceof class_1753 && mc.field_1724.method_6115()) {
            class_1799 arrowStack = new class_1799(class_1802.field_8107);
            inHand = new class_1667(mc.field_1687, mc.field_1724, arrowStack, handStack);
         } else if (handStack.method_7909() instanceof class_1764 && class_1764.method_7781(handStack)) {
            boolean hasMultishot = EnchantmentUtility.getEnchantmentLevel(handStack, class_1893.field_9108) > 0;
            class_1799 arrowStack = new class_1799(class_1802.field_8107);
            if (hasMultishot) {
               for (int i = 0; i < 3; i++) {
                  class_1667 arrow = new class_1667(mc.field_1687, mc.field_1724, arrowStack, handStack);
                  this.projectiles.add(arrow);
               }
            } else {
               inHand = new class_1667(mc.field_1687, mc.field_1724, arrowStack, handStack);
            }
         }

         if (inHand instanceof class_1676 projectile) {
            float speed = 1.5F;
            if (inHand instanceof class_1685) {
               speed = 2.5F;
            } else if (inHand instanceof class_1667) {
               speed = 3.0F;
            }

            this.setVelocity(projectile, mc.field_1724, mc.field_1724.method_36455(), mc.field_1724.method_36454(), 0.0F, speed, 1.0F);
            this.predict(projectile, true);
         }
      }

      if (!this.projectiles.isEmpty()) {
         float speed = 3.15F;
         float spreadAngle = 10.0F;

         for (int i = 0; i < this.projectiles.size(); i++) {
            class_1676 projectile = this.projectiles.get(i);
            float yawOffset = 0.0F;
            if (i == 0) {
               yawOffset = -spreadAngle;
            } else if (i == 2) {
               yawOffset = spreadAngle;
            }

            this.setVelocity(projectile, mc.field_1724, mc.field_1724.method_36455(), mc.field_1724.method_36454() + yawOffset, 0.0F, speed, 1.0F);
            this.predict(projectile, true);
         }
      }

      for (class_1297 entity : mc.field_1687.method_18112()) {
         this.predict(entity, false);
      }
   }

   private void predict(class_1297 entity, boolean inHand) {
      if (entity instanceof class_1676 projectile && projectile.method_24921() != mc.field_1724) {
         return;
      }

      if (this.isValid(entity)) {
         if (entity instanceof class_1676 pearl && pearl.method_24921() == null) {
            class_742 closestPlayer = null;
            double closestDistance = Double.MAX_VALUE;
            for (class_742 player : mc.field_1687.method_18456()) {
               double distance = player.method_5858(pearl);
               if (distance < closestDistance) {
                  closestDistance = distance;
                  closestPlayer = player;
               }
            }
            if (closestPlayer != null) {
               pearl.method_7432(closestPlayer);
            }
         }

         List<class_243> positions = new ArrayList<>();
         class_243 lastPos = entity.method_73189();
         class_243 lastMotion = entity.method_18798();
         class_1297 collidedEntity = null;
         int ticks = 0;
         class_3965 blockHitResult = null;

         for (int i = 0; i < 150; i++) {
            class_243 motion = this.predictMotion(entity, lastMotion);
            class_243 pos = lastPos.method_1019(motion);
            ticks = i;
            blockHitResult = mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3960.field_17558, class_242.field_1348, entity));
            class_1297 collided = this.checkEntityCollision(entity, pos);
            if (collided != null) {
               if (collided instanceof class_1309 && (isEntityInvisible(collided) || isEntityDead(collided))) {
                  lastPos = pos;
                  lastMotion = motion;
                  positions.add(pos);
                  continue;
               }
               positions.add(pos);
               collidedEntity = collided;
               break;
            }

            if (blockHitResult.method_17783() != class_240.field_1333) {
               positions.add(blockHitResult.method_17784());
               break;
            }

            positions.add(pos);
            lastPos = pos;
            lastMotion = motion;
         }

         if (!positions.isEmpty()) {
            if (collidedEntity != null && collidedEntity instanceof class_1309) {
               if (isEntityInvisible(collidedEntity) || isEntityDead(collidedEntity)) {
                  return;
               }
            }

            if (inHand) {
               this.landed.add(new Landed(entity, positions.getLast(), ticks, collidedEntity, blockHitResult));
            } else {
               this.predicted.add(new Predicted(entity, positions, ticks, collidedEntity));
            }
         }
      }
   }

   private void drawGlow(class_4587 ms, class_243 pos, class_287 buffer, float size, float alpha, float colorIndex) {
      ms.method_22903();
      ms.method_61958(pos);
      ms.method_22907(mc.field_1773.method_19418().method_23767());
      DrawUtility.drawImage(
              ms, buffer, (double)(-size / 2.0F), (double)(-size / 2.0F), 0.0, (double)size, (double)size, this.getPredictionColor(colorIndex).withAlpha(255.0F * alpha)
      );
      ms.method_22909();
   }

   private ColorRGBA getPredictionColor(float index) {
      if (this.colorCustom.isSelected()) {
         return this.colorFirst.getColorSafe().mix(this.colorSecond.getColorSafe(), (index % 40.0F) / 39.0F);
      }

      return Colors.getAccentColor(index * 6.0F);
   }

   private boolean isValid(class_1297 entity) {
      if (entity instanceof class_1676 projectile) {
         if (projectile.method_24921() != mc.field_1724) {
            return false;
         }
      }

      boolean valid = false;

      for (SelectSetting.Value selectedValue : this.entities.getSelectedValues()) {
         PredicateValue<class_1297> predicateValue = (PredicateValue<class_1297>)selectedValue;
         if (predicateValue.predicated(entity)) {
            valid = true;
         }
      }

      return entity instanceof class_1685 trident && trident.field_7649 > 0
              ? false
              : valid && (Math.abs(entity.method_18798().field_1352 + entity.method_18798().field_1350) > 0.01F || Math.abs(entity.method_18798().field_1351) > 0.2F);
   }

   private class_1297 checkEntityCollision(class_1297 movingEntity, class_243 predictedPos) {
      class_243 currentPos = movingEntity.method_73189();
      class_243 direction = predictedPos.method_1020(currentPos);
      if (direction.method_1027() == 0.0) {
         return null;
      } else {
         class_3966 hitResult = class_1675.method_18075(
                 movingEntity,
                 currentPos,
                 predictedPos,
                 movingEntity.method_5829().method_18804(direction).method_1014(0.5),
                 entity -> mc.field_1724 != entity
                         && entity.method_5805()
                         && !(entity instanceof class_1542)
                         && !(entity instanceof class_1303)
                         && !(entity instanceof class_1309 livingEntity && (isEntityInvisible(livingEntity) || isEntityDead(livingEntity)))
                         && entity != movingEntity,
                 direction.method_1027()
         );
         return hitResult != null ? hitResult.method_17782() : null;
      }
   }

   private void setVelocity(class_1676 entity, double x, double y, double z, float power) {
      class_243 vec3d = this.calculateVelocity(entity, x, y, z, power);
      entity.method_18799(vec3d);
      entity.field_64356 = true;
      double d = vec3d.method_37267();
      entity.method_36456((float)(class_3532.method_15349(vec3d.field_1352, vec3d.field_1350) * 180.0F / (float)Math.PI));
      entity.method_36457((float)(class_3532.method_15349(vec3d.field_1351, d) * 180.0F / (float)Math.PI));
      entity.field_5982 = entity.method_36454();
      entity.field_6004 = entity.method_36455();
   }

   private void setVelocity(class_1676 entity, class_1297 shooter, float pitch, float yaw, float roll, float speed, float divergence) {
      float f = -class_3532.method_15374(yaw * (float) (Math.PI / 180.0)) * class_3532.method_15362(pitch * (float) (Math.PI / 180.0));
      float g = -class_3532.method_15374((pitch + roll) * (float) (Math.PI / 180.0));
      float h = class_3532.method_15362(yaw * (float) (Math.PI / 180.0)) * class_3532.method_15362(pitch * (float) (Math.PI / 180.0));
      this.setVelocity(entity, f, g, h, speed);
      class_243 vec3d = shooter.method_60478();
      entity.method_18799(entity.method_18798().method_1031(vec3d.field_1352, shooter.method_24828() ? 0.0 : vec3d.field_1351, vec3d.field_1350));
   }

   private class_243 calculateVelocity(class_1676 entity, double x, double y, double z, float power) {
      return new class_243(x, y, z).method_1029().method_1021(power);
   }

   private class_243 predictMotion(class_1297 entity, class_243 motion) {
      return motion.method_1021(0.99).method_1031(0.0, -entity.method_56989(), 0.0);
   }

   private boolean isEntityInvisible(class_1297 entity) {
      if (!(entity instanceof class_1309 livingEntity)) {
         return false;
      }

      if (livingEntity.method_6059(class_1294.field_5905)) {
         return true;
      }
      if (livingEntity.method_5767()) {
         return true;
      }
      if (livingEntity.method_5756(mc.field_1724)) {
         return true;
      }

      return false;
   }

   private boolean isEntityDead(class_1297 entity) {
      if (!(entity instanceof class_1309 livingEntity)) {
         return false;
      }

      return livingEntity.method_29504() || livingEntity.method_6032() <= 0;
   }
   private String formatDuration(int ticks) {
      int seconds = ticks / 20;
      int minutes = seconds / 60;
      int remainingSeconds = seconds % 60;
      return minutes > 0 ? String.format("%d:%02d", minutes, remainingSeconds) : String.format("0:%02d", remainingSeconds);
   }

   record Landed(class_1297 entity, class_243 pos, int ticks, class_1297 collidedEntity, class_3965 hitResult) {
   }

   record Predicted(class_1297 entity, List<class_243> vectors, int ticks, class_1297 collidedEntity) {
   }
}
