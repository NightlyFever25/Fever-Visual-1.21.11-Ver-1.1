package fever.visual.systems.modules.modules.visuals;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.modules.modules.visuals.littlePet.ChinaHat;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1294;
import net.minecraft.class_156;
import net.minecraft.class_239;
import net.minecraft.class_3959;
import net.minecraft.class_4587;
import net.minecraft.class_742;

@ModuleInfo(
        name = "China Hat",
        desc = "modules.descriptions.china_hat",
        category = ModuleCategory.VISUALS
)
public class ChinaHatModule extends BaseModule {
    private static final float BASE_HEAD_Y_OFFSET = 0.2F;
    private static final long VISIBILITY_CACHE_MS = 50L;
    private final Map<UUID, VisibilityEntry> visibilityCache = new HashMap<>();
    private ModelChanger modelChanger;

    private final SelectSetting targets = new SelectSetting(this, "modules.settings.model_changer.targets");
    private final SelectSetting.Value targetSelf = new SelectSetting.Value(targets, "modules.settings.chinahat.render_self").select();
    private final SelectSetting.Value targetFriends = new SelectSetting.Value(targets, "modules.settings.chinahat.render_others");

    private final SliderSetting width = new SliderSetting(this, "modules.settings.chinahat.width", "modules.settings.chinahat.width").min(1.2F).max(2.1F).step(0.1F).currentValue(1.2F);
    private final SliderSetting height = new SliderSetting(this, "modules.settings.chinahat.height", "modules.settings.chinahat.height").min(0.05F).max(0.8F).step(0.05F).currentValue(0.25F);
    private final BooleanSetting useTheme = new BooleanSetting(this, "modules.settings.chinahat.use_theme_color").enable();
    private final ColorSetting color = new ColorSetting(this, "modules.settings.chinahat.color", () -> this.useTheme.isEnabled()).color(new ColorRGBA(100, 150, 200, 255)).alpha(true);
    private final SliderSetting alpha = new SliderSetting(this, "modules.settings.chinahat.alpha", "modules.settings.chinahat.alpha").min(0.0F).max(1.0F).step(0.05F).currentValue(0.85F);

    private final SliderSetting widthFriends = new SliderSetting(this, "modules.settings.chinahat.width_others", "modules.settings.chinahat.width_others").min(1.2F).max(2.1F).step(0.1F).currentValue(1.2F);
    private final SliderSetting heightFriends = new SliderSetting(this, "modules.settings.chinahat.height_others", "modules.settings.chinahat.height_others").min(0.05F).max(0.8F).step(0.05F).currentValue(0.25F);
    private final ColorSetting colorFriends = new ColorSetting(this, "modules.settings.chinahat.color_others", () -> this.useTheme.isEnabled()).color(new ColorRGBA(100, 150, 200, 255)).alpha(true);
    private final SliderSetting alphaFriends = new SliderSetting(this, "modules.settings.chinahat.alpha_others", "modules.settings.chinahat.alpha_others").min(0.0F).max(1.0F).step(0.05F).currentValue(0.85F);

    public boolean shouldRenderForPlayer(class_742 player) {
        if (!this.isEnabled() || mc.field_1687 == null || mc.field_1724 == null) {
            return false;
        }
        if (player == null || player.method_31481()) return false;

        if (player == mc.field_1724) {
            return targetSelf.isSelected();
        }

        boolean isFriend = isFriend(player);
        if (isFriend && targetFriends.isSelected()) {
            return !isInvisible(player) && canSeePlayer(player);
        }

        return false;
    }

    public void renderHeadAnchored(class_742 player, class_4587 matrices) {
        if (player == null || matrices == null) {
            return;
        }
        if (player == mc.field_1724 && mc.field_1690.method_31044().method_31034()) {
            return;
        }

        boolean isSelf = player == mc.field_1724;
        float width = isSelf ? this.width.getCurrentValue() : this.widthFriends.getCurrentValue();
        float height = isSelf ? this.height.getCurrentValue() : this.heightFriends.getCurrentValue();
        float modelScale = getModelScale(player, isSelf);
        float finalYOffset = BASE_HEAD_Y_OFFSET * modelScale;
        ColorRGBA color = isSelf ? getHatColor() : getHatColorFriends();
        float alpha = isSelf ? this.alpha.getCurrentValue() : this.alphaFriends.getCurrentValue();

        ChinaHat.renderAttachedToHead(
                matrices,
                width,
                height,
                finalYOffset,
                color,
                0.3F + alpha * 0.7F
        );
    }

    private float getModelScale(class_742 player, boolean isSelf) {
        ModelChanger modelChanger = this.modelChanger;
        if (modelChanger == null) {
            this.modelChanger = modelChanger = FeverVisual.getInstance().getModuleManager().getModuleSafe(ModelChanger.class);
        }
        if (modelChanger == null || !modelChanger.isEnabled() || player == null) {
            return 1.0F;
        }

        String playerName = player.method_5477().getString();
        return modelChanger.getScaleForPlayer(playerName, isSelf);
    }

    private boolean isFriend(class_742 player) {
        if (FeverVisual.getInstance().getFriendManager() == null) {
            return false;
        }
        String playerName = player.method_5477().getString();
        return FeverVisual.getInstance().getFriendManager().isFriend(playerName);
    }

    private boolean isInvisible(class_742 player) {
        if (player.method_6059(class_1294.field_5905)) {
            return true;
        }
        if (player.method_5767()) {
            return true;
        }
        if (player.method_5756(mc.field_1724)) {
            return true;
        }
        return false;
    }

    private boolean canSeePlayer(class_742 player) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }

        long now = class_156.method_658();
        VisibilityEntry cached = this.visibilityCache.get(player.method_5667());
        if (cached != null && now < cached.expiresAt()) {
            return cached.visible();
        }
        class_239 hitResult = mc.field_1687.method_17742(
                new class_3959(
                        mc.field_1724.method_33571(),
                        player.method_33571(),
                        class_3959.class_3960.field_17558,
                        class_3959.class_242.field_1348,
                        mc.field_1724
                )
        );

        boolean visible = hitResult.method_17783() != class_239.class_240.field_1332;
        this.visibilityCache.put(player.method_5667(), new VisibilityEntry(now + VISIBILITY_CACHE_MS, visible));
        return visible;
    }

    @Override
    public void onDisable() {
        this.visibilityCache.clear();
        super.onDisable();
    }

    private record VisibilityEntry(long expiresAt, boolean visible) {
    }

    private ColorRGBA getHatColor() {
        if (this.useTheme.isEnabled()) {
            return Colors.getAccentColor();
        }
        return this.color.getColor();
    }

    private ColorRGBA getHatColorFriends() {
        if (this.useTheme.isEnabled()) {
            return Colors.getAccentColor();
        }
        return this.colorFriends.getColor();
    }
}
