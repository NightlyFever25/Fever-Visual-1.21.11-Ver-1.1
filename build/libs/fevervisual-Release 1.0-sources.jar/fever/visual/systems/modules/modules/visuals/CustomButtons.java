package fever.visual.systems.modules.modules.visuals;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import net.minecraft.class_310;
import net.minecraft.class_405;
import net.minecraft.class_420;
import net.minecraft.class_422;
import net.minecraft.class_433;
import net.minecraft.class_436;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_445;
import net.minecraft.class_447;
import net.minecraft.class_457;
import net.minecraft.class_4667;
import net.minecraft.class_500;
import net.minecraft.class_5235;
import net.minecraft.class_524;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_527;
import net.minecraft.class_5375;
import net.minecraft.class_7745;
import net.minecraft.class_8219;

@ModuleInfo(name = "Custom Buttons", category = ModuleCategory.DISPLAY, desc = "modules.descriptions.custom_buttons")
public class CustomButtons extends BaseModule {
    public static boolean isEnabledSafe() {
        if (FeverVisual.getInstance().getModuleManager() == null) {
            return false;
        }

        CustomButtons module = FeverVisual.getInstance().getModuleManager().getModuleSafe(CustomButtons.class);
        return module != null && module.isEnabled();
    }

    public static boolean shouldStyleCurrentButtonScreen() {
        return shouldStyleButtonScreen(class_310.method_1551().field_1755);
    }

    public static boolean shouldStyleCurrentSettingsScreen() {
        return shouldStyleSettingsScreen(class_310.method_1551().field_1755);
    }

    public static boolean shouldStyleButtonScreen(class_437 screen) {
        if (screen == null) {
            return false;
        }

        if (shouldStyleSettingsScreen(screen)) {
            return true;
        }

        String screenName = screen.getClass().getSimpleName();
        return screen instanceof class_442
                || screen instanceof class_433
                || screen instanceof class_447
                || screen instanceof class_457
                || screen instanceof class_436
                || screen instanceof class_445
                || screen instanceof class_8219
                || screen instanceof class_500
                || screen instanceof class_422
                || screen instanceof class_420
                || screen instanceof class_526
                || screen instanceof class_524
                || screen instanceof class_525
                || screen instanceof class_405
                || screen instanceof class_527
                || screen instanceof class_5375
                || screenName.equals("TitleScreen")
                || screenName.equals("MainMenuScreen")
                || screenName.equals("GameMenuScreen")
                || screenName.equals("StatsScreen")
                || screenName.equals("AdvancementsScreen")
                || screenName.equals("FeedbackScreen")
                || screenName.equals("BugReportScreen")
                || screenName.equals("ShareToLanScreen")
                || screenName.equals("OpenToLanScreen")
                || screenName.equals("CreditsAndAttributionScreen")
                || screenName.equals("CreditsScreen")
                || screenName.equals("AttributionScreen")
                || screenName.equals("LicenseScreen")
                || screenName.equals("MultiplayerScreen")
                || screenName.equals("AddServerScreen")
                || screenName.equals("DirectConnectScreen")
                || screenName.equals("EditServerScreen")
                || screenName.equals("SelectWorldScreen")
                || screenName.equals("EditWorldScreen")
                || screenName.equals("CreateWorldScreen")
                || screenName.equals("BackupPromptScreen")
                || screenName.equals("OptimizeWorldScreen")
                || screenName.equals("PackScreen");
    }

    public static boolean shouldStyleSettingsScreen(class_437 screen) {
        if (screen == null) {
            return false;
        }

        String className = screen.getClass().getName();
        String screenName = screen.getClass().getSimpleName();

        return screen instanceof class_4667
                || screen instanceof class_5375
                || screen instanceof class_7745
                || screen instanceof class_5235
                || className.contains(".client.gui.screen.option.")
                || screenName.endsWith("OptionsScreen")
                || screenName.equals("GameOptionsScreen")
                || screenName.equals("KeybindsScreen")
                || screenName.equals("PackScreen")
                || screenName.equals("ExperimentalWarningScreen")
                || screenName.equals("EditGameRulesScreen");
    }
}
