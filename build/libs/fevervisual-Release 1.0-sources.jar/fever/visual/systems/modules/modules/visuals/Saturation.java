package fever.visual.systems.modules.modules.visuals;

import fever.visual.framework.base.CustomDrawContext;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.interfaces.IScaledResolution;
import net.minecraft.class_10799;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2960;

@ModuleInfo(name = "Saturation", category = ModuleCategory.VISUALS, desc = "modules.descriptions.saturation")
public class Saturation extends BaseModule implements IMinecraft, IScaledResolution {

    public static Saturation INSTANCE;

    private static final class_2960 FOOD_EMPTY = class_2960.method_60656("hud/food_empty");
    private static final class_2960 FOOD_HALF = class_2960.method_60656("hud/food_half");
    private static final class_2960 FOOD_FULL = class_2960.method_60656("hud/food_full");
    private static final class_2960 FOOD_EMPTY_HUNGER = class_2960.method_60656("hud/food_empty_hunger");
    private static final class_2960 FOOD_HALF_HUNGER = class_2960.method_60656("hud/food_half_hunger");
    private static final class_2960 FOOD_FULL_HUNGER = class_2960.method_60656("hud/food_full_hunger");

    private final BooleanSetting showBackground = new BooleanSetting(this, "modules.settings.saturation.background", "Показывать фон")
            .enabled(true);

    private final SliderSetting xOffset = new SliderSetting(this, "modules.settings.saturation_bar.x_offset", "Смещение по X")
            .min(-100.0F).max(100.0F).step(1.0F).currentValue(0.0F);

    private final SliderSetting yOffset = new SliderSetting(this, "modules.settings.saturation_bar.y_offset", "Смещение по Y")
            .min(-50.0F).max(50.0F).step(1.0F).currentValue(-10.0F);


    public Saturation() {
        INSTANCE = this;
    }

    public static void render(CustomDrawContext customContext) {
        if (INSTANCE == null || !INSTANCE.isEnabled()) return;
        if (INSTANCE.mc.field_1724 == null || INSTANCE.mc.field_1687 == null) return;
        if (INSTANCE.mc.field_1724.method_7325() || INSTANCE.mc.field_1724.method_31549().field_7477) return;
        if (!INSTANCE.shouldRenderFood(INSTANCE.mc.field_1724)) return;

        float saturation = INSTANCE.mc.field_1724.method_7344().method_7589();
        int foodLevel = INSTANCE.mc.field_1724.method_7344().method_7586();

        saturation = Math.max(0.0f, Math.min(saturation, (float) foodLevel));

        if (saturation < 1.0f) return;

        INSTANCE.renderVanillaStyle(customContext, saturation, foodLevel);
    }

    private void renderVanillaStyle(CustomDrawContext drawContext, float saturation, int foodLevel) {
        float right = sr.getScaledWidth() / 2.0f + 91;
        float baseY = sr.getScaledHeight() - 39;
        float x = right - 9 + xOffset.getCurrentValue();
        float y = baseY - 10 + yOffset.getCurrentValue();

        boolean hasHunger = mc.field_1724.method_6059(class_1294.field_5903);

        for (int i = 0; i < 10; i++) {
            float currentX = x - i * 8;
            float fullThreshold = (float) (i + 1) * 2.0f;
            float halfThreshold = fullThreshold - 1.0f;

            boolean drawFull = saturation >= fullThreshold;
            boolean drawHalf = !drawFull && saturation >= halfThreshold;

            if (!drawFull && !drawHalf) continue;

            if (showBackground.isEnabled()) {
                class_2960 emptyTexture;
                if (hasHunger) {
                    emptyTexture = FOOD_EMPTY_HUNGER;
                } else {
                    emptyTexture = FOOD_EMPTY;
                }
                drawContext.drawGuiTexture(class_10799.field_56883, emptyTexture,
                        (int) currentX, (int) y, 9, 9, Colors.getTextColor().withAlpha(50).getRGB());
            }

            class_2960 fillTexture;
            if (drawFull) {
                fillTexture = hasHunger ? FOOD_FULL_HUNGER : FOOD_FULL;
            } else {
                fillTexture = hasHunger ? FOOD_HALF_HUNGER : FOOD_HALF;
            }
            drawContext.drawGuiTexture(class_10799.field_56883, fillTexture,
                    (int) currentX, (int) y, 9, 9, ColorRGBA.WHITE.getRGB());
        }
    }

    private boolean shouldRenderFood(class_1657 player) {
        class_1297 vehicle = player.method_5854();
        if (!(vehicle instanceof class_1309)) {
            return true;
        }
        class_1309 living = (class_1309) vehicle;
        int heartCount = (int) ((living.method_6063() + 0.5f) / 2.0f);
        return Math.min(heartCount, 30) == 0;
    }
}
