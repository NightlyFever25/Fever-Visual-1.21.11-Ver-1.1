package fever.visual.systems.modules.modules.visuals;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.TestikRender3D;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2663;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@ModuleInfo(name = "Totem Angle", category = ModuleCategory.VISUALS, desc = "modules.descriptions.totem_angle")
public class TotemAngle extends BaseModule implements IMinecraft {
   private final ModeSetting mode = new ModeSetting(this, "modules.settings.totem_angle.mode", "modules.settings.totem_angle.mode.description");
   private final ModeSetting.Value angel = new ModeSetting.Value(this.mode, "modules.settings.totem_angle.mode.angel").select();
   private final ModeSetting.Value shatter = new ModeSetting.Value(this.mode, "modules.settings.totem_angle.mode.shatter");
   private final SliderSetting riseHeight = new SliderSetting(this, "modules.settings.totem_angle.rise", "modules.settings.totem_angle.rise.description")
           .min(0.2F).max(5.0F).step(0.1F).currentValue(4.0F);
   private final SliderSetting duration = new SliderSetting(this, "modules.settings.totem_angle.duration", "modules.settings.totem_angle.duration.description")
           .min(0.2F).max(6.0F).step(0.1F).currentValue(3.0F);
   private final BooleanSetting showSelf = new BooleanSetting(this, "modules.settings.totem_angle.self", "modules.settings.totem_angle.self.description").enabled(false);
   private final SliderSetting brightness = new SliderSetting(this, "modules.settings.totem_angle.brightness", "modules.settings.totem_angle.brightness.description")
           .min(0.2F).max(3.0F).step(0.1F).currentValue(1.0F);
   private final SliderSetting transparency = new SliderSetting(this, "modules.settings.totem_angle.alpha", "modules.settings.totem_angle.alpha.description")
           .min(0.05F).max(1.0F).step(0.05F).currentValue(0.72F);
   private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.totem_angle.color_mode");
   private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.totem_angle.color_mode.theme").select();
   private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.totem_angle.color_mode.custom");
   private final ColorSetting color = new ColorSetting(this, "modules.settings.totem_angle.color", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(179, 140, 255, 255))
           .alpha(true);
   private final ColorSetting colorSecond = new ColorSetting(this, "modules.settings.totem_angle.color_second", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(100, 160, 255, 255))
           .alpha(true);

   private final Deque<GhostFrame> ghosts = new ArrayDeque<>();
   private final Deque<ShatterFrame> shatters = new ArrayDeque<>();

   private final EventListener<ReceivePacketEvent> onPacket = event -> {
      if (mc.field_1687 == null || !(event.getPacket() instanceof class_2663 packet) || packet.method_11470() != 35) {
         return;
      }

      class_1297 entity = packet.method_11469(mc.field_1687);
      if (!(entity instanceof class_1309 living)) {
         return;
      }

      if (!this.showSelf.isEnabled() && mc.field_1724 != null && living.method_5628() == mc.field_1724.method_5628()) {
         return;
      }

      if (this.shatter.isSelected()) {
         this.shatters.addLast(createShatterFrame(living));
         while (this.shatters.size() > 48) {
            this.shatters.pollFirst();
         }
      } else {
         this.ghosts.addLast(createGhostFrame(living));
         while (this.ghosts.size() > 48) {
            this.ghosts.pollFirst();
         }
      }
   };

   private final EventListener<Render3DEvent> onRender3D = event -> {
      if (mc.field_1687 == null) {
         clear();
         return;
      }

      class_4587 matrices = event.getMatrices();
      class_243 cameraPos = event.getCamera().method_71156();
      TestikRender3D.setup(true);
      try {
         renderGhosts(matrices, cameraPos, System.currentTimeMillis());
         renderShatters(matrices, cameraPos, System.currentTimeMillis());
      } finally {
         TestikRender3D.reset();
      }
   };

   @Override
   public void onDisable() {
      clear();
   }

   private void clear() {
      this.ghosts.clear();
      this.shatters.clear();
   }

   private void renderGhosts(class_4587 matrices, class_243 cameraPos, long now) {
      float lifeMs = this.duration.getCurrentValue() * 1000.0F;
      float rise = this.riseHeight.getCurrentValue();
      float bright = class_3532.method_15363(this.brightness.getCurrentValue(), 0.2F, 3.0F);
      float alphaSetting = class_3532.method_15363(this.transparency.getCurrentValue(), 0.05F, 1.0F);

      Iterator<GhostFrame> iterator = this.ghosts.iterator();
      while (iterator.hasNext()) {
         GhostFrame frame = iterator.next();
         float t = (now - frame.startTime()) / Math.max(1.0F, lifeMs);
         if (t >= 1.0F) {
            iterator.remove();
            continue;
         }

         double up = rise * easeOut(class_3532.method_15363(t, 0.0F, 0.85F));
         float alpha = class_3532.method_15363((float)easeOutAlpha(t) * bright * alphaSetting, 0.0F, 0.95F);
         ColorRGBA baseColor = this.getTotemColor(t * 360.0F);
         ColorRGBA outline = baseColor.withAlpha(255.0F * alpha);
         ColorRGBA fill = baseColor.withAlpha(45.0F * alpha);
         class_243 origin = frame.pos().method_1031(0.0D, up, 0.0D).method_1020(cameraPos);
         drawGhostModel(matrices, origin, frame.bodyYaw(), frame.width(), frame.height(), fill, outline);
      }
   }

   private void renderShatters(class_4587 matrices, class_243 cameraPos, long now) {
      float lifeMs = this.duration.getCurrentValue() * 1000.0F;
      float power = Math.max(0.2F, this.riseHeight.getCurrentValue() * 0.35F);
      float bright = class_3532.method_15363(this.brightness.getCurrentValue(), 0.2F, 3.0F);
      float alphaSetting = class_3532.method_15363(this.transparency.getCurrentValue(), 0.05F, 1.0F);

      Iterator<ShatterFrame> iterator = this.shatters.iterator();
      while (iterator.hasNext()) {
         ShatterFrame frame = iterator.next();
         float t = (now - frame.startTime()) / Math.max(1.0F, lifeMs);
         if (t >= 1.0F) {
            iterator.remove();
            continue;
         }

         double elapsed = (now - frame.startTime()) / 1000.0D;
         float alpha = class_3532.method_15363((float)alphaProfile(t) * bright * alphaSetting, 0.0F, 0.95F);
         ColorRGBA baseColor = this.getTotemColor(t * 360.0F);
         ColorRGBA outline = baseColor.withAlpha(255.0F * alpha);
         ColorRGBA fill = baseColor.withAlpha(42.0F * alpha);

         for (PartMotion part : frame.parts()) {
            double side = part.side() + part.velSide() * elapsed * power;
            double up = part.up() + part.velUp() * elapsed * power - 2.9D * elapsed * elapsed;
            double front = part.front() + part.velFront() * elapsed * power;
            class_243 center = transformLocal(frame.pos(), frame.bodyYaw(), side, up, front).method_1020(cameraPos);
            drawPartBox(matrices, center, frame.width(), frame.height(), part.id(), fill, outline);
         }
      }
   }

   private GhostFrame createGhostFrame(class_1309 entity) {
      return new GhostFrame(
              new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321()),
              entity.field_6283,
              Math.max(entity.method_17681(), 0.35F),
              Math.max(entity.method_17682(), 0.6F),
              System.currentTimeMillis()
      );
   }

   private ShatterFrame createShatterFrame(class_1309 entity) {
      float width = Math.max(entity.method_17681(), 0.35F);
      float height = Math.max(entity.method_17682(), 0.6F);
      double wScale = width / 0.6D;
      double hScale = height / 1.95D;
      ThreadLocalRandom random = ThreadLocalRandom.current();
      PartMotion[] parts = new PartMotion[PartId.values().length];
      parts[PartId.HEAD.ordinal()] = part(0.0D, 1.60D * hScale, 0.0D, randomSigned(random, 0.22D), 0.32D, randomSigned(random, 0.22D), PartId.HEAD);
      parts[PartId.BODY.ordinal()] = part(0.0D, 1.08D * hScale, 0.0D, randomSigned(random, 0.12D), 0.20D, randomSigned(random, 0.12D), PartId.BODY);
      parts[PartId.ARM_L.ordinal()] = part(-0.48D * wScale, 1.15D * hScale, 0.0D, -0.22D, 0.17D, randomSigned(random, 0.12D), PartId.ARM_L);
      parts[PartId.ARM_R.ordinal()] = part(0.48D * wScale, 1.15D * hScale, 0.0D, 0.22D, 0.17D, randomSigned(random, 0.12D), PartId.ARM_R);
      parts[PartId.LEG_L.ordinal()] = part(-0.16D * wScale, 0.42D * hScale, 0.0D, -0.10D, 0.10D, randomSigned(random, 0.06D), PartId.LEG_L);
      parts[PartId.LEG_R.ordinal()] = part(0.16D * wScale, 0.42D * hScale, 0.0D, 0.10D, 0.10D, randomSigned(random, 0.06D), PartId.LEG_R);
      return new ShatterFrame(new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321()), entity.field_6283, width, height, System.currentTimeMillis(), parts);
   }

   private PartMotion part(double side, double up, double front, double velSide, double velUp, double velFront, PartId id) {
      return new PartMotion(side, up, front, velSide, velUp, velFront, id);
   }

   private void drawGhostModel(class_4587 matrices, class_243 origin, float bodyYaw, float width, float height, ColorRGBA fill, ColorRGBA outline) {
      double wScale = width / 0.6D;
      double hScale = height / 1.95D;
      double depth = Math.max(0.28D, width * 0.40D);
      drawLocalBox(matrices, origin, bodyYaw, 0.0D, 1.70D * hScale, 0.0D, 0.50D * wScale, 0.50D * hScale, 0.50D * wScale, fill, outline);
      drawLocalBox(matrices, origin, bodyYaw, 0.0D, 1.18D * hScale, 0.0D, 0.60D * wScale, 0.55D * hScale, depth, fill, outline);
      drawLocalBox(matrices, origin, bodyYaw, -0.48D * wScale, 1.18D * hScale, 0.02D * wScale, 0.22D * wScale, 0.50D * hScale, 0.24D * wScale, fill, outline);
      drawLocalBox(matrices, origin, bodyYaw, 0.48D * wScale, 1.18D * hScale, 0.02D * wScale, 0.22D * wScale, 0.50D * hScale, 0.24D * wScale, fill, outline);
      drawLocalBox(matrices, origin, bodyYaw, -0.16D * wScale, 0.42D * hScale, 0.0D, 0.26D * wScale, 0.90D * hScale, 0.24D * wScale, fill, outline);
      drawLocalBox(matrices, origin, bodyYaw, 0.16D * wScale, 0.42D * hScale, 0.0D, 0.26D * wScale, 0.90D * hScale, 0.24D * wScale, fill, outline);
   }

   private void drawPartBox(class_4587 matrices, class_243 center, float width, float height, PartId partId, ColorRGBA fill, ColorRGBA outline) {
      double wScale = width / 0.6D;
      double hScale = height / 1.95D;
      double boxW = switch (partId) {
         case HEAD -> 0.50D * wScale;
         case BODY -> 0.60D * wScale;
         case ARM_L, ARM_R -> 0.22D * wScale;
         case LEG_L, LEG_R -> 0.26D * wScale;
      };
      double boxH = switch (partId) {
         case HEAD -> 0.50D * hScale;
         case BODY -> 0.55D * hScale;
         case ARM_L, ARM_R -> 0.50D * hScale;
         case LEG_L, LEG_R -> 0.90D * hScale;
      };
      double boxD = partId == PartId.BODY ? Math.max(0.28D, width * 0.40D) : boxW;
      TestikRender3D.drawBox(matrices, centeredBox(center, boxW, boxH, boxD), fill, outline);
   }

   private void drawLocalBox(class_4587 matrices, class_243 origin, float bodyYaw, double side, double up, double front, double sizeX, double sizeY, double sizeZ, ColorRGBA fill, ColorRGBA outline) {
      class_243 center = transformLocal(origin, bodyYaw, side, up, front);
      TestikRender3D.drawBox(matrices, centeredBox(center, sizeX, sizeY, sizeZ), fill, outline);
   }

   private class_238 centeredBox(class_243 center, double width, double height, double depth) {
      return new class_238(center.field_1352 - width * 0.5D, center.field_1351 - height * 0.5D, center.field_1350 - depth * 0.5D, center.field_1352 + width * 0.5D, center.field_1351 + height * 0.5D, center.field_1350 + depth * 0.5D);
   }

   private class_243 transformLocal(class_243 origin, float bodyYaw, double side, double up, double front) {
      float radians = (float)Math.toRadians(bodyYaw);
      class_243 forward = new class_243(-class_3532.method_15374(radians), 0.0D, class_3532.method_15362(radians));
      class_243 right = new class_243(class_3532.method_15362(radians), 0.0D, class_3532.method_15374(radians));
      return origin.method_1019(right.method_1021(side)).method_1031(0.0D, up, 0.0D).method_1019(forward.method_1021(front));
   }

   private double easeOut(double t) {
      double inv = 1.0D - t;
      return 1.0D - inv * inv * inv;
   }

   private double easeOutAlpha(double t) {
      double inv = 1.0D - t;
      return 0.75D * (1.0D - inv * inv * inv);
   }

   private double alphaProfile(double t) {
      double in = class_3532.method_15350(t / 0.10D, 0.0D, 1.0D);
      double out = class_3532.method_15350((t - 0.65D) / 0.35D, 0.0D, 1.0D);
      return 0.85D * (1.0D - Math.pow(1.0D - in, 3.0D)) * (1.0D - out);
   }

   private double randomSigned(ThreadLocalRandom random, double range) {
      return random.nextDouble(-range, range);
   }

   private ColorRGBA getTotemColor(float index) {
      if (this.colorCustom.isSelected()) {
         float normalized = (index % 360.0F) / 180.0F;
         float mix = normalized > 1.0F ? 2.0F - normalized : normalized;
         return this.color.getColorSafe().mix(this.colorSecond.getColorSafe(), mix);
      }

      return Colors.getAccentColor(index);
   }

   private record GhostFrame(class_243 pos, float bodyYaw, float width, float height, long startTime) {
   }

   private record ShatterFrame(class_243 pos, float bodyYaw, float width, float height, long startTime, PartMotion[] parts) {
   }

   private record PartMotion(double side, double up, double front, double velSide, double velUp, double velFront, PartId id) {
   }

   private enum PartId {
      HEAD,
      BODY,
      ARM_L,
      ARM_R,
      LEG_L,
      LEG_R
   }
}
