package fever.visual.systems.modules.modules.player;


import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BindSetting;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(
   name = "Free Look",
   category = ModuleCategory.MISC,
   desc = "modules.descriptions.freelook"
)
public class Freelook extends BaseModule {
   public static boolean isActive = false;
   public static float x = 0.0F;
   public static float y = 0.0F;
   public static float prevX = 0.0F;
   public static float prevY = 0.0F;
   private float startYaw = 0.0F;
   private float startPitch = 0.0F;
   private class_5498 originalPerspective = class_5498.field_26664;
   private final BindSetting keybind = new BindSetting(this, "freelook.keybind").key(342);
   private final EventListener<ClientPlayerTickEvent> onTick = event -> {
      if (mc.field_1724 == null) {
         if (isActive) {
            isActive = false;
         }
      } else {
         boolean keyPressed = this.keybind.getKey() != -1 && GLFW.glfwGetKey(mc.method_22683().method_4490(), this.keybind.getKey()) == 1;
         if (keyPressed && !isActive) {
            this.activateFreelook();
         } else if (!keyPressed && isActive) {
            this.deactivateFreelook();
         }

         if (!isActive) {
            x = mc.field_1724.method_36454();
            y = mc.field_1724.method_36455();
            prevX = x;
            prevY = y;
         }
      }
   };

   @Override
   public void onEnable() {
      super.onEnable();
      isActive = false;
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (isActive) {
         this.deactivateFreelook();
      }
   }

   private void activateFreelook() {
      if (mc.field_1724 != null && !isActive) {
         this.startYaw = mc.field_1724.method_36454();
         this.startPitch = mc.field_1724.method_36455();
         this.originalPerspective = mc.field_1690.method_31044();
         isActive = true;
         x = this.startYaw;
         y = this.startPitch;
         prevX = x;
         prevY = y;
         mc.field_1690.method_31043(class_5498.field_26665);
      }
   }

   private void deactivateFreelook() {
      if (mc.field_1724 != null && isActive) {
         mc.field_1690.method_31043(this.originalPerspective);
         isActive = false;
      }
   }

   private boolean isFacingTarget(class_1297 target) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         class_243 playerPos = mc.field_1724.method_33571();
         class_243 targetPos = target.method_73189().method_1031(0.0, target.method_17682() / 2.0F, 0.0);
         class_243 direction = targetPos.method_1020(playerPos).method_1029();
         class_243 lookVec = getCurrentLookVector();
         double dot = lookVec.method_1026(direction);
         double angle = Math.acos(class_3532.method_15350(dot, -1.0, 1.0)) * (180.0 / Math.PI);
         return angle < 90.0;
      }
   }

   public static float calculateCorrectYawOffset(float yaw) {
      if (mc.field_1724 == null) {
         return yaw;
      } else {
         double xDiff = mc.field_1724.method_23317() - mc.field_1724.field_6014;
         double zDiff = mc.field_1724.method_23321() - mc.field_1724.field_5969;
         float distSquared = (float)(xDiff * xDiff + zDiff * zDiff);
         float renderYawOffset = mc.field_1724.field_6220;
         float offset = renderYawOffset;
         if (distSquared > 0.0025000002F) {
            offset = (float)class_3532.method_15349(zDiff, xDiff) * 180.0F / (float) Math.PI - 90.0F;
         }

         if (mc.field_1724.field_6251 > 0.0F) {
            offset = yaw;
         }

         float yawOffsetDiff = class_3532.method_15393(yaw - (renderYawOffset + class_3532.method_15393(offset - renderYawOffset) * 0.3F));
         yawOffsetDiff = class_3532.method_15363(yawOffsetDiff, -75.0F, 75.0F);
         renderYawOffset = yaw - yawOffsetDiff;
         if (yawOffsetDiff * yawOffsetDiff > 2500.0F) {
            renderYawOffset += yawOffsetDiff * 0.2F;
         }

         return renderYawOffset;
      }
   }

   public float getRotYaw() {
      return x;
   }

   public void setRotYaw(float rotYaw) {
      prevX = x;
      x = rotYaw;
   }

   public float getRotPitch() {
      return y;
   }

   public void setRotPitch(float rotPitch) {
      prevY = y;
      y = rotPitch;
   }

   public static float getYaw(float partialTicks) {
      return partialTicks == 1.0F ? x : prevX + (x - prevX) * partialTicks;
   }

   public static float getPitch(float partialTicks) {
      return partialTicks == 1.0F ? y : prevY + (y - prevY) * partialTicks;
   }

   public static float getActualYaw(float partialTicks) {
      return isActive ? getYaw(partialTicks) : (mc.field_1724 != null ? mc.field_1724.method_5705(partialTicks) : 0.0F);
   }

   public static float getActualPitch(float partialTicks) {
      return isActive ? getPitch(partialTicks) : (mc.field_1724 != null ? mc.field_1724.method_5695(partialTicks) : 0.0F);
   }

   public static class_243 getActualLookVector(float partialTicks) {
      if (!isActive && mc.field_1724 != null) {
         return mc.field_1724.method_5828(partialTicks);
      } else if (!isActive) {
         return class_243.field_1353;
      } else {
         float yaw = getYaw(partialTicks);
         float pitch = getPitch(partialTicks);
         float f = pitch * (float) (Math.PI / 180.0);
         float f1 = -yaw * (float) (Math.PI / 180.0);
         float f2 = class_3532.method_15362(f1);
         float f3 = class_3532.method_15374(f1);
         float f4 = class_3532.method_15362(f);
         float f5 = class_3532.method_15374(f);
         return new class_243(f3 * f4, -f5, f2 * f4);
      }
   }

   public static class_243 getCurrentLookVector() {
      if (!isActive) {
         return mc.field_1724 != null ? mc.field_1724.method_5828(1.0F) : class_243.field_1353;
      } else {
         float yaw = x;
         float pitch = y;
         float f = pitch * (float) (Math.PI / 180.0);
         float f1 = -yaw * (float) (Math.PI / 180.0);
         float f2 = class_3532.method_15362(f1);
         float f3 = class_3532.method_15374(f1);
         float f4 = class_3532.method_15362(f);
         float f5 = class_3532.method_15374(f);
         return new class_243(f3 * f4, -f5, f2 * f4);
      }
   }
}
