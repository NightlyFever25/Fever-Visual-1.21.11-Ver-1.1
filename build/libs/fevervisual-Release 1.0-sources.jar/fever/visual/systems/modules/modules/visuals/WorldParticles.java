package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.BufferRenderer;

import fever.visual.utility.render.compat.GlStateManager.DstFactor;
import fever.visual.utility.render.compat.GlStateManager.SrcFactor;
import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import fever.visual.utility.render.Utils;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.*;
//Да давай пасти бездарность :)
//Made by FeverVisuals (NightlyFever)
@ModuleInfo(name = "World Particles", category = ModuleCategory.VISUALS, desc = "modules.descriptions.world_particles")
public class WorldParticles extends BaseModule implements IMinecraft {

    private final ModeSetting particleType = new ModeSetting(this, "modules.settings.world_particles.particle_type");
    private final ModeSetting.Value star = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.star").select();
    private final ModeSetting.Value crown = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.crown");
    private final ModeSetting.Value dollar = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.dollar");
    private final ModeSetting.Value firefly = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.firefly");
    private final ModeSetting.Value heart = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.heart");
    private final ModeSetting.Value lightning = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.lightning");
    private final ModeSetting.Value line = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.line");
    private final ModeSetting.Value point = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.point");
    private final ModeSetting.Value rhombus = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.rhombus");
    private final ModeSetting.Value snowflake = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.snowflake");
    private final ModeSetting.Value spark = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.spark");
    private final ModeSetting.Value moon = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.moon");
    private final ModeSetting.Value feather = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.feather");
    private final ModeSetting.Value genshin = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.genshin");
    private final ModeSetting.Value randomType = new ModeSetting.Value(this.particleType, "modules.settings.world_particles.particle_type.random");

    private final ModeSetting animationMode = new ModeSetting(this, "modules.settings.world_particles.animation_mode", "Режим анимации частиц");
    private final ModeSetting.Value floatMode = new ModeSetting.Value(this.animationMode, "modules.settings.world_particles.animation_mode.float", "Парение").select();
    private final ModeSetting.Value snowMode = new ModeSetting.Value(this.animationMode, "modules.settings.world_particles.animation_mode.snow", "Снегопад");
    private final ModeSetting.Value rainMode = new ModeSetting.Value(this.animationMode, "modules.settings.world_particles.animation_mode.rain", "Дождь");

    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.world_particles.color_mode");
    private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.world_particles.color_mode.theme").select();
    private final ModeSetting.Value colorRainbow = new ModeSetting.Value(this.colorMode, "modules.settings.world_particles.color_mode.rainbow", "", () -> true);
    private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.world_particles.color_mode.custom");

    private final ColorSetting customColor = new ColorSetting(this, "modules.settings.world_particles.custom_color", () -> !colorCustom.isSelected())
            .color(new ColorRGBA(255, 100, 100, 255))
            .alpha(true);
    private final ColorSetting customColorSecond = new ColorSetting(this, "modules.settings.world_particles.custom_color_second", () -> !colorCustom.isSelected())
            .color(new ColorRGBA(100, 160, 255, 255))
            .alpha(true);

    private final SliderSetting floatSpeed = new SliderSetting(this, "modules.settings.world_particles.float_speed", "Скорость парения")
            .min(0.1F).max(2.0F).step(0.05F).currentValue(0.5F);
    private final SliderSetting snowSpeed = new SliderSetting(this, "modules.settings.world_particles.snow_speed", "Скорость снегопада")
            .min(0.05F).max(1.0F).step(0.05F).currentValue(0.2F);
    private final SliderSetting rainSpeed = new SliderSetting(this, "modules.settings.world_particles.rain_speed", "Скорость дождя")
            .min(0.05F).max(0.8F).step(0.05F).currentValue(0.2F);

    private final SliderSetting horizontalDrift = new SliderSetting(this, "modules.settings.world_particles.horizontal_drift", "Горизонтальный дрейф")
            .min(0.0F).max(1.0F).step(0.05F).currentValue(0.3F);

    private final SliderSetting particleOpacity = new SliderSetting(this, "modules.settings.world_particles.opacity", "Прозрачность частиц")
            .min(0.1F).max(1.0F).step(0.05F).currentValue(0.8F);

    private final SliderSetting particleCount = new SliderSetting(this, "modules.settings.world_particles.count", "Количество частиц")
            .min(50.0F).max(500.0F).step(10.0F).currentValue(200.0F);
    private final SliderSetting particleSize = new SliderSetting(this, "modules.settings.world_particles.size", "Размер частиц")
            .min(0.1F).max(2.0F).step(0.05F).currentValue(0.8F);
    private final SliderSetting particleLife = new SliderSetting(this, "modules.settings.world_particles.life", "Время жизни (мс)")
            .min(500.0F).max(10000.0F).step(100.0F).currentValue(2000.0F);
    private final SliderSetting spawnRadius = new SliderSetting(this, "modules.settings.world_particles.spawn_radius", "Радиус спавна")
            .min(10.0F).max(64.0F).step(1.0F).currentValue(32.0F);
    private final SliderSetting yOffset = new SliderSetting(this, "modules.settings.world_particles.y_offset", "Высота спавна")
            .min(0.0F).max(20.0F).step(0.5F).currentValue(5.0F);

    private final SliderSetting bounceDamping = new SliderSetting(this, "modules.settings.world_particles.bounce_damping", "Затухание отскока")
            .min(0.3F).max(0.9F).step(0.05F).currentValue(0.6F);
    private final SliderSetting bounceThreshold = new SliderSetting(this, "modules.settings.world_particles.bounce_threshold", "Порог отскока")
            .min(0.05F).max(0.3F).step(0.01F).currentValue(0.1F);

    private final BooleanSetting useGravity = new BooleanSetting(this, "modules.settings.world_particles.use_gravity", "Частицы падают вниз").enabled(true);
    private final BooleanSetting fadeOut = new BooleanSetting(this, "modules.settings.world_particles.fade_out", "Частицы исчезают плавно").enabled(true);
    private final BooleanSetting enableBounce = new BooleanSetting(this, "modules.settings.world_particles.enable_bounce", "Частицы отскакивают от земли").enabled(true);
    private final BooleanSetting collisionDetection = new BooleanSetting(this, "modules.settings.world_particles.collision_detection", "Частицы не застревают в блоках").enabled(true);

    private final List<WorldParticle> particles = new ArrayList<>();
    private final Map<class_2960, List<WorldParticle>> particlesByTexture = new HashMap<>();
    private final Random rand = new Random();
    private long lastRenderTime = System.currentTimeMillis();
    private long lastUpdateTime = System.currentTimeMillis();
    private boolean tickFloatMode;
    private boolean tickSnowMode;
    private boolean tickRainMode;
    private boolean tickGravity;
    private boolean tickBounce;
    private boolean tickCollision;
    private float tickFloatSpeed;
    private float tickSnowSpeed;
    private float tickRainSpeed;
    private float tickDrift;
    private float tickBounceDamping;
    private float tickBounceThreshold;
    private float tickSpawnRadius;
    private float tickYOffset;

    private static final Map<String, class_2960> TEXTURES = new HashMap<>();
    private static final List<class_2960> RANDOM_TEXTURES = new ArrayList<>();

    static {
        TEXTURES.put("crown", class_2960.method_60655("fevervisual", "textures/particles/crown.png"));
        TEXTURES.put("dollar", class_2960.method_60655("fevervisual", "textures/particles/dollar.png"));
        TEXTURES.put("firefly", class_2960.method_60655("fevervisual", "textures/particles/firefly.png"));
        TEXTURES.put("heart", class_2960.method_60655("fevervisual", "textures/particles/heart.png"));
        TEXTURES.put("thor", class_2960.method_60655("fevervisual", "textures/particles/thor.png"));
        TEXTURES.put("line", class_2960.method_60655("fevervisual", "textures/particles/line.png"));
        TEXTURES.put("point", class_2960.method_60655("fevervisual", "textures/particles/point.png"));
        TEXTURES.put("rhombus", class_2960.method_60655("fevervisual", "textures/particles/rhombus.png"));
        TEXTURES.put("snowflake", class_2960.method_60655("fevervisual", "textures/particles/snowflake.png"));
        TEXTURES.put("spark", class_2960.method_60655("fevervisual", "textures/particles/spark.png"));
        TEXTURES.put("star", class_2960.method_60655("fevervisual", "textures/particles/star.png"));
        TEXTURES.put("moon", class_2960.method_60655("fevervisual", "textures/particles/moon.png"));
        TEXTURES.put("feather", class_2960.method_60655("fevervisual", "textures/particles/feather.png"));
        TEXTURES.put("genshin", class_2960.method_60655("fevervisual", "textures/particles/genshin.png"));
        RANDOM_TEXTURES.addAll(TEXTURES.values());
    }

    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        long now = System.currentTimeMillis();
        float deltaTime = Math.min(1.0F, (now - lastUpdateTime) / 1000.0F);
        lastUpdateTime = now;

        cacheTickSettings();

        updateParticles(deltaTime);
        spawnParticles();
    };

    private void cacheTickSettings() {
        this.tickFloatMode = this.floatMode.isSelected();
        this.tickSnowMode = this.snowMode.isSelected();
        this.tickRainMode = this.rainMode.isSelected();
        this.tickGravity = this.useGravity.isEnabled();
        this.tickBounce = this.enableBounce.isEnabled();
        this.tickCollision = this.collisionDetection.isEnabled();
        this.tickFloatSpeed = this.floatSpeed.getCurrentValue();
        this.tickSnowSpeed = this.snowSpeed.getCurrentValue();
        this.tickRainSpeed = this.rainSpeed.getCurrentValue();
        this.tickDrift = this.horizontalDrift.getCurrentValue();
        this.tickBounceDamping = this.bounceDamping.getCurrentValue();
        this.tickBounceThreshold = this.bounceThreshold.getCurrentValue();
        this.tickSpawnRadius = this.spawnRadius.getCurrentValue();
        this.tickYOffset = this.yOffset.getCurrentValue();
    }

    private final EventListener<Render3DEvent> onRender3D = new EventListener<>() {
        @Override
        public void onEvent(Render3DEvent event) {
            if (particles.isEmpty()) return;

            renderParticles(event.getMatrices(), event.getTickDelta());
        }

        @Override
        public int getPriority() {
            return 100;
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
        particles.clear();
        lastRenderTime = System.currentTimeMillis();
        lastUpdateTime = System.currentTimeMillis();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        particles.clear();
    }

    private void updateParticles(float deltaTime) {
        long currentTime = System.currentTimeMillis();

        for (WorldParticle particle : particles) {
            particle.update(deltaTime);
        }

        for (int i = particles.size() - 1; i >= 0; i--) {
            WorldParticle particle = particles.get(i);
            if (currentTime - particle.spawnTime > particleLife.getCurrentValue()) {
                particles.remove(i);
            }
        }
    }

    private void spawnParticles() {
        int targetCount = (int) particleCount.getCurrentValue();
        int toSpawn = targetCount - particles.size();

        if (toSpawn <= 0) return;

        toSpawn = Math.min(toSpawn, 8);

        for (int i = 0; i < toSpawn; i++) {
            class_2960 texture = getParticleTexture();
            ColorRGBA color = getParticleColor(i);

            float x, y, z;
            float radius = tickSpawnRadius;
            float angle = (float) (rand.nextDouble() * Math.PI * 2);
            float distance = rand.nextFloat() * radius;

            x = (float) (mc.field_1724.method_23317() + Math.cos(angle) * distance);
            z = (float) (mc.field_1724.method_23321() + Math.sin(angle) * distance);

            if (tickRainMode) {
                y = (float) (mc.field_1724.method_23318() + tickYOffset + 10.0F + rand.nextFloat() * 15.0F);
            } else {
                y = (float) (mc.field_1724.method_23318() + tickYOffset + rand.nextFloat() * 8.0F - 4.0F);
            }

            float size = particleSize.getCurrentValue() * (0.5F + rand.nextFloat() * 0.8F);

            WorldParticle particle = new WorldParticle(
                    texture, x, y, z, color, size,
                    animationMode.getValue().getName()
            );
            particles.add(particle);
        }
    }

    private void renderParticles(class_4587 matrix, float tickDelta) {
        if (particles.isEmpty()) return;

        setupRenderState();
        class_4184 camera = mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();
        Quaternionf cameraRotation = camera.method_23767();
        long now = System.currentTimeMillis();
        float opacity = particleOpacity.getCurrentValue();
        float life = particleLife.getCurrentValue();
        boolean shouldFadeOut = fadeOut.isEnabled();

        class_289 tessellator = class_289.method_1348();

        for (List<WorldParticle> bucket : particlesByTexture.values()) {
            bucket.clear();
        }

        for (WorldParticle particle : particles) {
            if (Utils.isInViewHemisphere(camera, particle.position.field_1352, particle.position.field_1351, particle.position.field_1350, 2.0)) {
                particlesByTexture.computeIfAbsent(particle.texture, k -> new ArrayList<>()).add(particle);
            }
        }

        for (Map.Entry<class_2960, List<WorldParticle>> entry : particlesByTexture.entrySet()) {
            if (entry.getValue().isEmpty()) {
                continue;
            }
            RenderSystem.setShaderTexture(0, entry.getKey());
            class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1575);

            for (WorldParticle particle : entry.getValue()) {
                renderParticle(buffer, matrix, particle, cameraPos, cameraRotation, tickDelta, now, opacity, life, shouldFadeOut);
            }

            BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
        }

        resetRenderState();
    }

    private void renderParticle(class_287 buffer, class_4587 matrix, WorldParticle particle, class_243 cameraPos, Quaternionf cameraRotation, float tickDelta, long now, float opacity, float life, boolean shouldFadeOut) {
        matrix.method_22903();

        double px = class_3532.method_16436(tickDelta, particle.prevPosition.field_1352, particle.position.field_1352) - cameraPos.field_1352;
        double py = class_3532.method_16436(tickDelta, particle.prevPosition.field_1351, particle.position.field_1351) - cameraPos.field_1351;
        double pz = class_3532.method_16436(tickDelta, particle.prevPosition.field_1350, particle.position.field_1350) - cameraPos.field_1350;
        matrix.method_22904(px, py, pz);
        matrix.method_22907(cameraRotation);

        Matrix4f m = matrix.method_23760().method_23761();
        float halfSize = particle.size / 2.0F;

        float alpha = opacity;
        if (shouldFadeOut) {
            long age = now - particle.spawnTime;
            if (age < 100) {
                alpha *= age / 100.0F;
            } else if (age > life - 200) {
                alpha *= (life - age) / 200.0F;
            }
            alpha = class_3532.method_15363(alpha, 0.0F, 1.0F);
        }

        int color = (class_3532.method_15340((int) (alpha * 255), 0, 255) << 24) | (particle.color.getRGB() & 0x00FFFFFF);

        if (tickSnowMode && particle.rotatesSnowflake) {
            float rotation = (now + particle.spawnTime) % 360;
            matrix.method_22907(class_7833.field_40718.rotationDegrees(rotation));
        }
        if (particle.rotate180) {
            matrix.method_22907(class_7833.field_40718.rotationDegrees(180));
        }

        drawQuad(buffer, m, halfSize, color);

        matrix.method_22909();
    }

    private void drawQuad(class_287 buffer, Matrix4f matrix, float size, int color) {
        float r = ((color >> 16) & 0xFF) / 255.0F;
        float g = ((color >> 8) & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        float a = ((color >> 24) & 0xFF) / 255.0F;

        buffer.method_22918(matrix, -size, -size, 0.0F).method_22913(0.0F, 0.0F).method_22915(r, g, b, a);
        buffer.method_22918(matrix, size, -size, 0.0F).method_22913(1.0F, 0.0F).method_22915(r, g, b, a);
        buffer.method_22918(matrix, size, size, 0.0F).method_22913(1.0F, 1.0F).method_22915(r, g, b, a);
        buffer.method_22918(matrix, -size, size, 0.0F).method_22913(0.0F, 1.0F).method_22915(r, g, b, a);
    }

    private void setupRenderState() {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA, SrcFactor.ONE, DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
    }

    private void resetRenderState() {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.disableBlend();
    }

    private class_2960 getParticleTexture() {
        if (randomType.isSelected()) {
            return RANDOM_TEXTURES.get(rand.nextInt(RANDOM_TEXTURES.size()));
        } else if (crown.isSelected()) return TEXTURES.get("crown");
        else if (dollar.isSelected()) return TEXTURES.get("dollar");
        else if (firefly.isSelected()) return TEXTURES.get("firefly");
        else if (heart.isSelected()) return TEXTURES.get("heart");
        else if (lightning.isSelected()) return TEXTURES.get("thor");
        else if (line.isSelected()) return TEXTURES.get("line");
        else if (point.isSelected()) return TEXTURES.get("point");
        else if (rhombus.isSelected()) return TEXTURES.get("rhombus");
        else if (snowflake.isSelected()) return TEXTURES.get("snowflake");
        else if (spark.isSelected()) return TEXTURES.get("spark");
        else if (star.isSelected()) return TEXTURES.get("star");
        else if (moon.isSelected()) return TEXTURES.get("moon");
        else if (feather.isSelected()) return TEXTURES.get("feather");
        else if (genshin.isSelected()) return TEXTURES.get("genshin");
        else return TEXTURES.get("star");
    }

    private ColorRGBA getParticleColor(int index) {
        if (colorCustom.isSelected()) {
            return customColor.getColor().mix(customColorSecond.getColor(), (index % 20) / 19.0F);
        }

        return Colors.getAccentColor(index * 12.0F);
    }

    private class WorldParticle {
        private final class_2960 texture;
        private class_243 position;
        private class_243 velocity;
        private final ColorRGBA color;
        private final float size;
        private final long spawnTime;
        private class_243 prevPosition;
        private final String animationType;
        private final boolean rotatesSnowflake;
        private final boolean rotate180;
        private double groundY = -Double.MAX_VALUE;

        public WorldParticle(class_2960 texture, float x, float y, float z, ColorRGBA color, float size, String animationType) {
            this.texture = texture;
            this.position = new class_243(x, y, z);
            this.prevPosition = this.position;
            this.color = color;
            this.size = size;
            this.spawnTime = System.currentTimeMillis();
            this.animationType = animationType;
            this.rotatesSnowflake = texture.equals(TEXTURES.get("snowflake"));
            this.rotate180 = texture.equals(TEXTURES.get("heart"))
                    || texture.equals(TEXTURES.get("crown"))
                    || texture.equals(TEXTURES.get("moon"))
                    || texture.equals(TEXTURES.get("thor"))
                    || texture.equals(TEXTURES.get("dollar"));

            if (tickFloatMode) {
                float speed = tickFloatSpeed;
                this.velocity = new class_243(
                        (rand.nextDouble() - 0.5) * 0.4 * speed,
                        (rand.nextDouble() - 0.5) * 0.3 * speed,
                        (rand.nextDouble() - 0.5) * 0.4 * speed
                );
            } else if (tickSnowMode) {
                float speed = tickSnowSpeed;
                float drift = tickDrift;
                this.velocity = new class_243(
                        (rand.nextDouble() - 0.5) * 0.2 * drift,
                        -0.12 * speed - rand.nextDouble() * 0.03,
                        (rand.nextDouble() - 0.5) * 0.2 * drift
                );
            } else if (tickRainMode) {
                float speed = tickRainSpeed;
                float drift = tickDrift * 0.3f;
                this.velocity = new class_243(
                        (rand.nextDouble() - 0.5) * 0.08 * drift,
                        -0.15 * speed - rand.nextDouble() * 0.03,
                        (rand.nextDouble() - 0.5) * 0.08 * drift
                );
            } else {
                float speed = tickFloatSpeed;
                this.velocity = new class_243(
                        (rand.nextDouble() - 0.5) * 0.4 * speed,
                        (rand.nextDouble() - 0.5) * 0.3 * speed,
                        (rand.nextDouble() - 0.5) * 0.4 * speed
                );
            }
        }

        private boolean isInsideBlock(class_243 pos) {
            if (mc.field_1687 == null) return false;
            class_2338 blockPos = new class_2338((int) Math.floor(pos.field_1352), (int) Math.floor(pos.field_1351), (int) Math.floor(pos.field_1350));
            return !mc.field_1687.method_22347(blockPos) && !mc.field_1687.method_8320(blockPos).method_51176();
        }

        private class_243 pushOutOfBlock(class_243 pos) {
            if (mc.field_1687 == null) return pos;

            class_2338 blockPos = new class_2338((int) Math.floor(pos.field_1352), (int) Math.floor(pos.field_1351), (int) Math.floor(pos.field_1350));
            if (!mc.field_1687.method_22347(blockPos) && !mc.field_1687.method_8320(blockPos).method_51176()) {
                double newY = blockPos.method_10264() + 0.5;
                return new class_243(pos.field_1352, newY, pos.field_1350);
            }
            return pos;
        }

        public void update(float deltaTime) {
            prevPosition = position;

            if (tickFloatMode && tickCollision) {
                if (isInsideBlock(position)) {
                    position = pushOutOfBlock(position);
                    velocity = new class_243(
                            velocity.field_1352 * -0.5,
                            Math.abs(velocity.field_1351) * 0.5,
                            velocity.field_1350 * -0.5
                    );
                }
            }

            if (groundY == -Double.MAX_VALUE && mc.field_1687 != null && !tickFloatMode) {
                class_2338 blockPos = class_2338.method_49638(position);
                groundY = blockPos.method_10264();
                int searchBottom = Math.max(mc.field_1687.method_31607(), (int)position.field_1351 - 48);
                for (int y = (int) position.field_1351; y >= searchBottom; y--) {
                    class_2338 checkPos = new class_2338((int) position.field_1352, y, (int) position.field_1350);
                    if (!mc.field_1687.method_22347(checkPos)) {
                        groundY = y + 1.0;
                        break;
                    }
                }
            }

            if (tickGravity) {
                if (tickFloatMode) {
                    velocity = velocity.method_1031(0, -0.05 * deltaTime, 0);
                } else if (tickSnowMode) {
                    velocity = velocity.method_1031(0, -0.4 * deltaTime, 0);
                } else if (tickRainMode) {
                    velocity = velocity.method_1031(0, -0.35 * deltaTime, 0);
                }
            }

            class_243 newPosition = position.method_1019(velocity.method_1021(deltaTime * 60.0));

            if (tickFloatMode && tickCollision) {
                if (isInsideBlock(newPosition)) {
                    newPosition = pushOutOfBlock(newPosition);
                    velocity = new class_243(
                            velocity.field_1352 * -0.3,
                            Math.abs(velocity.field_1351) * 0.4,
                            velocity.field_1350 * -0.3
                    );
                }
            }

            position = newPosition;

            if (tickBounce && groundY != -Double.MAX_VALUE && !tickFloatMode) {
                if (position.field_1351 <= groundY + 0.05) {
                    position = new class_243(position.field_1352, groundY + 0.05, position.field_1350);

                    if (Math.abs(velocity.field_1351) > tickBounceThreshold) {
                        velocity = new class_243(
                                velocity.field_1352 * tickBounceDamping,
                                -velocity.field_1351 * tickBounceDamping,
                                velocity.field_1350 * tickBounceDamping
                        );

                        if (Math.abs(velocity.field_1351) < tickBounceThreshold) {
                            velocity = new class_243(velocity.field_1352, 0, velocity.field_1350);
                        }
                    } else {
                        velocity = new class_243(velocity.field_1352 * 0.95, 0, velocity.field_1350 * 0.95);
                    }
                }
            }

            if (tickFloatMode) {
                if (rand.nextDouble() < 0.02) {
                    float speed = tickFloatSpeed;
                    velocity = velocity.method_1031(
                            (rand.nextDouble() - 0.5) * 0.05 * speed,
                            (rand.nextDouble() - 0.5) * 0.03 * speed,
                            (rand.nextDouble() - 0.5) * 0.05 * speed
                    );
                    velocity = velocity.method_1021(0.98);
                }

                double maxSpeed = 0.5 * tickFloatSpeed;
                if (velocity.method_1033() > maxSpeed) {
                    velocity = velocity.method_1029().method_1021(maxSpeed);
                }

                if (mc.field_1724 != null) {
                    double minY = mc.field_1724.method_23318() - 5;
                    double maxY = mc.field_1724.method_23318() + 8;
                    if (position.field_1351 < minY) {
                        position = new class_243(position.field_1352, minY, position.field_1350);
                        velocity = new class_243(velocity.field_1352, Math.abs(velocity.field_1351) * 0.5, velocity.field_1350);
                    } else if (position.field_1351 > maxY) {
                        position = new class_243(position.field_1352, maxY, position.field_1350);
                        velocity = new class_243(velocity.field_1352, -Math.abs(velocity.field_1351) * 0.5, velocity.field_1350);
                    }
                }

            } else if (tickSnowMode) {
                if (rand.nextDouble() < 0.03) {
                    float drift = tickDrift;
                    velocity = velocity.method_1031(
                            (rand.nextDouble() - 0.5) * 0.03 * drift,
                            0,
                            (rand.nextDouble() - 0.5) * 0.03 * drift
                    );
                }

                velocity = velocity.method_1021(0.995);

                if (mc.field_1724 != null && position.field_1351 < mc.field_1724.method_23318() - 5) {
                    position = new class_243(
                            position.field_1352,
                            mc.field_1724.method_23318() + tickYOffset + 15,
                            position.field_1350
                    );
                    float speed = tickSnowSpeed;
                    float drift = tickDrift;
                    velocity = new class_243(
                            velocity.field_1352 * 0.8,
                            -0.12 * speed,
                            velocity.field_1350 * 0.8
                    );
                }

            } else if (tickRainMode) {
                velocity = velocity.method_1021(0.999);

                if (position.field_1351 <= groundY + 0.1 && mc.field_1724 != null) {
                    position = new class_243(
                            mc.field_1724.method_23317() + (rand.nextDouble() - 0.5) * tickSpawnRadius,
                            mc.field_1724.method_23318() + tickYOffset + 15,
                            mc.field_1724.method_23321() + (rand.nextDouble() - 0.5) * tickSpawnRadius
                    );
                    float speed = tickRainSpeed;
                    float drift = tickDrift * 0.3f;
                    velocity = new class_243(
                            (rand.nextDouble() - 0.5) * 0.08 * drift,
                            -0.15 * speed,
                            (rand.nextDouble() - 0.5) * 0.08 * drift
                    );
                }
            }

            if (mc.field_1724 != null && !tickFloatMode) {
                double distToPlayer = position.method_1022(mc.field_1724.method_73189());
                if (distToPlayer > tickSpawnRadius * 2) {
                    position = new class_243(
                            mc.field_1724.method_23317() + (rand.nextDouble() - 0.5) * tickSpawnRadius,
                            mc.field_1724.method_23318() + tickYOffset + (rand.nextDouble() - 0.5) * 8,
                            mc.field_1724.method_23321() + (rand.nextDouble() - 0.5) * tickSpawnRadius
                    );
                }
            }
        }

        public class_243 getInterpolatedPosition(float tickDelta) {
            double x = prevPosition.field_1352 + (position.field_1352 - prevPosition.field_1352) * tickDelta;
            double y = prevPosition.field_1351 + (position.field_1351 - prevPosition.field_1351) * tickDelta;
            double z = prevPosition.field_1350 + (position.field_1350 - prevPosition.field_1350) * tickDelta;
            return new class_243(x, y, z);
        }
    }
}
