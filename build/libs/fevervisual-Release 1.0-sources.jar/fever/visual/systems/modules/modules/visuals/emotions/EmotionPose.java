package fever.visual.systems.modules.modules.visuals.emotions;

import net.minecraft.class_3532;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_630;

public class EmotionPose {
   public float headRotX, headRotY, headRotZ;
   public float bodyRotX, bodyRotY, bodyRotZ;
   public float rightArmRotX, rightArmRotY, rightArmRotZ;
   public float leftArmRotX, leftArmRotY, leftArmRotZ;
   public float rightLegRotX, rightLegRotY, rightLegRotZ;
   public float leftLegRotX, leftLegRotY, leftLegRotZ;
   public float headOffX, headOffY, headOffZ;
   public float bodyOffX, bodyOffY, bodyOffZ;
   public float rightArmOffX, rightArmOffY, rightArmOffZ;
   public float leftArmOffX, leftArmOffY, leftArmOffZ;
   public float rightLegOffX, rightLegOffY, rightLegOffZ;
   public float leftLegOffX, leftLegOffY, leftLegOffZ;
   public float upperOffY, upperOffZ;

   public void lean(float angle) {
      this.bodyRotX += angle;
      this.headRotX += angle;
      this.rightArmRotX += angle;
      this.leftArmRotX += angle;
      float cos = (float)Math.cos(angle);
      float sin = (float)Math.sin(angle);
      float torsoY = 12.0F - 12.0F * cos;
      float torsoZ = -12.0F * sin;
      this.headOffY += torsoY;
      this.headOffZ += torsoZ;
      this.bodyOffY += torsoY;
      this.bodyOffZ += torsoZ;
      float armY = 12.0F - 10.0F * cos - 2.0F;
      float armZ = -10.0F * sin;
      this.rightArmOffY += armY;
      this.rightArmOffZ += armZ;
      this.leftArmOffY += armY;
      this.leftArmOffZ += armZ;
   }

   public void applyTo(class_572<?> model, float weight, float walkAmount) {
      if (weight <= 0.0F) {
         return;
      }
      float w = Math.min(weight, 1.0F);
      float legW = w * (1.0F - class_3532.method_15363(walkAmount, 0.0F, 1.0F));
      applyAdditive(model.field_3398, this.headRotX, this.headRotY, this.headRotZ, this.headOffX, this.headOffY + this.upperOffY, this.headOffZ + this.upperOffZ, w);
      apply(model.field_3391, this.bodyRotX, this.bodyRotY, this.bodyRotZ, this.bodyOffX, this.bodyOffY + this.upperOffY, this.bodyOffZ + this.upperOffZ, w);
      apply(model.field_3401, this.rightArmRotX, this.rightArmRotY, this.rightArmRotZ, this.rightArmOffX, this.rightArmOffY + this.upperOffY, this.rightArmOffZ + this.upperOffZ, w);
      apply(model.field_27433, this.leftArmRotX, this.leftArmRotY, this.leftArmRotZ, this.leftArmOffX, this.leftArmOffY + this.upperOffY, this.leftArmOffZ + this.upperOffZ, w);
      apply(model.field_3392, this.rightLegRotX, this.rightLegRotY, this.rightLegRotZ, this.rightLegOffX, this.rightLegOffY, this.rightLegOffZ, legW);
      apply(model.field_3397, this.leftLegRotX, this.leftLegRotY, this.leftLegRotZ, this.leftLegOffX, this.leftLegOffY, this.leftLegOffZ, legW);
   }

   private static void applyAdditive(class_630 part, float rotX, float rotY, float rotZ, float offX, float offY, float offZ, float weight) {
      class_5603 base = part.method_41921();
      part.field_3654 += rotX * weight;
      part.field_3675 += rotY * weight;
      part.field_3674 += rotZ * weight;
      part.field_3657 = class_3532.method_16439(weight, part.field_3657, base.comp_2997() + offX);
      part.field_3656 = class_3532.method_16439(weight, part.field_3656, base.comp_2998() + offY);
      part.field_3655 = class_3532.method_16439(weight, part.field_3655, base.comp_2999() + offZ);
   }

   private static void apply(class_630 part, float rotX, float rotY, float rotZ, float offX, float offY, float offZ, float weight) {
      class_5603 base = part.method_41921();
      part.field_3654 = class_3532.method_16439(weight, part.field_3654, rotX);
      part.field_3675 = class_3532.method_16439(weight, part.field_3675, rotY);
      part.field_3674 = class_3532.method_16439(weight, part.field_3674, rotZ);
      part.field_3657 = class_3532.method_16439(weight, part.field_3657, base.comp_2997() + offX);
      part.field_3656 = class_3532.method_16439(weight, part.field_3656, base.comp_2998() + offY);
      part.field_3655 = class_3532.method_16439(weight, part.field_3655, base.comp_2999() + offZ);
   }
}
