package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.BufferRenderer;

import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.utility.render.compat.GlStateManager;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@ModuleInfo(name = "Hit Bubbles", category = ModuleCategory.VISUALS, desc = "Пузырьки при ударе")
@Environment(EnvType.CLIENT)
public class HitBubbles extends BaseModule {

    private static final class_2960 BUBBLE_TEX = FeverVisual.id("textures/bubble.png");
    private static final long GROW_MS = 400L;
    private static final long COOLDOWN_MS = 100L;
    private static final float MAX_ROTATION = 45.0f;

    private final ModeSetting mode = new ModeSetting(this, "Mode");
    private final ModeSetting.Value textureMode = new ModeSetting.Value(this.mode, "Texture").select();
    private final ModeSetting.Value rippleMode = new ModeSetting.Value(this.mode, "Ripple");

    private final SliderSetting size = new SliderSetting(this, "modules.settings.hit_bubbles.size", "Размер пузырька")
            .min(0.3f).max(2.0f).step(0.05f).currentValue(1.0f);
    private final SliderSetting lifeTime = new SliderSetting(this, "modules.settings.hit_bubbles.life_time", "Время жизни (сек)")
            .min(0.1f).max(0.6f).step(0.05f).currentValue(0.2f);
    private final SliderSetting strength = new SliderSetting(this, "Strength", () -> !this.rippleMode.isSelected())
            .min(0.2f).max(3.0f).step(0.1f).currentValue(1.5f);
    private final BooleanSetting warp = new BooleanSetting(this, "Warp", () -> !this.rippleMode.isSelected());
    private final SliderSetting warpStrength = new SliderSetting(this, "Warp Strength", () -> !this.rippleMode.isSelected() || !this.warp.isEnabled())
            .min(0.1f).max(2.0f).step(0.1f).currentValue(0.5f);
    private final SliderSetting saturation = new SliderSetting(this, "Saturation", () -> !this.rippleMode.isSelected())
            .min(-1.0f).max(1.0f).step(0.05f).currentValue(1.0f);
    private final BooleanSetting tint = new BooleanSetting(this, "Tint", () -> !this.rippleMode.isSelected()).enable();
    private final SliderSetting tintStrength = new SliderSetting(this, "Tint Strength", () -> !this.rippleMode.isSelected())
            .min(0.0f).max(100.0f).step(1.0f).currentValue(100.0f);

    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.hit_bubbles.color_mode");
    private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.hit_bubbles.color_mode.theme").select();
    private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.hit_bubbles.color_mode.custom");
    private final ColorSetting colorFirst = new ColorSetting(this, "modules.settings.hit_bubbles.color", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(255, 80, 120, 255))
            .alpha(true);
    private final ColorSetting colorSecond = new ColorSetting(this, "modules.settings.hit_bubbles.color_second", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(100, 160, 255, 255))
            .alpha(true);

    private final List<HitCircle> hitCircles = new ArrayList<>();
    private final ConcurrentHashMap<Integer, Long> lastHitTime = new ConcurrentHashMap<>();

    private final EventListener<AttackEvent> onAttack = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_1297 target = event.getEntity();
        if (target == mc.field_1724) return;
        if (!(target instanceof class_1309 entity)) return;
        if (!entity.method_5805()) return;
        if (this.hasVisionBlockingEffect() || this.isInvisible(entity)) return;

        int entityId = entity.method_5628();
        long now = System.currentTimeMillis();
        Long lastHit = lastHitTime.get(entityId);

        if (!this.rippleMode.isSelected() && lastHit != null && (now - lastHit) < COOLDOWN_MS) {
            return;
        }

        lastHitTime.put(entityId, now);

        class_243 hitPos = this.rippleMode.isSelected() ? entity.method_73189().method_1031(0, entity.method_17682() * 0.5F, 0) : computeHitPos(entity);
        if (hitPos == null) {
            hitPos = entity.method_73189().method_1031(0, entity.method_17682() / 2f, 0);
        }

        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        class_243 toCamera = cameraPos.method_1020(hitPos).method_1029();

        float yaw = (float) Math.toDegrees(Math.atan2(toCamera.field_1350, toCamera.field_1352));
        float pitch = (float) Math.toDegrees(Math.atan2(-toCamera.field_1351, Math.sqrt(toCamera.field_1352 * toCamera.field_1352 + toCamera.field_1350 * toCamera.field_1350)));

        hitCircles.add(new HitCircle(hitPos, (long) (lifeTime.getCurrentValue() * 1000), yaw, pitch));

        if (hitCircles.size() % 20 == 0) {
            lastHitTime.entrySet().removeIf(entry -> entry.getValue() == null || now - entry.getValue() > 10000L);
        }
    };

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        long now = System.currentTimeMillis();
        for (int i = hitCircles.size() - 1; i >= 0; i--) {
            HitCircle circle = hitCircles.get(i);
            if ((now - circle.spawnTime) > circle.ttl) {
                hitCircles.remove(i);
            }
        }

        if (this.rippleMode.isSelected()) {
            for (HitCircle circle : hitCircles) {
                long age = now - circle.spawnTime;
                float progress = class_3532.method_15363(age / (float)Math.max(1L, circle.ttl), 0.0F, 1.0F);
                float fadeIn = class_3532.method_15363(progress / 0.1F, 0.0F, 1.0F);
                float fadeOut = class_3532.method_15363((1.0F - progress) / 0.3F, 0.0F, 1.0F);
                float envelope = fadeIn * fadeOut;
                if (envelope <= 0.001F) continue;
                float radius = this.size.getCurrentValue() * (0.08F + 0.92F * (1.0F - (1.0F - progress) * (1.0F - progress)));
                this.renderRipple(event.getMatrices(), circle.origin, radius, this.getRippleColor(age * 0.35F, envelope), envelope, age);
            }
            return;
        }

        for (HitCircle c : hitCircles) {
            long age = now - c.spawnTime;

            float growVal;
            if (age >= GROW_MS) {
                growVal = 1.0f;
            } else {
                growVal = (float) age / GROW_MS;
                growVal = (float) (1 - Math.pow(1 - growVal, 2));
            }

            float rotation;
            if (age < GROW_MS) {
                rotation = MAX_ROTATION * growVal;
            } else {
                float fadeProgress = Math.min(1.0f, Math.max(0f, (age - GROW_MS) / (float) Math.max(1, c.ttl - GROW_MS)));
                rotation = MAX_ROTATION * (1 - fadeProgress);
            }

            float timeFade = 1.0f - Math.min(1.0f, Math.max(0f, (age - GROW_MS) / (float) Math.max(1, c.ttl - GROW_MS)));
            if (age < GROW_MS) {
                timeFade = Math.min(1.0f, age / (float) GROW_MS);
            }

            float alphaK = Math.max(0f, Math.min(1f, growVal * timeFade));
            int alpha = (int) (255 * alphaK);
            if (alpha <= 2) continue;

            float r = size.getCurrentValue() * (0.6f + 0.4f * growVal);
            ColorRGBA drawColor = this.getBubbleColor(age * 0.35f).withAlpha(alpha);

            renderBubble(event.getMatrices(), c.origin, r, drawColor, c.rotationYaw, c.rotationPitch, rotation);
        }
    };

    public HitBubbles() {
    }

    private class_243 computeHitPos(class_1309 entity) {
        class_239 crosshairTarget = mc.field_1765;
        if (crosshairTarget != null && crosshairTarget.method_17783() == class_239.class_240.field_1331) {
            class_3966 ehr = (class_3966) crosshairTarget;
            if (ehr.method_17782() == entity) {
                return ehr.method_17784();
            }
        }
        return computeHitOnEntityAABB(entity);
    }

    private boolean isInvisible(class_1309 entity) {
        if (entity.method_6059(class_1294.field_5905)) return true;
        if (entity.method_5767()) return true;
        if (mc.field_1724 != null && entity.method_5756(mc.field_1724)) return true;
        return false;
    }

    private boolean hasVisionBlockingEffect() {
        return mc.field_1724 != null
                && (mc.field_1724.method_6059(class_1294.field_5919)
                || mc.field_1724.method_6059(class_1294.field_38092));
    }

    private class_243 computeHitOnEntityAABB(class_1309 entity) {
        class_243 start = mc.field_1724.method_33571();
        class_243 dir = mc.field_1724.method_5828(1.0f);
        class_243 end = start.method_1019(dir.method_1021(6.0));
        class_238 bb = entity.method_5829();
        Optional<class_243> res = bb.method_992(start, end);
        return res.orElse(null);
    }

    private ColorRGBA getBubbleColor(float index) {
        if (this.colorCustom.isSelected()) {
            return this.colorFirst.getColor().mix(this.colorSecond.getColor(), this.getCustomMix(index));
        }

        return Colors.getAccentColor(index);
    }

    private float getCustomMix(float index) {
        float normalized = (index % 360.0f) / 180.0f;
        return normalized > 1.0f ? 2.0f - normalized : normalized;
    }

    private void renderBubble(class_4587 ms, class_243 origin, float size, ColorRGBA color, float rotationYaw, float rotationPitch, float additionalRotation) {
        class_4184 camera = mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BUBBLE_TEX);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO
        );
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(false);

        ms.method_22903();
        ms.method_22904(origin.field_1352 - cameraPos.field_1352, origin.field_1351 - cameraPos.field_1351, origin.field_1350 - cameraPos.field_1350);

        double yawRadians = Math.toRadians(rotationYaw);
        double pitchRadians = Math.toRadians(rotationPitch);
        double rotRadians = Math.toRadians(additionalRotation);

        double cosYaw = Math.cos(yawRadians);
        double sinYaw = Math.sin(yawRadians);
        double cosPitch = Math.cos(pitchRadians);
        double sinPitch = Math.sin(pitchRadians);
        double cosRot = Math.cos(rotRadians);
        double sinRot = Math.sin(rotRadians);

        class_243 forward = new class_243(
                cosYaw * cosPitch,
                -sinPitch,
                sinYaw * cosPitch
        ).method_1029();

        class_243 worldUp = new class_243(0, 1, 0);
        class_243 right = worldUp.method_1036(forward).method_1029();
        class_243 up = forward.method_1036(right).method_1029();

        class_243 rotatedRight = right.method_1021(cosRot).method_1019(up.method_1021(sinRot));
        class_243 rotatedUp = up.method_1021(cosRot).method_1020(right.method_1021(sinRot));

        class_243 scaledRight = rotatedRight.method_1021(size);
        class_243 scaledUp = rotatedUp.method_1021(size);

        class_243 topLeft = scaledUp.method_1020(scaledRight);
        class_243 topRight = scaledUp.method_1019(scaledRight);
        class_243 bottomLeft = scaledRight.method_1021(-1).method_1020(scaledUp);
        class_243 bottomRight = scaledRight.method_1020(scaledUp);

        Matrix4f matrix = ms.method_23760().method_23761();
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);

        float red = color.getRed() / 255.0f;
        float green = color.getGreen() / 255.0f;
        float blue = color.getBlue() / 255.0f;
        float alphaValue = color.getAlpha() / 255.0f;

        buffer.method_22918(matrix, (float) bottomLeft.field_1352, (float) bottomLeft.field_1351, (float) bottomLeft.field_1350)
                .method_22913(0.0f, 1.0f).method_22915(red, green, blue, alphaValue);
        buffer.method_22918(matrix, (float) bottomRight.field_1352, (float) bottomRight.field_1351, (float) bottomRight.field_1350)
                .method_22913(1.0f, 1.0f).method_22915(red, green, blue, alphaValue);
        buffer.method_22918(matrix, (float) topRight.field_1352, (float) topRight.field_1351, (float) topRight.field_1350)
                .method_22913(1.0f, 0.0f).method_22915(red, green, blue, alphaValue);
        buffer.method_22918(matrix, (float) topLeft.field_1352, (float) topLeft.field_1351, (float) topLeft.field_1350)
                .method_22913(0.0f, 0.0f).method_22915(red, green, blue, alphaValue);

        BufferRenderer.drawWithGlobalProgram(buffer.method_60800());

        ms.method_22909();

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private ColorRGBA getRippleColor(float index, float alphaK) {
        ColorRGBA base = this.getBubbleColor(index);
        if (this.tint.isEnabled()) {
            float tintK = class_3532.method_15363(this.tintStrength.getCurrentValue() / 100.0F, 0.0F, 1.0F);
            base = base.mix(Colors.getAccentColor(index + 60.0F), tintK * 0.35F);
        } else {
            float gray = (base.getRed() + base.getGreen() + base.getBlue()) / 3.0F;
            float sat = this.saturation.getCurrentValue();
            base = new ColorRGBA(
                    gray + (base.getRed() - gray) * sat,
                    gray + (base.getGreen() - gray) * sat,
                    gray + (base.getBlue() - gray) * sat,
                    base.getAlpha()
            );
        }
        return base.withAlpha(230.0F * alphaK);
    }

    private void renderRipple(class_4587 ms, class_243 origin, float radius, ColorRGBA color, float alphaK, long age) {
        class_4184 camera = mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();
        Matrix4f matrix = ms.method_23760().method_23761();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);

        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1576);
        class_243 center = origin.method_1020(cameraPos);
        int segments = 96;
        float warpAmount = this.warp.isEnabled() ? 0.035F * this.warpStrength.getCurrentValue() : 0.0F;
        float halfWidth = class_3532.method_15363(0.008F * this.strength.getCurrentValue(), 0.006F, 0.035F);
        for (int ring = 0; ring < 3; ring++) {
            float ringRadius = radius * (0.55F + ring * 0.28F + (age % 650L) / 650.0F * 0.16F);
            float ringAlpha = alphaK * (0.8F - ring * 0.18F);
            ColorRGBA ringColor = color.withAlpha(210.0F * ringAlpha);
            for (int i = 0; i < segments; i++) {
                double a1 = Math.PI * 2.0D * i / segments;
                double a2 = Math.PI * 2.0D * (i + 1) / segments;
                float y1 = (float)Math.sin(a1 * 3.0D + age * 0.012D + ring) * warpAmount;
                float y2 = (float)Math.sin(a2 * 3.0D + age * 0.012D + ring) * warpAmount;
                float inner = Math.max(0.0F, ringRadius - halfWidth);
                float outer = ringRadius + halfWidth;
                buffer.method_22918(matrix, (float)(center.field_1352 + Math.cos(a1) * inner), (float)center.field_1351 + y1, (float)(center.field_1350 + Math.sin(a1) * inner)).method_39415(ringColor.getRGB());
                buffer.method_22918(matrix, (float)(center.field_1352 + Math.cos(a1) * outer), (float)center.field_1351 + y1, (float)(center.field_1350 + Math.sin(a1) * outer)).method_39415(ringColor.getRGB());
                buffer.method_22918(matrix, (float)(center.field_1352 + Math.cos(a2) * outer), (float)center.field_1351 + y2, (float)(center.field_1350 + Math.sin(a2) * outer)).method_39415(ringColor.getRGB());
                buffer.method_22918(matrix, (float)(center.field_1352 + Math.cos(a2) * inner), (float)center.field_1351 + y2, (float)(center.field_1350 + Math.sin(a2) * inner)).method_39415(ringColor.getRGB());
            }
        }

        class_9801 built = buffer.method_60794();
        if (built != null) {
            BufferRenderer.drawWithGlobalProgram(built);
        }

        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        hitCircles.clear();
        lastHitTime.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        hitCircles.clear();
        lastHitTime.clear();
    }

    private static class HitCircle {
        final class_243 origin;
        final long spawnTime;
        final long ttl;
        final float rotationYaw;
        final float rotationPitch;

        HitCircle(class_243 origin, long ttl, float rotationYaw, float rotationPitch) {
            this.origin = origin;
            this.spawnTime = System.currentTimeMillis();
            this.ttl = ttl;
            this.rotationYaw = rotationYaw;
            this.rotationPitch = rotationPitch;
        }
    }
}
