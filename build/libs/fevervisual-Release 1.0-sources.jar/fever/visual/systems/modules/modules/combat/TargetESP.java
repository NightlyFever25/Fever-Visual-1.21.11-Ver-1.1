package fever.visual.systems.modules.modules.combat;

import fever.visual.utility.render.compat.GlStateManager.DstFactor;
import fever.visual.utility.render.compat.GlStateManager.SrcFactor;
import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.animation.base.Animation;
import fever.visual.utility.animation.base.Easing;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.EntityUtility;
import fever.visual.utility.math.MathUtility;
import fever.visual.utility.render.CrystalRenderer;
import fever.visual.utility.render.DrawUtility;
import fever.visual.utility.render.RenderUtility;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import fever.visual.utility.render.compat.BufferRenderer;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

@ModuleInfo(name = "Target ESP", category = ModuleCategory.COMBAT, desc = "Помечает активную цель")
public class TargetESP extends BaseModule {
   private static final class_2960 RHOMB_TEXTURE = FeverVisual.id("images/world/cube.png");
   private static final class_2960 GHOST_GLOW_TEXTURE = FeverVisual.id("images/particle/ghost-glow.png");
   private static final class_2960 BLOOM_TEXTURE = FeverVisual.id("textures/bloom.png");
   private static final class_2960 CHAIN_TEXTURE = FeverVisual.id("images/world/chain.png");
   private static final int CIRCLE_SEGMENTS = 64;
   private static final class_243[] CIRCLE_POINTS = createCirclePoints();

   private final ModeSetting mode = new ModeSetting(this, "modules.settings.target_esp.mode");
   private final ModeSetting.Value rhomb = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.rhomb").select();
   private final ModeSetting.Value ghost = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.ghost");
   private final ModeSetting.Value souls = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.souls");
   private final ModeSetting.Value circle = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.circle");
   private final ModeSetting.Value crystals = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.crystals");
   private final ModeSetting.Value chain = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.chain");
   private final ModeSetting ghostStyle = new ModeSetting(this, "modules.settings.target_esp.ghost_style", () -> !this.ghost.isSelected());
   private final ModeSetting.Value ghostTrails = new ModeSetting.Value(this.ghostStyle, "modules.settings.target_esp.ghost_style.trails").select();
   private final ModeSetting.Value ghostSouls = new ModeSetting.Value(this.ghostStyle, "modules.settings.target_esp.ghost_style.souls");
   private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.target_esp.color_mode");
   private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.target_esp.color_mode.theme").select();
   private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.target_esp.color_mode.custom");
   private final ColorSetting colorTarget = new ColorSetting(this, "modules.settings.target_esp.custom_color", () -> !colorCustom.isSelected())
           .color(new ColorRGBA(160, 115, 255, 255));
   private final ColorSetting colorTargetSecond = new ColorSetting(this, "modules.settings.target_esp.custom_color_second", () -> !colorCustom.isSelected())
           .color(new ColorRGBA(100, 160, 255, 255));
   private final SliderSetting opacity = new SliderSetting(this, "modules.settings.target_esp.opacity").step(0.01F).min(0.7F).max(1.0F).currentValue(0.05F);
   private final Animation animation = new Animation(300L, 0.0F, Easing.BOTH_CUBIC);
   private final Animation moving = new Animation(70L, 0.0F, Easing.LINEAR);
   private class_1309 prevTarget;
   private class_1309 lastTarget;
   private class_243 smoothedPos;
   private float hurtProgress;
   private float soulsRotation;
   private long ghostLastUpdateTime = System.currentTimeMillis();
   private long lastFrameTime = System.currentTimeMillis();
   private float circleStep;
   private float circleSpeed = 1.0F;
   private boolean circleFlipSpeed;
   private double smoothCircleY;
   private double smoothCircleY2;
   private final List<GhostTrail> ghostTrailPoints = new ArrayList<>();
   private final Map<class_1297, Long> targetTimers = new HashMap<>();
   private static final long LOOK_TIMEOUT = 3000;
   private static final double MAX_DISTANCE = 8.0;
   private boolean wasInChat = false;
   private class_1297 currentTarget = null;

   private final EventListener<Render3DEvent> onRender3D = new EventListener<>() {
      @Override
      public void onEvent(Render3DEvent event) {
         renderTargetEsp(event);
      }

      @Override
      public int getPriority() {
         return -100;
      }
   };

   private void renderTargetEsp(Render3DEvent event) {
      if (EntityUtility.isInGame()) {
         float deltaTime = this.getDeltaTime();
         currentTarget = getCurrentTarget();
         class_1309 target = null;
         if (currentTarget instanceof class_1309 livingTarget) {
            target = livingTarget;
         }

         this.animation.setEasing(Easing.FIGMA_EASE_IN_OUT);
         this.animation.update(target != null);
         this.moving.update(this.moving.getValue() + 10.0F + 50.0F);
         this.updateCircleAnimation(deltaTime);
         if (target != null) {
            this.prevTarget = target;
            this.updateTargetAnimation(target);
         } else {
            if (this.prevTarget != null && !this.isTargetRenderable(this.prevTarget)) {
               this.prevTarget = null;
               this.animation.update(false);
            }
            this.smoothedPos = null;
            this.lastTarget = null;
            this.ghostTrailPoints.clear();
            this.ghostLastUpdateTime = System.currentTimeMillis();
            this.smoothCircleY = 0.0;
            this.smoothCircleY2 = 0.0;
         }

         if (this.prevTarget != null && this.animation.getValue() != 0.0F && this.isTargetRenderable(this.prevTarget)) {
            class_4587 ms = event.getMatrices();
            ms.method_22903();
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
            RenderSystem.disableCull();
            RenderSystem.depthMask(false);
            if (this.crystals.isSelected()) {
               RenderSystem.enableDepthTest();
               this.drawCrystals(ms, this.prevTarget);
            } else if (this.chain.isSelected()) {
               RenderSystem.enableDepthTest();
               this.drawChain(ms, this.prevTarget);
            } else if (this.rhomb.isSelected()) {
               RenderSystem.disableDepthTest();
               this.drawRhomb(ms, this.prevTarget);
            } else if (this.ghost.isSelected()) {
               RenderSystem.disableDepthTest();
               this.drawFeverGhost(ms, this.prevTarget);
            } else if (this.circle.isSelected()) {
               RenderSystem.enableDepthTest();
               this.drawCircle(ms, this.prevTarget);
            } else {
               RenderSystem.disableDepthTest();
               this.drawGhosts(ms, this.prevTarget);
            }

            RenderSystem.depthMask(true);
            RenderSystem.setShaderTexture(0, 0);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            ms.method_22909();
         }
      }
   }

   @Override
   public void tick() {
      super.tick();
      updateTarget();
   }

   @Override
   public void onDisable() {
      super.onDisable();
      targetTimers.clear();
      wasInChat = false;
      currentTarget = null;
      ghostTrailPoints.clear();
      smoothedPos = null;
      lastTarget = null;
      smoothCircleY = 0.0;
      smoothCircleY2 = 0.0;
   }

   private float getDeltaTime() {
      long currentTime = System.currentTimeMillis();
      float deltaMs = class_3532.method_15363((float)(currentTime - this.lastFrameTime), 1.0F, 100.0F);
      this.lastFrameTime = currentTime;
      return deltaMs / (1000.0F / 60.0F);
   }

   private void updateCircleAnimation(float deltaTime) {
      this.circleSpeed = this.circleFlipSpeed ? this.circleSpeed - 0.5F * deltaTime : this.circleSpeed + 0.5F * deltaTime;
      if (this.circleSpeed > 25.0F) {
         this.circleFlipSpeed = true;
      }
      if (this.circleSpeed < -25.0F) {
         this.circleFlipSpeed = false;
      }
      this.circleStep += 0.06F * deltaTime;
   }

   private void updateTargetAnimation(class_1309 target) {
      float tickDelta = class_310.method_1551().method_61966().method_60637(false);
      class_243 targetPos = this.getRenderPos(target);
      if (this.lastTarget != target || this.smoothedPos == null) {
         this.smoothedPos = targetPos;
         this.lastTarget = target;
         this.ghostTrailPoints.clear();
         this.ghostLastUpdateTime = System.currentTimeMillis();
      } else {
         float smoothing = Math.min(1.0F, tickDelta * 1.5F);
         this.smoothedPos = new class_243(
                 class_3532.method_16436(smoothing, this.smoothedPos.field_1352, targetPos.field_1352),
                 class_3532.method_16436(smoothing, this.smoothedPos.field_1351, targetPos.field_1351),
                 class_3532.method_16436(smoothing, this.smoothedPos.field_1350, targetPos.field_1350)
         );
      }

      this.hurtProgress = target.field_6235 > 0 ? target.field_6235 / 10.0F : Math.max(0.0F, this.hurtProgress - 0.1F);
   }

   private void updateTarget() {
      if (mc.field_1724 == null || mc.field_1687 == null) return;

      long currentTime = System.currentTimeMillis();
      boolean isInChat = mc.field_1755 instanceof net.minecraft.class_408;

      Iterator<Map.Entry<class_1297, Long>> iterator = targetTimers.entrySet().iterator();
      while (iterator.hasNext()) {
         Map.Entry<class_1297, Long> entry = iterator.next();
         class_1297 entity = entry.getKey();
         if (entity instanceof class_1309) {
            class_1309 livingEntity = (class_1309) entity;
            if (currentTime - entry.getValue() > LOOK_TIMEOUT ||
                    isEntityDead(livingEntity) ||
                    isEntityInvisible(livingEntity) ||
                    !this.isWithinTargetDistance(livingEntity)) {
               iterator.remove();
            }
         } else {
            iterator.remove();
         }
      }

      if (wasInChat && !isInChat) {
         targetTimers.remove(mc.field_1724);
      }

      wasInChat = isInChat;

      if (isInChat) {
         targetTimers.clear();
         return;
      }

      class_1297 lookedAtEntity = getEntityFromCrosshair();
      if (lookedAtEntity != null && lookedAtEntity instanceof class_1309) {
         class_1309 livingEntity = (class_1309) lookedAtEntity;
         if (isEntityDead(livingEntity) || isEntityInvisible(livingEntity)) {
            targetTimers.remove(livingEntity);
            return;
         }
         if (this.isWithinTargetDistance(livingEntity)) {
            targetTimers.put(livingEntity, currentTime);
         } else {
            targetTimers.remove(livingEntity);
         }
      }
   }

   private class_1297 getCurrentTarget() {
      if (mc.field_1724 == null || mc.field_1687 == null) return null;

      class_1297 currentTarget = null;
      long latestTime = 0;

      for (Map.Entry<class_1297, Long> entry : targetTimers.entrySet()) {
         class_1297 entity = entry.getKey();
         if (entity instanceof class_1309) {
            class_1309 livingEntity = (class_1309) entity;
            if (isEntityDead(livingEntity) || isEntityInvisible(livingEntity)) {
               continue;
            }
            if (!this.isWithinTargetDistance(livingEntity)) {
               continue;
            }

            if (entry.getValue() > latestTime) {
               latestTime = entry.getValue();
               currentTarget = entity;
            }
         }
      }

      if (currentTarget != null) {
         long currentTime = System.currentTimeMillis();
         if (currentTime - latestTime > LOOK_TIMEOUT) {
            targetTimers.remove(currentTarget);
            return null;
         }
      }

      return currentTarget;
   }

   private class_1297 getEntityFromCrosshair() {
      if (mc.field_1724 == null || mc.field_1687 == null) return null;

      class_239 hitResult = mc.field_1765;
      if (hitResult instanceof class_3966 entityHitResult) {
         class_1297 entity = entityHitResult.method_17782();
         if (entity instanceof class_1309 && !entity.equals(mc.field_1724) &&
                 (entity instanceof class_1657 || entity instanceof class_1308 || entity instanceof class_1296)) {
            if (isEntityDead(entity) || isEntityInvisible(entity)) {
               return null;
            }
            if (this.isWithinTargetDistance(entity)) {
               return entity;
            }
         }
      }
      return null;
   }

   private boolean isEntityDead(class_1297 entity) {
      if (!(entity instanceof class_1309)) {
         return false;
      }

      class_1309 livingEntity = (class_1309) entity;
      return livingEntity.method_29504() || livingEntity.method_6032() <= 0;
   }

   private boolean isEntityInvisible(class_1297 entity) {
      if (!(entity instanceof class_1309)) {
         return false;
      }

      class_1309 livingEntity = (class_1309) entity;
      if (livingEntity.method_6059(class_1294.field_5905)) {
         return true;
      }
      if (livingEntity.method_5767()) {
         return true;
      }
      if (livingEntity.method_5756(mc.field_1724)) {
         return true;
      }

      return false;
   }

   private boolean isTargetRenderable(class_1309 entity) {
      return !this.isEntityDead(entity) && !this.isEntityInvisible(entity) && this.isWithinTargetDistance(entity);
   }

   private boolean isWithinTargetDistance(class_1297 entity) {
      return mc.field_1724 != null && mc.field_1724.method_73189().method_1025(entity.method_73189()) <= MAX_DISTANCE * MAX_DISTANCE;
   }

   private ColorRGBA getTargetColor(class_1297 entity, int index) {
      if (colorCustom.isSelected()) {
         return this.applyHurtTint(this.colorTarget.getColor().mix(this.colorTargetSecond.getColor(), (index % 40) / 39.0F));
      }

      return this.applyHurtTint(Colors.getAccentColor(index * 6.0F));
   }

   private ColorRGBA applyHurtTint(ColorRGBA color) {
      return this.hurtProgress > 0.0F ? color.mix(ColorRGBA.RED, class_3532.method_15363(this.hurtProgress, 0.0F, 1.0F)) : color;
   }

   private void drawRhomb(class_4587 ms, class_1309 target) {
      ColorRGBA color = getTargetColor(target, 0).withAlpha(255.0F * this.animation.getValue() * this.opacity.getCurrentValue());
      ColorRGBA secondColor = getTargetColor(target, 20).withAlpha(255.0F * this.animation.getValue() * this.opacity.getCurrentValue());
      RenderSystem.setShaderTexture(0, RHOMB_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      RenderUtility.prepareMatrices(ms, this.smoothedPos != null ? this.smoothedPos : this.getRenderPos(target));
      ms.method_46416(0.0F, target.method_17682() / 2.0F, 0.0F);
      ms.method_22907(mc.field_1773.method_19418().method_23767());
      float rotation = (float)Math.sin((System.currentTimeMillis() % 6283L) / 1000.0F) * 360.0F;
      ms.method_22907(class_7833.field_40718.rotationDegrees(rotation));
      float size = 0.9F;
      Matrix4f matrix = ms.method_23760().method_23761();

      buffer.method_22918(matrix, -size / 2.0F, -size / 2.0F, 0.0F).method_22913(0.0F, 1.0F).method_39415(secondColor.getRGB());
      buffer.method_22918(matrix, size / 2.0F, -size / 2.0F, 0.0F).method_22913(1.0F, 1.0F).method_39415(color.getRGB());
      buffer.method_22918(matrix, size / 2.0F, size / 2.0F, 0.0F).method_22913(1.0F, 0.0F).method_39415(secondColor.getRGB());
      buffer.method_22918(matrix, -size / 2.0F, size / 2.0F, 0.0F).method_22913(0.0F, 0.0F).method_39415(color.getRGB());

      RenderUtility.buildBuffer(buffer);
   }

   private void drawFeverGhost(class_4587 ms, class_1309 target) {
      RenderSystem.setShaderTexture(0, GHOST_GLOW_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);

      RenderUtility.prepareMatrices(ms, this.smoothedPos != null ? this.smoothedPos : this.getRenderPos(target));
      ms.method_46416(0.0F, target.method_17682() * 0.5F, 0.0F);
      if (this.ghostSouls.isSelected()) {
         this.drawSoulGhosts(ms, target, buffer);
      } else {
         this.drawTrailGhosts(ms, target, buffer);
      }

      RenderUtility.buildBuffer(buffer);
   }

   private void drawTrailGhosts(class_4587 ms, class_1309 target, class_287 buffer) {
      if (this.smoothedPos == null) {
         return;
      }

      long elapsed = System.currentTimeMillis();
      class_243 center = this.smoothedPos.method_1031(0.0, target.method_17682() * 0.5F, 0.0);
      double radius = 0.33;
      double angle = (0.25F * (elapsed % 67000L)) / 45.0;
      double sin = Math.sin(angle) * radius;
      double cos = Math.cos(angle) * radius;

      class_243 orb1 = center.method_1031(sin, cos, -cos);
      class_243 orb2 = center.method_1031(-sin, sin, -cos);
      class_243 orb3 = center.method_1031(-sin, -sin, cos);
      if (this.ghostTrailPoints.isEmpty() || this.ghostTrailPoints.getLast().distanceTo(orb1) > 0.02) {
         this.ghostTrailPoints.add(new GhostTrail(orb1, 0));
         this.ghostTrailPoints.add(new GhostTrail(orb2, 1));
         this.ghostTrailPoints.add(new GhostTrail(orb3, 2));
      }

      while (this.ghostTrailPoints.size() > 160) {
         this.ghostTrailPoints.removeFirst();
      }

      int trailSize = this.ghostTrailPoints.size();
      if (trailSize <= 1) {
         return;
      }

      for (int i = 0; i < trailSize; i++) {
         GhostTrail trail = this.ghostTrailPoints.get(i);
         float progress = (float)i / (float)(trailSize - 1);
         if (progress <= 0.0F) {
            continue;
         }

         class_243 local = trail.position.method_1020(center);
         float size = 0.72F * progress;
         ColorRGBA color = this.getGhostColor(trail.colorIndex, progress).withAlpha(progress * 235.0F * this.animation.getValue() * this.opacity.getCurrentValue());
         this.drawGhostBillboard(ms, buffer, local, size, elapsed * 0.08F + i * 7.0F, color);
      }
   }

   private void drawSoulGhosts(class_4587 ms, class_1309 target, class_287 buffer) {
      long now = System.currentTimeMillis();
      this.soulsRotation += (1.65F * (now - this.ghostLastUpdateTime)) / 600.0F;
      this.ghostLastUpdateTime = now;

      int particles = 12;
      for (int layer = 0; layer < 9; layer += 3) {
         float layerProgress = layer / 6.0F;
         float layerY = -0.45F + layerProgress * 0.82F;
         for (int point = 0; point < particles; point++) {
            float gradient = (float)point / (float)(particles - 1);
            float phase = this.soulsRotation + point * 0.1F;
            float radius = 0.72F;
            int layerOffset = layer * layer;
            class_243 local = new class_243(
                    radius * class_3532.method_15374(phase + layerOffset),
                    layerY + 0.16F * class_3532.method_15374(this.soulsRotation * 0.75F + point * 0.17F),
                    radius * class_3532.method_15362(phase - layerOffset)
            );

            ColorRGBA color = this.getTargetColor(target, (int)(gradient * 40.0F));
            float animAlpha = this.animation.getValue() * this.opacity.getCurrentValue();
            this.drawGhostBillboard(ms, buffer, local, (0.12F + point / 155.0F) * 8.9F * animAlpha, now * 0.018F + point * 8.0F, color.withAlpha(70.0F * animAlpha));
            this.drawGhostBillboard(ms, buffer, local, (0.08F + point / 170.0F) * 6.7F * animAlpha, now * 0.026F + point * 12.0F, color.withAlpha(235.0F * animAlpha));
         }
      }
   }

   private ColorRGBA getGhostColor(int colorIndex, float progress) {
      ColorRGBA first = this.getTargetColor(this.prevTarget, colorIndex * 12);
      ColorRGBA second = this.getTargetColor(this.prevTarget, colorIndex * 12 + 20);
      return first.mix(second, progress);
   }

   private void drawGhostBillboard(class_4587 ms, class_287 buffer, class_243 local, float size, float rotation, ColorRGBA color) {
      ms.method_22903();
      ms.method_22904(local.field_1352, local.field_1351, local.field_1350);
      ms.method_22907(mc.field_1773.method_19418().method_23767());
      ms.method_22907(class_7833.field_40718.rotationDegrees(rotation));
      float half = size * 0.5F;
      Matrix4f matrix = ms.method_23760().method_23761();

      buffer.method_22918(matrix, -half, -half, 0.0F).method_22913(0.0F, 1.0F).method_39415(color.getRGB());
      buffer.method_22918(matrix, half, -half, 0.0F).method_22913(1.0F, 1.0F).method_39415(color.getRGB());
      buffer.method_22918(matrix, half, half, 0.0F).method_22913(1.0F, 0.0F).method_39415(color.getRGB());
      buffer.method_22918(matrix, -half, half, 0.0F).method_22913(0.0F, 0.0F).method_39415(color.getRGB());

      ms.method_22909();
   }

   private void drawCircle(class_4587 ms, class_1309 target) {
      class_243 renderPos = this.smoothedPos != null ? this.smoothedPos : this.getRenderPos(target);
      float alpha = this.animation.getValue() * this.opacity.getCurrentValue();
      float hitEffect = Math.min(this.hurtProgress * 2.0F, 1.0F);
      float width = target.method_17681() * (1.0F + class_3532.method_15374(hitEffect * (float)Math.PI) * 0.18F);
      float height = target.method_17682();
      int size = CIRCLE_SEGMENTS;

      double y = this.smoothSinAnimation(this.circleStep) * height;
      double y2 = this.smoothSinAnimation(this.circleStep - 0.35F) * height;
      this.smoothCircleY = this.lerp(this.smoothCircleY, y, 0.12);
      this.smoothCircleY2 = this.lerp(this.smoothCircleY2, y2, 0.10);

      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      class_287 quads = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);
      Matrix4f matrix = ms.method_23760().method_23761();
      class_243 cameraPos = mc.field_1773.method_19418().method_71156();
      ColorRGBA firstColor = this.getTargetColor(target, 0);
      ColorRGBA secondColor = this.getTargetColor(target, 20);

      for (int i = 0; i < size; i++) {
         float t = (float)i / (float)size;
         float tNext = (float)((i + 1) % size) / (float)size;
         float gradient = 0.5F - 0.5F * class_3532.method_15362(t * (float)Math.PI * 2.0F);
         float nextGradient = 0.5F - 0.5F * class_3532.method_15362(tNext * (float)Math.PI * 2.0F);

         ColorRGBA current = firstColor.mix(secondColor, gradient);
         ColorRGBA next = firstColor.mix(secondColor, nextGradient);
         class_243 cs = this.circlePoint(i, width);
         class_243 ncs = this.circlePoint((i + 1) % size, width);
         class_243 circlePoint = renderPos.method_1031(cs.field_1352, this.smoothCircleY, cs.field_1350);
         class_243 trailPoint = renderPos.method_1031(cs.field_1352, this.smoothCircleY2, cs.field_1350);
         class_243 nextCirclePoint = renderPos.method_1031(ncs.field_1352, this.smoothCircleY, ncs.field_1350);
         class_243 nextTrailPoint = renderPos.method_1031(ncs.field_1352, this.smoothCircleY2, ncs.field_1350);

         this.drawCircleQuad(quads, matrix, cameraPos, circlePoint, nextCirclePoint, nextTrailPoint, trailPoint,
                 current.withAlpha(204.0F * alpha), next.withAlpha(204.0F * alpha), next.withAlpha(0.0F), current.withAlpha(0.0F));
         this.drawCircleQuad(quads, matrix, cameraPos, trailPoint, nextTrailPoint, nextCirclePoint, circlePoint,
                 current.withAlpha(0.0F), next.withAlpha(0.0F), next.withAlpha(204.0F * alpha), current.withAlpha(204.0F * alpha));
      }
      RenderUtility.buildBuffer(quads);

      class_287 lines = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);
      for (int i = 0; i < size; i++) {
         float t = (float)i / (float)size;
         float tNext = (float)((i + 1) % size) / (float)size;
         ColorRGBA current = firstColor.mix(secondColor, 0.5F - 0.5F * class_3532.method_15362(t * (float)Math.PI * 2.0F));
         ColorRGBA next = firstColor.mix(secondColor, 0.5F - 0.5F * class_3532.method_15362(tNext * (float)Math.PI * 2.0F));
         class_243 cs = this.circlePoint(i, width);
         class_243 ncs = this.circlePoint((i + 1) % size, width);
         class_243 circlePoint = renderPos.method_1031(cs.field_1352, this.smoothCircleY, cs.field_1350);
         class_243 trailPoint = renderPos.method_1031(cs.field_1352, this.smoothCircleY2, cs.field_1350);
         class_243 nextCirclePoint = renderPos.method_1031(ncs.field_1352, this.smoothCircleY, ncs.field_1350);

         this.drawCircleLine(lines, matrix, cameraPos, circlePoint, trailPoint, current.withAlpha(38.0F * alpha), current.withAlpha(0.0F));
         this.drawCircleLine(lines, matrix, cameraPos, circlePoint, nextCirclePoint, current.withAlpha(255.0F * alpha), next.withAlpha(255.0F * alpha));
      }
      RenderUtility.buildBuffer(lines);
   }

   private class_243 circlePoint(int index, float radius) {
      class_243 point = CIRCLE_POINTS[index];
      return new class_243(point.field_1352 * radius, 0.0, point.field_1350 * radius);
   }

   private static class_243[] createCirclePoints() {
      class_243[] points = new class_243[CIRCLE_SEGMENTS];
      for (int i = 0; i < CIRCLE_SEGMENTS; i++) {
         double angle = (double)i / (double)CIRCLE_SEGMENTS * Math.PI * 2.0;
         points[i] = new class_243(Math.cos(angle), 0.0, Math.sin(angle));
      }
      return points;
   }

   private double smoothSinAnimation(double input) {
      double sin = (Math.sin(input) + 1.0) / 2.0;
      return -(Math.cos(Math.PI * sin) - 1.0) / 2.0;
   }

   private double lerp(double from, double to, double delta) {
      return from + (to - from) * delta;
   }

   private void drawCircleQuad(class_287 buffer, Matrix4f matrix, class_243 cam, class_243 p1, class_243 p2, class_243 p3, class_243 p4,
                               ColorRGBA c1, ColorRGBA c2, ColorRGBA c3, ColorRGBA c4) {
      buffer.method_22918(matrix, (float)(p1.field_1352 - cam.field_1352), (float)(p1.field_1351 - cam.field_1351), (float)(p1.field_1350 - cam.field_1350)).method_39415(c1.getRGB());
      buffer.method_22918(matrix, (float)(p2.field_1352 - cam.field_1352), (float)(p2.field_1351 - cam.field_1351), (float)(p2.field_1350 - cam.field_1350)).method_39415(c2.getRGB());
      buffer.method_22918(matrix, (float)(p3.field_1352 - cam.field_1352), (float)(p3.field_1351 - cam.field_1351), (float)(p3.field_1350 - cam.field_1350)).method_39415(c3.getRGB());
      buffer.method_22918(matrix, (float)(p4.field_1352 - cam.field_1352), (float)(p4.field_1351 - cam.field_1351), (float)(p4.field_1350 - cam.field_1350)).method_39415(c4.getRGB());
   }

   private void drawCircleLine(class_287 buffer, Matrix4f matrix, class_243 cam, class_243 p1, class_243 p2, ColorRGBA c1, ColorRGBA c2) {
      buffer.method_22918(matrix, (float)(p1.field_1352 - cam.field_1352), (float)(p1.field_1351 - cam.field_1351), (float)(p1.field_1350 - cam.field_1350)).method_39415(c1.getRGB());
      buffer.method_22918(matrix, (float)(p2.field_1352 - cam.field_1352), (float)(p2.field_1351 - cam.field_1351), (float)(p2.field_1350 - cam.field_1350)).method_39415(c2.getRGB());
   }

   private void drawCrystals(class_4587 ms, class_1309 target) {
      class_4184 camera = mc.field_1773.method_19418();
      class_243 cameraPos = camera.method_71156();
      float width = this.prevTarget.method_17681() * 1.5F;
      RenderUtility.prepareMatrices(ms, this.getRenderPos(this.prevTarget));
      class_287 builder = CrystalRenderer.createBuffer();

      for (int i = 0; i < 360; i += 20) {
         float val = 1.2F - 0.5F * this.animation.getValue();
         float sin = (float)(MathUtility.sin((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
         float cos = (float)(MathUtility.cos((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
         float size = 0.1F;
         ms.method_22903();
         ms.method_22904(sin, 0.1F + target.method_17682() * Math.abs(MathUtility.sin(i)), cos);
         class_243 crystalPos = this.getRenderPos(this.prevTarget).method_1031(sin, 1.0, cos);
         class_243 targetPos = target.method_73189().method_1031(0.0, target.method_17682() / 2.0, 0.0);
         Vector3f directionToTarget = new Vector3f(
                 (float)(targetPos.field_1352 - crystalPos.field_1352), (float)(targetPos.field_1351 - crystalPos.field_1351), (float)(targetPos.field_1350 - crystalPos.field_1350)
         )
                 .normalize();
         Vector3f initialDirection = new Vector3f(0.0F, 1.0F, 0.0F);
         Quaternionf rotation = new Quaternionf().rotationTo(initialDirection, directionToTarget);
         ms.method_22907(rotation);
         ColorRGBA color = getTargetColor(target, i);
         CrystalRenderer.render(ms, builder, 0.0F, 0.0F, 0.0F, size, color.withAlpha(255.0F * this.animation.getValue() * this.opacity.getCurrentValue()));
         ms.method_22909();
      }

      BufferRenderer.drawWithGlobalProgram(builder.method_60800());
      RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
      float bigSize = 1.0F;

      for (int i = 0; i < 360; i += 20) {
         float val = 1.2F - 0.5F * this.animation.getValue();
         float sin = (float)(MathUtility.sin((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
         float cos = (float)(MathUtility.cos((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
         float size = 0.1F;
         ColorRGBA color = getTargetColor(target, i);
         ms.method_22903();
         ms.method_22904(sin, 0.1F + target.method_17682() * Math.abs(MathUtility.sin(i)), cos);
         ms.method_22907(camera.method_23767());
         DrawUtility.drawImage(
                 ms,
                 buffer,
                 (double)(-bigSize / 2.0F),
                 (double)(-bigSize / 2.0F),
                 0.0,
                 (double)bigSize,
                 (double)bigSize,
                 color.withAlpha(255.0F * this.animation.getValue() * 0.2F * this.opacity.getCurrentValue())
         );
         ms.method_22909();
      }

      RenderUtility.buildBuffer(buffer);
   }

   private void drawGhosts(class_4587 ms, class_1309 target) {
      class_4184 camera = mc.field_1773.method_19418();
      class_2960 id = BLOOM_TEXTURE;
      float width = this.prevTarget.method_17681() * 1.5F;
      RenderSystem.setShaderTexture(0, id);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
      RenderUtility.prepareMatrices(ms, this.getRenderPos(this.prevTarget));
      int step = 2;
      int wormTick = 0;
      int wormCD = 0;
      int wormCount = 0;

      for (int i = 0; i < 360; i += step) {
         float size = 0.13F + 0.005F * wormTick;
         float bigSize = 0.7F + 0.005F * wormTick;
         if (wormCD > 0) {
            wormCD -= step;
         } else {
            wormTick += step;
            if (wormTick > 50) {
               wormCD = 100;
               wormTick = 0;
               wormCount++;
            } else {
               float val = Math.max(0.5F, 1.2F - 0.5F * this.animation.getValue());
               float sin = (float)(MathUtility.sin((float)Math.toRadians(i + this.moving.getValue() * 1.0F)) * width * val);
               float cos = (float)(MathUtility.cos((float)Math.toRadians(i + this.moving.getValue() * 1.0F)) * width * val);
               ms.method_22903();
               ms.method_22904(
                       sin,
                       this.prevTarget.method_17682() / 1.5F
                               + this.prevTarget.method_17682() / 3.0F * MathUtility.sin(Math.toRadians(i / 2.0F + this.moving.getValue() / 5.0F)),
                       cos
               );
               ms.method_22907(camera.method_23767());
               ColorRGBA color = getTargetColor(target, i);
               DrawUtility.drawImage(
                       ms,
                       builder,
                       (double)(-bigSize / 2.0F),
                       (double)(-bigSize / 2.0F),
                       (double)(-size / 2.0F),
                       (double)bigSize,
                       (double)bigSize,
                       color.withAlpha(color.getAlpha() * this.animation.getValue() * 0.05F * this.opacity.getCurrentValue())
               );
               DrawUtility.drawImage(
                       ms,
                       builder,
                       (double)(-size / 2.0F),
                       (double)(-size / 2.0F),
                       (double)(-size / 2.0F),
                       (double)size,
                       (double)size,
                       color.withAlpha(color.getAlpha() * this.animation.getValue() * this.opacity.getCurrentValue())
               );
               ms.method_22909();
            }
         }
      }

      BufferRenderer.drawWithGlobalProgram(builder.method_60800());
   }

   private void drawChain(class_4587 ms, class_1309 target) {
      ColorRGBA color = getTargetColor(target, 0);
      ColorRGBA secondColor = getTargetColor(target, 20);
      RenderSystem.setShaderTexture(0, CHAIN_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
      RenderUtility.prepareMatrices(ms, this.getRenderPos(target));

      float animValue = (System.currentTimeMillis() % 360000L) / 1000.0F * 60.0F;
      float gradusX = 20.0F * Math.min(1.0F + class_3532.method_15374((float)Math.toRadians(animValue)), 1.0F);
      float gradusZ = 20.0F * (Math.min(1.0F + class_3532.method_15374((float)Math.toRadians(animValue)), 2.0F) - 1.0F);
      float width = target.method_17681() * 3.0F;
      int linksStep = 18;
      int totalAngle = 720;
      float chainSize = 8.0F;
      float down = 1.5F;
      float chainScale = 0.5F;
      float alpha = this.animation.getValue() * this.opacity.getCurrentValue();
      ColorRGBA top = color.withAlpha(128.0F * alpha);
      ColorRGBA bottom = secondColor.withAlpha(128.0F * alpha);
      float rotationValue = (System.currentTimeMillis() % 720000L) / 1000.0F * 30.0F;

      for (int chainIndex = 0; chainIndex < 2; chainIndex++) {
         float val = 1.2F - 0.5F * (chainIndex == 0 ? 1.0F : 0.9F);
         ms.method_22903();
         ms.method_46416(0.0F, target.method_17682() / 2.0F, 0.0F);
         ms.method_22905(chainScale, chainScale, chainScale);
         ms.method_22907(class_7833.field_40718.rotationDegrees(chainIndex == 0 ? gradusX : -gradusX));
         ms.method_22907(class_7833.field_40714.rotationDegrees(chainIndex == 0 ? gradusZ : -gradusZ));

         Matrix4f matrix = ms.method_23760().method_23761();
         int step = linksStep / 2;
         for (int i = 0; i < totalAngle; i += step) {
            float offsetX = (chainIndex == 0 ? gradusX : -gradusX) / 100.0F;
            float offsetZ = (chainIndex == 0 ? -gradusZ : gradusZ) / 100.0F;
            float prevSin = offsetX + class_3532.method_15374((float)Math.toRadians(i - step + rotationValue)) * width * val;
            float prevCos = offsetZ + class_3532.method_15362((float)Math.toRadians(i - step + rotationValue)) * width * val;
            float sin = offsetX + class_3532.method_15374((float)Math.toRadians(i + rotationValue)) * width * val;
            float cos = offsetZ + class_3532.method_15362((float)Math.toRadians(i + rotationValue)) * width * val;
            float u0 = (i - step) / 360.0F * chainSize;
            float u1 = i / 360.0F * chainSize;

            buffer.method_22918(matrix, prevSin, -0.5F, prevCos).method_22913(u0, 0.0F).method_39415(top.getRGB());
            buffer.method_22918(matrix, sin, -0.5F, cos).method_22913(u1, 0.0F).method_39415(top.getRGB());
            buffer.method_22918(matrix, sin, -0.5F + down, cos).method_22913(u1, 0.99F).method_39415(bottom.getRGB());
            buffer.method_22918(matrix, prevSin, -0.5F + down, prevCos).method_22913(u0, 0.99F).method_39415(bottom.getRGB());
         }
         ms.method_22909();
      }

      BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
   }

   private class_243 getRenderPos(class_1309 target) {
      float tickDelta = class_310.method_1551().method_61966().method_60637(false);
      return new class_243(
              class_3532.method_16436(tickDelta, target.field_6014, target.method_23317()),
              class_3532.method_16436(tickDelta, target.field_6036, target.method_23318()),
              class_3532.method_16436(tickDelta, target.field_5969, target.method_23321())
      );
   }

   public static class_1297 getTarget() {
      TargetESP instance = FeverVisual.getInstance().getModuleManager().getModule(TargetESP.class);
      if (instance == null) return null;

      class_1297 target = instance.currentTarget;

      if (target != null && (instance.isEntityDead(target) || instance.isEntityInvisible(target))) {
         return null;
      }
      if (target != null && instance.mc.field_1724 != null) {
         double distance = instance.mc.field_1724.method_73189().method_1022(target.method_73189());
         if (distance > MAX_DISTANCE) {
            return null;
         }
      }

      return target;
   }

   private static class GhostTrail {
      private final class_243 position;
      private final int colorIndex;

      private GhostTrail(class_243 position, int colorIndex) {
         this.position = position;
         this.colorIndex = colorIndex;
      }

      private double distanceTo(class_243 other) {
         return this.position.method_1022(other);
      }
   }
}
