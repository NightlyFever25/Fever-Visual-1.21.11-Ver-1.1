package fever.visual.systems.modules.modules.other;

import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.network.ReceivePacketEvent;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.notifications.NotificationType;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.utility.game.server.ServerUtility;
import fever.visual.utility.inventory.group.SlotGroup;
import fever.visual.utility.inventory.group.SlotGroups;
import fever.visual.utility.inventory.slots.HotbarSlot;
import fever.visual.utility.time.Timer;
import net.minecraft.class_1268;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2886;
import net.minecraft.class_7439;

@ModuleInfo(name = "Auto Join", category = ModuleCategory.MISC, desc = "modules.descriptions.auto_join")
public class AutoJoin extends BaseModule {
   private final String griefString = "306";
   private final ModeSetting mode = new ModeSetting(this, "modules.settings.auto_join.mode");
   private final ModeSetting.Value duels = new ModeSetting.Value(this.mode, "modules.settings.auto_join.mode.duels").select();
   private final ModeSetting.Value grief = new ModeSetting.Value(this.mode, "modules.settings.auto_join.mode.grief");
   private final Timer timer = new Timer();
   private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
      if (ServerUtility.isST() && this.duels.isSelected()) {
         SlotGroup<HotbarSlot> search = SlotGroups.hotbar();
         HotbarSlot compass = search.findItem(class_1802.field_8251);
         HotbarSlot sword = search.findItem(class_1802.field_8802);
         if (compass != null && this.timer.finished(300L)) {
            mc.field_1724.method_31548().method_61496(compass.getSlotId());
            mc.field_1761
                    .method_41931(mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
            if (mc.field_1724.field_7512 instanceof class_1707 && mc.field_1755.method_25440().getString().contains("Выберите режим")) {
               mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 14, 0, class_1713.field_7794, mc.field_1724);
            }

            this.timer.reset();
         }

         if (sword != null) {
            FeverVisual.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, "modules.auto_join.success_title", "modules.auto_join.success_message");
            this.toggle();
         }
      }

      if ((ServerUtility.isFT() || ServerUtility.isRW() || ServerUtility.isST()) && this.grief.isSelected()) {
         mc.field_1724.field_3944.method_45730("an306");
      }
   };
   private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
      if (event.getPacket() instanceof class_7439 packet
              && (ServerUtility.isFT() || ServerUtility.isRW() || ServerUtility.isST())
              && this.grief.isSelected()) {
         String message = packet.comp_763().getString().toLowerCase();
         if (ServerUtility.isFT() ? message.contains("вы уже подключены к этому серверву!") : message.contains("вы уже подключены на этот сервер!")) {
            this.toggle();
         }
      }
   };
}
