package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.BufferRenderer;

import fever.visual.utility.render.compat.GlStateManager.DstFactor;
import fever.visual.utility.render.compat.GlStateManager.SrcFactor;
import fever.visual.utility.render.compat.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.utility.animation.base.Animation;
import fever.visual.utility.animation.base.Easing;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.Draw3DUtility;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import java.util.ArrayList;
import java.util.List;

@ModuleInfo(
        name = "Hit Effect",
        category = ModuleCategory.VISUALS,
        desc = "modules.descriptions.hiteffect"
)
public class HitEffect extends BaseModule {
   private static final int MAX_ACTIVE_WAVES = 3;
   private final List<WaveEffect> waves = new ArrayList<>();
   private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.hiteffect.color_mode");
   private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.hiteffect.color_mode.theme").select();
   private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.hiteffect.color_mode.custom");
   private final ColorSetting color = new ColorSetting(this, "modules.settings.hiteffect.color", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(151, 71, 255, 255))
           .alpha(true);
   private final ColorSetting colorSecond = new ColorSetting(this, "modules.settings.hiteffect.color_second", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(100, 160, 255, 255))
           .alpha(true);

   private final EventListener<AttackEvent> onAttack = event -> {
      if (mc.field_1724 != null && event.getEntity() != null && !this.hasVisionBlockingEffect()) {
         if (event.getEntity() instanceof class_1309 living && this.isInvisible(living)) {
            return;
         }
         class_243 pos = event.getEntity().method_73189();
         if (this.waves.size() >= MAX_ACTIVE_WAVES) {
            this.waves.remove(0);
         }
         this.waves.add(new WaveEffect(pos, this.colorMode.is(this.colorCustom), this.color.getColorSafe(), this.colorSecond.getColorSafe()));
      }
   };

   private final EventListener<Render3DEvent> on3DRender = event -> {
      if (!this.waves.isEmpty()) {
         class_4587 ms = event.getMatrices();
         class_4184 camera = mc.field_1773.method_19418();
         class_243 cameraPos = camera.method_71156();
         ms.method_22903();
         ms.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         class_287 fillBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1576);

         for (WaveEffect wave : this.waves) {
            wave.renderFill(fillBuffer, ms);
         }

         class_9801 fillBuilt = fillBuffer.method_60794();
         if (fillBuilt != null) {
            BufferRenderer.drawWithGlobalProgram(fillBuilt);
         }

         class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_29344, class_290.field_1576);

         for (WaveEffect wave : this.waves) {
            wave.renderOutline(linesBuffer, ms);
         }

         class_9801 linesBuilt = linesBuffer.method_60794();
         if (linesBuilt != null) {
            BufferRenderer.drawWithGlobalProgram(linesBuilt);
         }

         RenderSystem.enableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
         ms.method_22909();
         for (int index = this.waves.size() - 1; index >= 0; index--) {
            if (this.waves.get(index).animation.getValue() >= 1.0F) {
               this.waves.remove(index);
            }
         }
      }
   };

   @Override
   public void onDisable() {
      this.waves.clear();
   }

   private boolean isInvisible(class_1309 entity) {
      if (entity.method_6059(class_1294.field_5905)) return true;
      if (entity.method_5767()) return true;
      if (mc.field_1724 != null && entity.method_5756(mc.field_1724)) return true;
      return false;
   }

   private boolean hasVisionBlockingEffect() {
      return mc.field_1724 != null
              && (mc.field_1724.method_6059(class_1294.field_5919)
              || mc.field_1724.method_6059(class_1294.field_38092));
   }

   static class BlockOutline {
      final class_2338 pos;
      final double distance;

      public BlockOutline(class_2338 pos, double distance) {
         this.pos = pos;
         this.distance = distance;
      }
   }

   static class WaveEffect {
      final class_243 centerPos;
      final boolean customColor;
      final ColorRGBA color;
      final ColorRGBA colorSecond;
      final Animation animation = new Animation(1200L, 0.0F, Easing.LINEAR);
      final List<BlockOutline> blocks = new ArrayList<>();
      final int maxRadius = 15;

      public WaveEffect(class_243 pos, boolean customColor, ColorRGBA color, ColorRGBA colorSecond) {
         this.centerPos = pos;
         this.customColor = customColor;
         this.color = color;
         this.colorSecond = colorSecond;
         this.animation.update(true);
         class_2338 centerBlock = class_2338.method_49638(pos);

         for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 15; z++) {
               double distance = Math.sqrt(x * x + z * z);
               if (distance <= 15.0 && distance >= 1.0) {
                  class_2338 foundPos = null;

                  for (int y = 3; y >= -10; y--) {
                     class_2338 checkPos = centerBlock.method_10069(x, y, z);
                     if (IMinecraft.mc.field_1687 != null && !IMinecraft.mc.field_1687.method_8320(checkPos).method_26215()) {
                        foundPos = checkPos;
                        break;
                     }
                  }

                  if (foundPos != null) {
                     this.blocks.add(new BlockOutline(foundPos, distance));
                  }
               }
            }
         }
      }

      void renderFill(class_287 builder, class_4587 ms) {
         this.animation.update(true);
         float progress = this.animation.getValue();
         float currentRadius = progress * 15.0F;
         float waveThickness = 1.0F;

         for (BlockOutline block : this.blocks) {
            float distDiff = Math.abs((float)block.distance - currentRadius);
            if (!(distDiff > waveThickness)) {
               float alpha = 1.0F - distDiff / waveThickness;
               alpha = (float)Math.pow(alpha, 0.5);
               float fadeOut = 1.0F;
               if (progress > 0.7F) {
                  fadeOut = 1.0F - (progress - 0.7F) / 0.3F;
               }

               alpha *= fadeOut;
               if (!(alpha <= 0.05F)) {
                  float scale = 1.0F;
                  if (progress > 0.7F) {
                     scale = 0.5F + 0.5F * fadeOut;
                  }

                  class_243 center = block.pos.method_46558();
                  double halfSize = 0.5 * scale;
                  class_238 box = new class_238(
                          center.field_1352 - halfSize,
                          center.field_1351 - halfSize,
                          center.field_1350 - halfSize,
                          center.field_1352 + halfSize,
                          center.field_1351 + halfSize,
                          center.field_1350 + halfSize
                  );
                  Draw3DUtility.renderFilledBox(ms, builder, box, this.getColor((float)block.distance * 24.0F).withAlpha((int)(alpha * 40.0F)));
               }
            }
         }
      }

      void renderOutline(class_287 builder, class_4587 ms) {
         this.animation.update(true);
         float progress = this.animation.getValue();
         float currentRadius = progress * 15.0F;
         float waveThickness = 1.0F;

         for (BlockOutline block : this.blocks) {
            float distDiff = Math.abs((float)block.distance - currentRadius);
            if (!(distDiff > waveThickness)) {
               float alpha = 1.0F - distDiff / waveThickness;
               alpha = (float)Math.pow(alpha, 0.5);
               float fadeOut = 1.0F;
               if (progress > 0.7F) {
                  fadeOut = 1.0F - (progress - 0.7F) / 0.3F;
               }

               alpha *= fadeOut;
               if (!(alpha <= 0.05F)) {
                  float scale = 1.0F;
                  if (progress > 0.7F) {
                     scale = 0.5F + 0.5F * fadeOut;
                  }

                  class_243 center = block.pos.method_46558();
                  double halfSize = 0.5 * scale;
                  class_238 box = new class_238(
                          center.field_1352 - halfSize,
                          center.field_1351 - halfSize,
                          center.field_1350 - halfSize,
                          center.field_1352 + halfSize,
                          center.field_1351 + halfSize,
                          center.field_1350 + halfSize
                  );
                  Draw3DUtility.renderOutlinedBox(ms, builder, box, this.getColor((float)block.distance * 24.0F).withAlpha((int)(alpha * 255.0F)));
               }
            }
         }
      }

      private ColorRGBA getColor(float index) {
         if (this.customColor) {
            float normalized = (index % 360.0F) / 180.0F;
            float mix = normalized > 1.0F ? 2.0F - normalized : normalized;
            return this.color.mix(this.colorSecond, mix);
         }

         return Colors.getAccentColor(index);
      }
   }
}
