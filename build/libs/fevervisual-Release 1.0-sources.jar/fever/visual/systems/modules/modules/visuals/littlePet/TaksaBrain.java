package fever.visual.systems.modules.modules.visuals.littlePet;

import fever.visual.systems.modules.modules.visuals.littlePet.SmoothValue;
import fever.visual.utility.interfaces.IMinecraft;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class TaksaBrain implements IMinecraft {

    private static final int SMOOTH_SPEED = 150;

    private class_243 pos = null;
    private class_243 motion = class_243.field_1353;
    private float direction = randomDirection();

    private SmoothValue sx = new SmoothValue(0.0f, SMOOTH_SPEED);
    private SmoothValue sy = new SmoothValue(0.0f, SMOOTH_SPEED);
    private SmoothValue sz = new SmoothValue(0.0f, SMOOTH_SPEED);

    private float yaw;
    private float body;
    private SmoothValue bodySmooth  = new SmoothValue(0.0f, SMOOTH_SPEED);
    private SmoothValue yawSmooth   = new SmoothValue(0.0f, SMOOTH_SPEED);
    private SmoothValue pitchSmooth = new SmoothValue(0.0f, SMOOTH_SPEED);

    private boolean lay;
    private long stayingStart = System.currentTimeMillis();

    public float prevLimbSwingAmount;
    public float limbSwingAmount;
    public float limbSwing;

    private class_1657 entity;
    private class_1309 attackTarget;
    private long attackTargetExpiry = 0L;
    private static final long ATTACK_TARGET_TIMEOUT = 3000L;

    public void setEntity(class_1657 e) {
        this.entity = e;
    }

    public void setAttackTarget(class_1309 target) {
        if (target != null && target != mc.field_1724) {
            boolean isPlayer = target instanceof class_1657;
            if (isInvisible(target)) {
                this.attackTarget = null;
                return;
            }
            if (isPlayer && target != mc.field_1724) {
                this.attackTarget = null;
                return;
            }
        }

        this.attackTarget = target;
        this.attackTargetExpiry = System.currentTimeMillis() + ATTACK_TARGET_TIMEOUT;
    }

    private boolean isValidTarget(class_1309 target) {
        if (target == null) return false;
        if (target == mc.field_1724) return false;
        if (target.method_31481() || target.method_29504()) return false;
        if (isInvisible(target)) return false;
        if (target instanceof class_1657 && target != mc.field_1724) return false;

        return true;
    }

    private boolean isInvisible(class_1309 target) {
        if (target.method_6059(class_1294.field_5905)) return true;
        if (target.method_5767()) return true;
        if (mc.field_1724 != null && target.method_5756(mc.field_1724)) return true;
        return false;
    }

    private static float randomDirection() {
        return (float)ThreadLocalRandom.current().nextDouble(360.0);
    }

    public void tick() {
        if (this.entity == null || mc.field_1687 == null) return;

        class_243 playerPos = this.entity.method_73189();

        if (this.pos == null || this.pos.method_1022(playerPos) > 10.0) {
            this.pos = playerPos;
            this.sx = new SmoothValue((float) this.pos.field_1352, SMOOTH_SPEED);
            this.sy = new SmoothValue((float) this.pos.field_1351, SMOOTH_SPEED);
            this.sz = new SmoothValue((float) this.pos.field_1350, SMOOTH_SPEED);
        }

        this.motion = this.motion.method_1031(0.0, -0.2, 0.0);
        class_243 newPos = this.pos.method_1019(this.motion);
        class_2338 bp = class_2338.method_49637(newPos.field_1352, newPos.field_1351 - 0.1, newPos.field_1350);
        if (!mc.field_1687.method_8320(bp).method_26215()) {
            double correctedY = bp.method_10264() + 1 + 0.1;
            newPos = new class_243(newPos.field_1352, correctedY, newPos.field_1350);
            this.motion = new class_243(this.motion.field_1352, 0.0, this.motion.field_1350);
        }
        if (this.attackTarget != null) {
            if (System.currentTimeMillis() > this.attackTargetExpiry || !isValidTarget(this.attackTarget)) {
                this.attackTarget = null;
            }
        }

        class_1309 target = this.attackTarget;
        double dist = newPos.method_1022(playerPos);

        if (target != null && target.method_5805() && isValidTarget(target)) {
            class_243 targetPos = target.method_73189();
            if (mc.field_1687 != null) {
                class_243 dir = targetPos.method_1020(newPos).method_1029();
                class_2338 frontBp = class_2338.method_49637(
                        newPos.field_1352 + dir.field_1352 * 0.5,
                        newPos.field_1351 + 0.5,
                        newPos.field_1350 + dir.field_1350 * 0.5
                );
                if (!mc.field_1687.method_8320(frontBp).method_26215()) {
                    this.motion = new class_243(this.motion.field_1352, 0.62, this.motion.field_1350);
                }
            }
            this.motion = this.motion.method_1019(targetPos.method_1020(newPos).method_1029().method_1021(0.6));
            class_238 taksaBox = new class_238(newPos.method_1023(0.4, 0.0, 0.4), newPos.method_1031(0.4, 0.4, 0.4));
            class_238 targetBox = target.method_5829().method_1009(-0.1, 0.0, -0.1);
            if (taksaBox.method_994(targetBox)) {
                this.motion = new class_243(-this.motion.field_1352, this.motion.field_1351, -this.motion.field_1350);
            }

        } else if (dist > 2.0) {
            this.motion = this.motion.method_1019(playerPos.method_1020(newPos).method_1029().method_1021(0.7));
        }

        this.handleRotation(newPos, target);
        this.pos = newPos;
        if (dist < 0.1 && target == null) {
            this.direction = randomDirection();
            double xMot = -Math.sin(Math.toRadians(this.direction)) * 0.08;
            double zMot =  Math.cos(Math.toRadians(this.direction)) * 0.08;
            this.motion = this.motion.method_1031(xMot, 0.0, zMot);
        }

        this.motion = this.motion.method_1021(0.5);

        this.sx.set((float) this.pos.field_1352);
        this.sy.set((float) this.pos.field_1351);
        this.sz.set((float) this.pos.field_1350);

        this.limbTick();

        float dx = this.sx.get() - (float) this.pos.field_1352;
        float dz = this.sz.get() - (float) this.pos.field_1350;
        boolean moving = Math.abs(dx) > 0.1f || Math.abs(dz) > 0.1f;

        if (moving) {
            this.stayingStart = System.currentTimeMillis();
        }
        this.lay = System.currentTimeMillis() - this.stayingStart > 1000L;
    }

    private void handleRotation(class_243 currentPos, class_1309 target) {
        if (this.motion.field_1352 != 0.0 || this.motion.field_1350 != 0.0) {
            double angle = Math.atan2(this.motion.field_1350, this.motion.field_1352);
            this.yaw = (float) Math.toDegrees(angle) - 90.0f;
            this.yaw %= 360.0f;
            if (this.yaw < 0.0f) this.yaw += 360.0f;
        }

        class_243 lookAt;
        if (target != null && isValidTarget(target)) {
            lookAt = target.method_73189();
        } else {
            lookAt = this.entity.method_73189();
        }

        float[] rot = this.getRotation(currentPos, lookAt);
        float targetYawHead = rot[0];
        float targetPitch   = rot[1];

        float gradus  = this.lay ? 200.0f : 150.0f;
        float gradus1 = this.lay ? 100.0f : 50.0f;

        if (targetYawHead - this.yaw < -gradus || targetYawHead - this.yaw > gradus) {
            this.yaw = targetYawHead;
        }

        float shortestYawPath = ((this.yaw - this.body) % 360.0f + 540.0f) % 360.0f - 180.0f;

        this.bodySmooth.set(this.body + shortestYawPath);
        this.yawSmooth.set(class_3532.method_15363(targetYawHead - this.yaw, -gradus1, gradus1));
        this.pitchSmooth.set(targetPitch);
        this.body += shortestYawPath;
    }

    private float[] getRotation(class_243 from, class_243 to) {
        double dx = to.field_1352 - from.field_1352;
        double dy = to.field_1351 - from.field_1351;
        double dz = to.field_1350 - from.field_1350;
        double hDist = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, hDist)));
        return new float[]{yaw, pitch};
    }

    private void limbTick() {
        this.prevLimbSwingAmount = this.limbSwingAmount;
        double d0 = (double) this.sx.get() - this.pos.field_1352;
        double d2 = (double) this.sz.get() - this.pos.field_1350;
        float f = class_3532.method_15355((float) (d0 * d0 + d2 * d2)) * 4.0f;
        if (f > 1.0f) f = 1.0f;
        this.limbSwingAmount += (f - this.limbSwingAmount) * 0.4f;
        this.limbSwing += this.limbSwingAmount;
    }

    public class_243 getPos() {
        if (this.pos == null) return class_243.field_1353;
        return new class_243(this.sx.get(), this.sy.get(), this.sz.get());
    }

    public float getBody()  { return this.bodySmooth.get(); }
    public float getYaw()   { return this.yawSmooth.get(); }
    public float getPitch() { return this.pitchSmooth.get(); }
    public boolean isLay()  { return this.lay; }
}
