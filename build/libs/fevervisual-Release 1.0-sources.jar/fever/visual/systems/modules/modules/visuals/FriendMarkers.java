//Да давай пасти бездарность :)
//Made by FeverVisuals (NightlyFever)
package fever.visual.systems.modules.modules.visuals;


import lombok.Generated;
import net.minecraft.class_1294;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_9801;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.render.CrystalRenderer;
import fever.visual.utility.render.RenderUtility;
import fever.visual.utility.render.Utils;
import fever.visual.utility.render.compat.BufferRenderer;

@ModuleInfo(name = "Friend Markers", desc = "Выделяет друзей", category = ModuleCategory.DISPLAY)
public class FriendMarkers extends BaseModule {

    private final ModeSetting setting = new ModeSetting(this, "modules.settings.friends_markers.setting");
    private final ModeSetting.Value heads = new ModeSetting.Value(this.setting, "modules.settings.friends_markers.heads");
    private final ModeSetting.Value sims = new ModeSetting.Value(this.setting, "modules.settings.friends_markers.sims");

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (sims.isSelected()) {
            RenderUtility.setupRender3D(true);
            class_4587 ms = event.getMatrices();
            class_4184 camera = mc.field_1773.method_19418();
            class_243 cameraPos = camera.method_71156();
            ColorRGBA color = new ColorRGBA(52.0F, 199.0F, 89.0F);
            class_287 builder = CrystalRenderer.createBuffer();

            for (class_742 player : mc.field_1687.method_18456()) {
                if (!FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
                    continue;
                }

                if (isInvisible(player)) {
                    continue;
                }

                ms.method_22903();
                RenderUtility.prepareMatrices(ms, Utils.getInterpolatedPos(player, event.getTickDelta()));
                float size = 0.1F;
                CrystalRenderer.render(ms, builder, 0.0F, player.method_17682() + 0.4F, 0.0F, size, color.withAlpha(255.0F));
                ms.method_22909();
            }

            class_9801 built = builder.method_60794();
            if (built != null) {
                BufferRenderer.drawWithGlobalProgram(built);
            }

            RenderUtility.endRender3D();
        }
    };

    private boolean isInvisible(class_742 player) {
        if (player.method_6059(class_1294.field_5905)) {
            return true;
        }
        if (player.method_5767()) {
            return true;
        }
        if (mc.field_1724 != null && player.method_5756(mc.field_1724)) {
            return true;
        }
        return false;
    }

    @Generated
    public ModeSetting.Value getHeads() {
        return this.heads;
    }
}
