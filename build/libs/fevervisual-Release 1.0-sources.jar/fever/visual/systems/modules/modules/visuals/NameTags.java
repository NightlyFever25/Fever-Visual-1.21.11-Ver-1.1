package fever.visual.systems.modules.modules.visuals;

import fever.visual.framework.base.CustomDrawContext;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.HudRenderEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.game.EntityVisibility;
import fever.visual.framework.objects.BorderRadius;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

@ModuleInfo(name = "Name Tags", category = ModuleCategory.VISUALS, desc = "Custom projected entity name tags")
public class NameTags extends BaseModule {
    private static NameTags instance;

    private final SelectSetting targets = new SelectSetting(this, "Targets").min(1);
    private final SelectSetting.Value players = new SelectSetting.Value(this.targets, "Players").select();
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targets, "Mobs");
    private final SelectSetting.Value self = new SelectSetting.Value(this.targets, "Self");
    private final BooleanSetting health = new BooleanSetting(this, "Health").enable();
    private final BooleanSetting background = new BooleanSetting(this, "Background").enable();
    private final SliderSetting scale = new SliderSetting(this, "Scale").min(0.65F).max(1.6F).step(0.05F).currentValue(1.0F);
    private final SliderSetting distance = new SliderSetting(this, "Distance").min(8.0F).max(192.0F).step(4.0F).currentValue(96.0F);
    private final List<Tag> tags = new ArrayList<>();
    private long projectedAt;

    public NameTags() {
        instance = this;
    }

    private final EventListener<Render3DEvent> onWorldRender = event -> {
        this.tags.clear();
        if (mc.field_1724 == null || mc.field_1687 == null || event.getCamera() == null) return;
        this.projectedAt = System.currentTimeMillis();
        Matrix4f viewProjection = new Matrix4f(event.getProjectionMatrix()).mul(event.getPositionMatrix());
        class_243 camera = event.getCamera().method_71156();
        float tickDelta = event.getTickDelta();
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living) || !this.shouldRender(living)) continue;
            if (living.method_5858(mc.field_1724) > this.distance.getCurrentValue() * this.distance.getCurrentValue()) continue;
            if (!EntityVisibility.isRenderedAndVisible(living, tickDelta)) continue;
            double x = class_3532.method_16436(tickDelta, living.field_6038, living.method_23317()) - camera.field_1352;
            double y = class_3532.method_16436(tickDelta, living.field_5971, living.method_23318()) + living.method_17682() + 0.35D - camera.field_1351;
            double z = class_3532.method_16436(tickDelta, living.field_5989, living.method_23321()) - camera.field_1350;
            Vector4f clip = new Vector4f((float)x, (float)y, (float)z, 1.0F);
            viewProjection.transform(clip);
            if (clip.w <= 0.001F) continue;
            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;
            if (Math.abs(ndcX) > 1.15F || Math.abs(ndcY) > 1.15F) continue;
            float screenX = (ndcX * 0.5F + 0.5F) * mc.method_22683().method_4486();
            float screenY = (0.5F - ndcY * 0.5F) * mc.method_22683().method_4502();
            this.tags.add(new Tag(living, screenX, screenY));
        }
    };

    private final EventListener<HudRenderEvent> onHudRender = event -> {
        if (System.currentTimeMillis() - this.projectedAt > 100L || mc.field_1687 == null || mc.field_1724 == null) {
            this.tags.clear();
            return;
        }
        CustomDrawContext context = event.getContext();
        float tagScale = this.scale.getCurrentValue();
        Font font = Fonts.MEDIUM.getFont(7.0F * tagScale);
        for (Tag tag : this.tags) {
            String name = tag.entity.method_5476().getString();
            String suffix = this.health.isEnabled() ? "  " + Math.round(tag.entity.method_6032() * 10.0F) / 10.0F + " HP" : "";
            String text = name + suffix;
            float textWidth = font.width(text);
            float width = textWidth + 6.0F * tagScale;
            float height = font.height() + 4.0F * tagScale;
            float x = tag.x - width * 0.5F;
            float y = tag.y - height;
            if (this.background.isEnabled()) {
                context.drawRoundedRect(x, y, width, height, BorderRadius.all(3.0F), new ColorRGBA(12, 14, 18, 190));
                context.drawRoundedBorder(x, y, width, height, 0.7F, BorderRadius.all(3.0F), new ColorRGBA(255, 255, 255, 35));
            }
            ColorRGBA color = tag.entity.field_6235 > 0 ? new ColorRGBA(255, 115, 115, 255) : ColorRGBA.WHITE;
            context.drawText(font, text, tag.x - textWidth * 0.5F, y + 2.0F * tagScale, color);
        }
    };

    private boolean shouldRender(class_1309 entity) {
        if (!entity.method_5805() || entity.method_31481() || isInvisible(entity)) return false;
        if (entity == mc.field_1724) return this.self.isSelected() && mc.field_1690.method_31044() != class_5498.field_26664;
        if (entity instanceof class_1657) return this.players.isSelected() && !entity.method_7325();
        return entity instanceof class_1308 && this.mobs.isSelected() && !entity.method_7325();
    }

    private static boolean isInvisible(class_1309 entity) {
        return entity.method_6059(class_1294.field_5905) || entity.method_5767()
                || mc.field_1724 != null && entity.method_5756(mc.field_1724);
    }

    public static boolean shouldHideVanilla(class_1297 entity) {
        NameTags module = instance;
        return module != null && module.isEnabled() && entity instanceof class_1309 living
                && module.shouldRender(living)
                && EntityVisibility.isRenderedAndVisible(living, mc.method_61966().method_60637(false));
    }

    @Override
    public void onDisable() {
        this.tags.clear();
        this.projectedAt = 0L;
    }

    private record Tag(class_1309 entity, float x, float y) {
    }
}
