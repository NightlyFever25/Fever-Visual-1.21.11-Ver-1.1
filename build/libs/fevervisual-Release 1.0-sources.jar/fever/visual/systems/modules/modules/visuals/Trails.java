package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.BufferRenderer;

import fever.visual.utility.render.compat.GlStateManager;
import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.EntityUtility;
import fever.visual.utility.render.DrawUtility;
import fever.visual.utility.render.RenderUtility;
import fever.visual.utility.render.Utils;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.util.*;

@ModuleInfo(name = "Trails", category = ModuleCategory.VISUALS, desc = "modules.descriptions.trails")
public class Trails extends BaseModule {

    private final SelectSetting targets = new SelectSetting(this, "modules.descriptions.badtrip.targets").min(0);

    private final SelectSetting.Value targetFriends = new SelectSetting.Value(targets, "modules.descriptions.badtrip.friends");
    private final SelectSetting.Value targetSelf = new SelectSetting.Value(targets, "modules.descriptions.badtrip.self");

    private final ModeSetting mode = new ModeSetting(this, "Mode");
    private final ModeSetting.Value stripMode = new ModeSetting.Value(this.mode, "Strip").select();
    private final ModeSetting.Value glowMode = new ModeSetting.Value(this.mode, "Glow");
    private final ModeSetting.Value shardsMode = new ModeSetting.Value(this.mode, "Shards");
    private final ModeSetting.Value energyMode = new ModeSetting.Value(this.mode, "Energy");
    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.move_particles.color_mode");
    private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.trails.sync_with_theme").select();
    private final ModeSetting.Value colorRainbow = new ModeSetting.Value(this.colorMode, "modules.settings.move_particles.color_mode.rainbow", "", () -> true);
    private final ModeSetting.Value colorFriends = new ModeSetting.Value(this.colorMode, "modules.settings.target_esp.color_mode.friends", "", () -> true);
    private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.move_particles.color_mode.custom");
    private final ColorSetting customColorFirst = new ColorSetting(this, "modules.settings.trails.custom_color", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(255, 100, 100, 255))
            .alpha(true);
    private final ColorSetting customColorSecond = new ColorSetting(this, "modules.settings.trails.custom_color_second", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(100, 160, 255, 255))
            .alpha(true);

    private final SliderSetting length = new SliderSetting(this, "modules.settings.trails.length")
            .min(50).max(1000).currentValue(750).step(10);
    private final SliderSetting opacity = new SliderSetting(this, "modules.settings.nimb.opacity")
            .min(0.1F).max(1.0F).currentValue(0.7F).step(0.05F);
    private final SliderSetting shardLength = new SliderSetting(this, "Shards Length", () -> !this.shardsMode.isSelected())
            .min(0.0F).max(8.0F).currentValue(3.0F).step(0.25F);
    private final SliderSetting shardDensity = new SliderSetting(this, "Shards Density", () -> !this.shardsMode.isSelected())
            .min(1.0F).max(10.0F).currentValue(6.0F).step(1.0F);
    private final SliderSetting shardAlpha = new SliderSetting(this, "Shards Alpha", () -> !this.shardsMode.isSelected())
            .min(0.1F).max(1.0F).currentValue(0.7F).step(0.05F);
    private final SliderSetting shardTint = new SliderSetting(this, "Shards Tint", () -> !this.shardsMode.isSelected())
            .min(0.0F).max(100.0F).currentValue(100.0F).step(1.0F);
    private final SliderSetting shardDistort = new SliderSetting(this, "Shards Distortion", () -> !this.shardsMode.isSelected())
            .min(0.0F).max(3.0F).currentValue(1.0F).step(0.1F);
    private final SliderSetting shardReflect = new SliderSetting(this, "Shards Reflect", () -> !this.shardsMode.isSelected())
            .min(0.0F).max(1.0F).currentValue(0.4F).step(0.05F);
    private final BooleanSetting shardSparks = new BooleanSetting(this, "Shards Sparks", () -> !this.shardsMode.isSelected()).enable();
    private final SliderSetting energyLength = new SliderSetting(this, "Energy Length", () -> !this.energyMode.isSelected())
            .min(875.0F).max(1625.0F).currentValue(1200.0F).step(25.0F);
    private final SliderSetting energyShrink = new SliderSetting(this, "Energy Shrink", () -> !this.energyMode.isSelected())
            .min(0.0F).max(100.0F).currentValue(35.0F).step(5.0F);
    private final SliderSetting energySpread = new SliderSetting(this, "Energy Spread", () -> !this.energyMode.isSelected())
            .min(15.0F).max(30.0F).currentValue(16.0F).step(0.5F);
    private final SliderSetting energyRise = new SliderSetting(this, "Energy Rise", () -> !this.energyMode.isSelected())
            .min(-12.0F).max(12.0F).currentValue(-0.5F).step(0.5F);
    private final BooleanSetting energyGlow = new BooleanSetting(this, "Energy Glow", () -> !this.energyMode.isSelected()).enable();
    private final BooleanSetting energyWalls = new BooleanSetting(this, "Energy Through Walls", () -> !this.energyMode.isSelected()).enabled(false);
    private final Map<class_1657, List<TrailPoint>> trailsMap = new HashMap<>();
    private final Map<class_1657, List<ShardBurst>> shardBursts = new HashMap<>();
    private final Map<class_1657, class_243> lastShardPositions = new HashMap<>();
    private final Map<class_1657, EnergyState> energyStates = new HashMap<>();
    private long lastUpdateTime = 0;

    private final EventListener<Render3DEvent> onRender3D = new EventListener<>() {
        @Override
        public void onEvent(Render3DEvent event) {
            if (!EntityUtility.isInGame()) return;

            long now = System.currentTimeMillis();
            long trailLifetimeMs = (long) length.getCurrentValue();
            long renderLifetime = Trails.this.energyMode.isSelected() ? (long)Trails.this.energyLength.getCurrentValue() : trailLifetimeMs;
            long updateInterval = Trails.this.energyMode.isSelected() ? 8L : 50L;
            if (now - lastUpdateTime > updateInterval) {
                updateTrails(now, renderLifetime);
                lastUpdateTime = now;
            }
            renderTrails(event, now, renderLifetime);
        }

        @Override
        public int getPriority() {
            return -100;
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
        trailsMap.clear();
        shardBursts.clear();
        lastShardPositions.clear();
        energyStates.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        trailsMap.clear();
        shardBursts.clear();
        lastShardPositions.clear();
        energyStates.clear();
    }

    private void updateTrails(long now, long trailLifetimeMs) {
        if (mc.field_1687 == null) {
            trailsMap.clear();
            return;
        }

        for (class_1657 entity : mc.field_1687.method_18456()) {
            if (entity == null || entity == mc.field_1724 && mc.field_1690.method_31044() == class_5498.field_26664) {
                continue;
            }

            if (!shouldRenderTrails(entity)) {
                trailsMap.remove(entity);
                continue;
            }

            List<TrailPoint> trails = trailsMap.computeIfAbsent(entity, k -> new ArrayList<>());
            for (int i = trails.size() - 1; i >= 0; i--) {
                if (trails.get(i).isExpired(now, trailLifetimeMs)) {
                    trails.remove(i);
                }
            }
            class_243 currentPos = entity.method_73189();
            if (this.shardsMode.isSelected()) {
                this.updateShardBursts(entity, currentPos, now);
            }
            if (this.energyMode.isSelected()) {
                this.energyStates.computeIfAbsent(entity, ignored -> new EnergyState()).sample(entity, currentPos, now, trailLifetimeMs);
            }
            if (trails.isEmpty()) {
                trails.add(new TrailPoint(currentPos, getTrailColor(entity, 0).getRGB(), now));
            } else {
                TrailPoint last = trails.get(trails.size() - 1);
                double distance = last.pos.method_1022(currentPos);
                if (distance > 8.0) {
                    trails.clear();
                    trails.add(new TrailPoint(currentPos, getTrailColor(entity, 0).getRGB(), now));
                    continue;
                }
                if (distance >= 0.05f) {
                    int steps = Math.min(24, Math.max(1, (int) (distance / 0.05f)));
                    for (int i = 1; i <= steps; i++) {
                        double t = (double) i / steps;
                        class_243 interpolated = new class_243(
                                class_3532.method_16436(t, last.pos.field_1352, currentPos.field_1352),
                                class_3532.method_16436(t, last.pos.field_1351, currentPos.field_1351),
                                class_3532.method_16436(t, last.pos.field_1350, currentPos.field_1350)
                        );
                        trails.add(new TrailPoint(interpolated,
                                getTrailColor(entity, trails.size()).getRGB(),
                                now - (long)((1 - t) * (now - last.time))));
                    }
                }
            }
        }

        trailsMap.entrySet().removeIf(entry -> {
            class_1657 player = entry.getKey();
            return player == null || !player.method_5805() || !mc.field_1687.method_18456().contains(player) || !shouldRenderTrails(player);
        });
        this.shardBursts.entrySet().removeIf(entry -> !shouldRenderTrails(entry.getKey()));
        this.lastShardPositions.keySet().removeIf(player -> !shouldRenderTrails(player));
        this.energyStates.entrySet().removeIf(entry -> !shouldRenderTrails(entry.getKey()));

        long shardLife = Math.max(250L, trailLifetimeMs);
        this.shardBursts.values().forEach(list -> list.removeIf(burst -> now - burst.spawnTime > shardLife));
        if (!this.shardsMode.isSelected()) {
            this.shardBursts.clear();
            this.lastShardPositions.clear();
        }
        if (!this.energyMode.isSelected()) {
            this.energyStates.clear();
        }
    }

    private void updateShardBursts(class_1657 entity, class_243 currentPos, long now) {
        class_243 previous = this.lastShardPositions.put(entity, currentPos);
        if (previous == null || previous.method_1025(currentPos) > 64.0D) {
            return;
        }
        class_243 movement = currentPos.method_1020(previous);
        if (movement.method_37268() < 0.04D) {
            return;
        }
        class_243 direction = new class_243(movement.field_1352, 0.0D, movement.field_1350).method_1029();
        List<ShardBurst> bursts = this.shardBursts.computeIfAbsent(entity, ignored -> new ArrayList<>());
        int count = class_3532.method_15340(Math.round(this.shardDensity.getCurrentValue() * 0.65F), 2, 8);
        long seed = now ^ ((long)entity.method_5628() << 32) ^ bursts.size() * 0x9E3779B97F4A7C15L;
        bursts.add(new ShardBurst(currentPos, direction, now, seed, getTrailColor(entity, bursts.size()).getRGB(), count));
        while (bursts.size() > 64) {
            bursts.remove(0);
        }
    }

    private void renderTrails(Render3DEvent event, long now, long trailLifetimeMs) {
        class_4587 matrices = event.getMatrices();
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        try {
            if (this.shardsMode.isSelected()) {
                this.renderShardBursts(matrices, cameraPos, now, trailLifetimeMs);
                return;
            }
            if (this.energyMode.isSelected()) {
                this.renderEnergyStates(matrices, cameraPos, now, trailLifetimeMs);
                return;
            }
            for (Map.Entry<class_1657, List<TrailPoint>> entry : trailsMap.entrySet()) {
                class_1657 entity = entry.getKey();
                List<TrailPoint> trails = entry.getValue();

                if (trails.size() < 2 || !shouldRenderTrails(entity)
                        || !Utils.isInViewHemisphere(camera, entity.method_23317(), entity.method_23318() + entity.method_17682() * 0.5, entity.method_23321(), 4.0)) continue;

                if (this.stripMode.isSelected()) {
                    renderTrailStrip(matrices, cameraPos, entity.method_17682(), trails, now, trailLifetimeMs);
                } else if (this.glowMode.isSelected()) {
                    renderGlowTrail(matrices, event.getCamera(), trails, now, trailLifetimeMs);
                }
            }
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        }
    }

    private void renderShardBursts(class_4587 matrices, class_243 cameraPos, long now, long lifetime) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, FeverVisual.id("textures/bloom.png"));
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
        Matrix4f matrix = matrices.method_23760().method_23761();
        boolean emitted = false;
        for (List<ShardBurst> bursts : this.shardBursts.values()) {
            for (ShardBurst burst : bursts) {
                float age = class_3532.method_15363((now - burst.spawnTime) / (float)Math.max(1L, lifetime), 0.0F, 1.0F);
                float appear = class_3532.method_15363(age / 0.08F, 0.0F, 1.0F);
                float fade = class_3532.method_15363((1.0F - age) / 0.28F, 0.0F, 1.0F);
                float alpha = appear * fade * this.opacity.getCurrentValue() * this.shardAlpha.getCurrentValue();
                if (alpha <= 0.01F) continue;
                class_243 side = new class_243(-burst.direction.field_1350, 0.0D, burst.direction.field_1352);
                for (int i = 0; i < burst.count; i++) {
                    float r1 = hash01(burst.seed, i * 5 + 1);
                    float r2 = hash01(burst.seed, i * 5 + 2);
                    float r3 = hash01(burst.seed, i * 5 + 3);
                    double behind = 0.08D + r1 * 0.42D;
                    double lateral = (r2 - 0.5D) * (0.55D + this.shardDistort.getCurrentValue() * 0.14D);
                    double height = 0.14D + r3 * 1.55D;
                    // The tiny forward drift belongs to the burst itself and never follows the player.
                    class_243 center = burst.origin.method_1020(burst.direction.method_1021(behind + age * age * 0.28D))
                            .method_1019(side.method_1021(lateral)).method_1031(0.0D, height, 0.0D).method_1020(cameraPos);
                    float halfHeight = 0.014F + 0.012F * this.shardReflect.getCurrentValue();
                    float halfLength = halfHeight * (5.0F + this.shardLength.getCurrentValue());
                    ColorRGBA source = ColorRGBA.fromInt(burst.color);
                    float tint = class_3532.method_15363(this.shardTint.getCurrentValue() / 100.0F, 0.0F, 1.0F);
                    ColorRGBA color = new ColorRGBA(
                            255.0F + (source.getRed() - 255.0F) * tint,
                            255.0F + (source.getGreen() - 255.0F) * tint,
                            255.0F + (source.getBlue() - 255.0F) * tint,
                            220.0F * alpha);
                    emitWorldDash(buffer, matrix, center, burst.direction, halfLength, halfHeight, color);
                    if (this.shardSparks.isEnabled() && (i & 1) == 0) {
                        class_243 spark = center.method_1019(side.method_1021((r1 - 0.5D) * 0.24D)).method_1031(0.0D, (r2 - 0.5D) * 0.2D, 0.0D);
                        emitWorldDash(buffer, matrix, spark, burst.direction, halfLength * 0.22F, halfHeight * 1.25F, source.withAlpha(170.0F * alpha));
                    }
                    emitted = true;
                }
            }
        }
        class_9801 built = buffer.method_60794();
        if (emitted && built != null) BufferRenderer.drawWithGlobalProgram(built);
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
    }

    private void renderEnergyStates(class_4587 matrices, class_243 cameraPos, long now, long lifetime) {
        if (this.energyWalls.isEnabled()) RenderSystem.disableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, this.energyGlow.isEnabled()
                ? GlStateManager.DstFactor.ONE : GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1576);
        Matrix4f matrix = matrices.method_23760().method_23761();
        boolean emitted = false;
        for (EnergyState state : this.energyStates.values()) {
            for (EnergyRibbon ribbon : state.ribbons) {
                ribbon.prune(now, lifetime);
                if (ribbon.points.size() < 2) continue;
                emitted |= this.renderEnergyRibbon(buffer, matrix, cameraPos, ribbon, now, lifetime);
            }
        }
        class_9801 built = buffer.method_60794();
        if (emitted && built != null) BufferRenderer.drawWithGlobalProgram(built);
        if (this.energyWalls.isEnabled()) RenderSystem.enableDepthTest();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
    }

    private boolean renderEnergyRibbon(class_287 buffer, Matrix4f matrix, class_243 cameraPos, EnergyRibbon ribbon,
                                       long now, long lifetime) {
        List<EnergyPoint> points = new ArrayList<>(ribbon.points);
        if (ribbon.livePosition != null && !points.isEmpty()) {
            points.add(new EnergyPoint(ribbon.livePosition, now, ribbon.liveColor, class_243.field_1353, 0.0F));
        }
        boolean emitted = false;
        for (int i = 0; i + 1 < points.size(); i++) {
            EnergyPoint a = points.get(i);
            EnergyPoint b = points.get(i + 1);
            float ageA = class_3532.method_15363((now - a.time) / (float)Math.max(1L, lifetime), 0.0F, 1.0F);
            float ageB = class_3532.method_15363((now - b.time) / (float)Math.max(1L, lifetime), 0.0F, 1.0F);
            class_243 pa = energyPosition(a, ageA).method_1020(cameraPos);
            class_243 pb = energyPosition(b, ageB).method_1020(cameraPos);
            class_243 tangent = pb.method_1020(pa);
            if (tangent.method_1027() < 1.0E-8D) continue;
            tangent = tangent.method_1029();
            class_243 viewA = pa.method_1027() < 1.0E-8D ? new class_243(0.0D, 0.0D, 1.0D) : pa.method_1029();
            class_243 viewB = pb.method_1027() < 1.0E-8D ? viewA : pb.method_1029();
            class_243 sideA = tangent.method_1036(viewA);
            class_243 sideB = tangent.method_1036(viewB);
            if (sideA.method_1027() < 1.0E-8D) sideA = new class_243(1.0D, 0.0D, 0.0D);
            if (sideB.method_1027() < 1.0E-8D) sideB = sideA;
            sideA = sideA.method_1029();
            sideB = sideB.method_1029();

            float restA = 1.0F - ageA;
            float restB = 1.0F - ageB;
            float growA = class_3532.method_15363((now - a.time) / 120.0F, 0.0F, 1.0F);
            float growB = class_3532.method_15363((now - b.time) / 120.0F, 0.0F, 1.0F);
            growA = growA * growA * (3.0F - 2.0F * growA);
            growB = growB * growB * (3.0F - 2.0F * growB);
            float alphaA = 0.05F * 0.75F * a.power * ribbon.brightness * growA * restA * restA;
            float alphaB = 0.05F * 0.75F * b.power * ribbon.brightness * growB * restB * restB;
            if (alphaA <= 0.002F && alphaB <= 0.002F) continue;
            float shrink = class_3532.method_15363(this.energyShrink.getCurrentValue() / 100.0F, 0.0F, 1.0F);
            float widthA = ribbon.width * (1.0F - shrink * ageA);
            float widthB = ribbon.width * (1.0F - shrink * ageB);
            ColorRGBA ca = ColorRGBA.fromInt(a.color).withAlpha(255.0F * alphaA);
            ColorRGBA cb = ColorRGBA.fromInt(b.color).withAlpha(255.0F * alphaB);
            emitEnergySpan(buffer, matrix, pa, pb, sideA, sideB, widthA * 1.25F, widthB * 1.25F,
                    ca.withAlpha(ca.getAlpha() * 0.45F), cb.withAlpha(cb.getAlpha() * 0.45F));
            emitEnergySpan(buffer, matrix, pa, pb, sideA, sideB, widthA * 0.5F, widthB * 0.5F, ca, cb);
            emitted = true;
        }
        return emitted;
    }

    private class_243 energyPosition(EnergyPoint point, float age) {
        double travel = this.energySpread.getCurrentValue() * 0.0625D * age * Math.sqrt(age);
        return point.pos.method_1019(point.drift.method_1021(travel)).method_1031(0.0D, this.energyRise.getCurrentValue() * 0.0625D * age, 0.0D);
    }

    private static void emitEnergySpan(class_287 buffer, Matrix4f matrix, class_243 a, class_243 b,
                                       class_243 sideA, class_243 sideB, float halfA, float halfB,
                                       ColorRGBA colorA, ColorRGBA colorB) {
        class_243 al = a.method_1020(sideA.method_1021(halfA));
        class_243 ar = a.method_1019(sideA.method_1021(halfA));
        class_243 bl = b.method_1020(sideB.method_1021(halfB));
        class_243 br = b.method_1019(sideB.method_1021(halfB));
        buffer.method_22918(matrix, (float)al.field_1352, (float)al.field_1351, (float)al.field_1350).method_39415(colorA.getRGB());
        buffer.method_22918(matrix, (float)ar.field_1352, (float)ar.field_1351, (float)ar.field_1350).method_39415(colorA.getRGB());
        buffer.method_22918(matrix, (float)br.field_1352, (float)br.field_1351, (float)br.field_1350).method_39415(colorB.getRGB());
        buffer.method_22918(matrix, (float)bl.field_1352, (float)bl.field_1351, (float)bl.field_1350).method_39415(colorB.getRGB());
    }

    private static float hash01(long seed, int salt) {
        long value = seed + salt * 0x9E3779B97F4A7C15L;
        value = (value ^ (value >>> 30)) * 0xBF58476D1CE4E5B9L;
        value = (value ^ (value >>> 27)) * 0x94D049BB133111EBL;
        return ((value ^ (value >>> 31)) >>> 40) / (float)(1L << 24);
    }

    private void renderGlowTrail(class_4587 matrices, class_4184 camera, List<TrailPoint> trails, long now, long trailLifetimeMs) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, FeverVisual.id("textures/bloom.png"));
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
        boolean hasVertices = false;
        for (int i = 0; i < trails.size(); i++) {
            TrailPoint point = trails.get(i);
            if (point.isExpired(now, trailLifetimeMs)) continue;
            float ageFrac = (float)(now - point.time) / (float)trailLifetimeMs;
            float alpha = (1.0F - Math.min(1.0F, ageFrac)) * opacity.getCurrentValue();
            float size = 0.18F + 0.28F * (1.0F - ageFrac);
            ColorRGBA color = ColorRGBA.fromInt(point.color).withAlpha(255.0F * alpha);
            matrices.method_22903();
            RenderUtility.prepareMatrices(matrices, point.pos.method_1031(0.0D, 0.72D + (i % 3) * 0.08D, 0.0D));
            matrices.method_22907(camera.method_23767());
            DrawUtility.drawImage(matrices, buffer, -size, -size, 0.0D, size * 2.0F, size * 2.0F, color);
            matrices.method_22909();
            hasVertices = true;
        }
        class_9801 built = buffer.method_60794();
        if (hasVertices && built != null) {
            BufferRenderer.drawWithGlobalProgram(built);
        }
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
    }

    private void renderShardTrail(class_4587 matrices, class_243 cameraPos, List<TrailPoint> trails, long now, long trailLifetimeMs) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, FeverVisual.id("textures/bloom.png"));
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
        Matrix4f matrix = matrices.method_23760().method_23761();
        boolean hasVertices = false;
        int stride = Math.max(1, 12 - Math.round(this.shardDensity.getCurrentValue()));
        for (int i = 0; i < trails.size(); i += stride) {
            TrailPoint point = trails.get(i);
            if (point.isExpired(now, trailLifetimeMs)) continue;
            float ageFrac = (float)(now - point.time) / (float)trailLifetimeMs;
            float alpha = (1.0F - Math.min(1.0F, ageFrac)) * opacity.getCurrentValue() * shardAlpha.getCurrentValue();
            double angle = i * 2.399963229728653D;
            double burst = class_3532.method_15363(ageFrac / 0.22F, 0.0F, 1.0F);
            double spread = (0.12D + this.shardDistort.getCurrentValue() * 0.08D) * burst;
            double side = Math.cos(angle) * spread;
            double up = 0.22D + (i % 5) * 0.22D + Math.sin(angle * 1.7D) * 0.05D;
            class_243 center = point.pos.method_1031(side, up, Math.sin(angle) * spread);
            float h = (0.018F + 0.018F * this.shardReflect.getCurrentValue()) * opacity.getCurrentValue();
            float w = h * (5.0F + this.shardLength.getCurrentValue() * 1.1F);
            ColorRGBA source = ColorRGBA.fromInt(point.color);
            float tint = class_3532.method_15363(this.shardTint.getCurrentValue() / 100.0F, 0.0F, 1.0F);
            ColorRGBA color = new ColorRGBA(
                    255.0F + (source.getRed() - 255.0F) * tint,
                    255.0F + (source.getGreen() - 255.0F) * tint,
                    255.0F + (source.getBlue() - 255.0F) * tint,
                    180.0F * alpha
            );
            class_243 direction = trailDirection(trails, i);
            emitWorldDash(buffer, matrix, center.method_1020(cameraPos), direction, w, h, color);
            hasVertices = true;
            if (this.shardSparks.isEnabled() && (i % (stride * 2) == 0)) {
                float sparkSize = Math.max(h * 1.8F, 0.025F);
                ColorRGBA sparkColor = source.withAlpha(190.0F * alpha);
                class_243 sparkCenter = center.method_1031(Math.sin(angle * 1.7D) * 0.18D, Math.cos(angle) * 0.06D, Math.cos(angle * 1.3D) * 0.18D).method_1020(cameraPos);
                emitWorldDash(buffer, matrix, sparkCenter, direction, sparkSize * 1.8F, sparkSize, sparkColor);
            }
        }
        class_9801 built = buffer.method_60794();
        if (hasVertices && built != null) {
            BufferRenderer.drawWithGlobalProgram(built);
        }
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
    }

    private void renderEnergyTrail(class_4587 matrices, class_243 cameraPos, float playerHeight, List<TrailPoint> trails, long now, long trailLifetimeMs) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, FeverVisual.id("textures/bloom.png"));
        if (this.energyGlow.isEnabled()) {
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        } else {
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        }
        if (this.energyWalls.isEnabled()) {
            RenderSystem.disableDepthTest();
        }
        class_287 glow = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
        Matrix4f matrix = matrices.method_23760().method_23761();
        boolean hasGlow = false;
        int stride = 3;
        float shrink = class_3532.method_15363(this.energyShrink.getCurrentValue() / 100.0F, 0.0F, 1.0F);
        float spread = this.energySpread.getCurrentValue() / 16.0F;
        float rise = this.energyRise.getCurrentValue() / 12.0F;
        for (int i = 0; i < trails.size(); i += stride) {
            TrailPoint point = trails.get(i);
            if (point.isExpired(now, trailLifetimeMs)) continue;
            float ageFrac = (float)(now - point.time) / (float)trailLifetimeMs;
            float alpha = (1.0F - Math.min(1.0F, ageFrac)) * opacity.getCurrentValue();
            float tailScale = 1.0F - shrink * ageFrac;
            class_243 direction = trailDirection(trails, i);
            class_243 sideDirection = new class_243(-direction.field_1350, 0.0D, direction.field_1352);
            for (int layer = 0; layer < 5; layer++) {
                double phase = i * 0.37D + layer * 2.11D + now * 0.001D;
                double side = Math.sin(phase) * (0.10D + layer * 0.07D) * spread;
                double y = playerHeight * 0.5D + Math.cos(phase * 0.7D) * 0.04D + rise * ageFrac;
                float halfLength = (0.42F + layer * 0.16F + 0.35F * (1.0F - ageFrac)) * tailScale;
                float halfHeight = (playerHeight * (0.48F + layer * 0.025F)) * tailScale;
                ColorRGBA color = ColorRGBA.fromInt(point.color).mix(Colors.getAccentColor(i * 9.0F + layer * 58.0F), 0.65F)
                        .withAlpha((82.0F - layer * 9.0F) * alpha);
                class_243 center = point.pos.method_1019(sideDirection.method_1021(side)).method_1031(0.0D, y, 0.0D).method_1020(cameraPos);
                emitVerticalGlow(glow, matrix, center, direction, halfLength, halfHeight, color);
                hasGlow = true;
            }
        }
        class_9801 glowBuilt = glow.method_60794();
        if (hasGlow && glowBuilt != null) {
            BufferRenderer.drawWithGlobalProgram(glowBuilt);
        }
        if (this.energyWalls.isEnabled()) {
            RenderSystem.enableDepthTest();
        }
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
    }

    private static class_243 trailDirection(List<TrailPoint> trails, int index) {
        class_243 before = trails.get(Math.max(0, index - 2)).pos;
        class_243 after = trails.get(Math.min(trails.size() - 1, index + 2)).pos;
        class_243 direction = new class_243(after.field_1352 - before.field_1352, 0.0D, after.field_1350 - before.field_1350);
        return direction.method_1027() < 1.0E-6D ? new class_243(1.0D, 0.0D, 0.0D) : direction.method_1029();
    }

    private static void emitWorldDash(class_287 buffer, Matrix4f matrix, class_243 center, class_243 direction, float halfLength, float halfThickness, ColorRGBA color) {
        class_243 along = direction.method_1021(halfLength);
        class_243 up = new class_243(0.0D, halfThickness, 0.0D);
        texturedQuad(buffer, matrix, center.method_1020(along).method_1020(up), center.method_1019(along).method_1020(up), center.method_1019(along).method_1019(up), center.method_1020(along).method_1019(up), color);

        class_243 side = new class_243(-direction.field_1350, 0.0D, direction.field_1352).method_1021(halfThickness);
        texturedQuad(buffer, matrix, center.method_1020(along).method_1020(side), center.method_1019(along).method_1020(side), center.method_1019(along).method_1019(side), center.method_1020(along).method_1019(side), color.withAlpha(color.getAlpha() * 0.72F));
    }

    private static void emitVerticalGlow(class_287 buffer, Matrix4f matrix, class_243 center, class_243 direction, float halfLength, float halfHeight, ColorRGBA color) {
        class_243 along = direction.method_1021(halfLength);
        class_243 up = new class_243(0.0D, halfHeight, 0.0D);
        texturedQuad(buffer, matrix, center.method_1020(along).method_1020(up), center.method_1019(along).method_1020(up), center.method_1019(along).method_1019(up), center.method_1020(along).method_1019(up), color);

        class_243 sideDirection = new class_243(-direction.field_1350, 0.0D, direction.field_1352);
        class_243 side = sideDirection.method_1021(halfLength * 0.45F);
        texturedQuad(buffer, matrix, center.method_1020(side).method_1020(up), center.method_1019(side).method_1020(up), center.method_1019(side).method_1019(up), center.method_1020(side).method_1019(up), color.withAlpha(color.getAlpha() * 0.55F));
    }

    private static void texturedQuad(class_287 buffer, Matrix4f matrix, class_243 a, class_243 b, class_243 c, class_243 d, ColorRGBA color) {
        int rgba = color.getRGB();
        buffer.method_22918(matrix, (float)a.field_1352, (float)a.field_1351, (float)a.field_1350).method_22913(0.0F, 1.0F).method_39415(rgba);
        buffer.method_22918(matrix, (float)b.field_1352, (float)b.field_1351, (float)b.field_1350).method_22913(1.0F, 1.0F).method_39415(rgba);
        buffer.method_22918(matrix, (float)c.field_1352, (float)c.field_1351, (float)c.field_1350).method_22913(1.0F, 0.0F).method_39415(rgba);
        buffer.method_22918(matrix, (float)d.field_1352, (float)d.field_1351, (float)d.field_1350).method_22913(0.0F, 0.0F).method_39415(rgba);
    }

    private void renderTrailStrip(class_4587 matrices, class_243 cameraPos, float playerHeight, List<TrailPoint> trails, long now, long trailLifetimeMs) {
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27380, class_290.field_1576);
        Matrix4f positionMatrix = matrices.method_23760().method_23761();
        float actualOpacity = opacity.getCurrentValue();
        boolean hasVertices = false;

        for (TrailPoint point : trails) {
            if (point.isExpired(now, trailLifetimeMs)) continue;

            float ageFrac = (float) (now - point.time) / (float) trailLifetimeMs;
            float alpha = 1f - Math.min(1f, ageFrac);
            alpha = Math.max(0.01f, alpha) * actualOpacity;

            int color = (class_3532.method_15340(Math.round(alpha * 255.0F), 0, 255) << 24) | (point.color & 0x00FFFFFF);
            float x = (float) (point.pos.field_1352 - cameraPos.field_1352);
            float yBottom = (float) (point.pos.field_1351 - cameraPos.field_1351);
            float yTop = yBottom + playerHeight;
            float z = (float) (point.pos.field_1350 - cameraPos.field_1350);

            buffer.method_22918(positionMatrix, x, yTop, z)
                    .method_39415(color);
            buffer.method_22918(positionMatrix, x, yBottom, z)
                    .method_39415(color);
            hasVertices = true;
        }

        if (hasVertices) {
            BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
        } else {
            buffer.method_60794();
        }
    }

    private ColorRGBA getTrailColor(class_1657 entity, int index) {
        if (colorCustom.isSelected()) {
            return customColorFirst.getColor().mix(customColorSecond.getColor(), (index % 40) / 39.0F);
        }

        return Colors.getAccentColor(index * 6.0F);
    }

    private boolean shouldRenderTrails(class_1657 entity) {
        if (entity == mc.field_1724) {
            if (mc.field_1690.method_31044() == class_5498.field_26664) {
                return false;
            }
            return targetSelf.isSelected();
        }
        if (targetFriends.isSelected() && FeverVisual.getInstance().getFriendManager().isFriend(entity.method_5477().getString())) {
            return !isPlayerInvisible(entity);
        }
        return false;
    }

    private boolean isPlayerInvisible(class_1657 player) {
        if (player == mc.field_1724) return false;
        if (player.method_6059(class_1294.field_5905)) return true;
        if (player.method_5767()) return true;
        if (player.method_5756(mc.field_1724)) return true;
        return false;
    }

    private record ShardBurst(class_243 origin, class_243 direction, long spawnTime, long seed, int color, int count) {
    }

    private static final List<SurfaceSample> ENERGY_SURFACE = createEnergySurface();

    private static List<SurfaceSample> createEnergySurface() {
        List<SurfaceSample> samples = new ArrayList<>();
        addBoxSurface(samples, 0.0D, 1.55D, 0.0D, 0.25D, 0.25D, 0.25D);
        addBoxSurface(samples, 0.0D, 1.05D, 0.0D, 0.25D, 0.375D, 0.125D);
        addBoxSurface(samples, -0.375D, 1.05D, 0.0D, 0.125D, 0.375D, 0.125D);
        addBoxSurface(samples, 0.375D, 1.05D, 0.0D, 0.125D, 0.375D, 0.125D);
        addBoxSurface(samples, -0.125D, 0.375D, 0.0D, 0.125D, 0.375D, 0.125D);
        addBoxSurface(samples, 0.125D, 0.375D, 0.0D, 0.125D, 0.375D, 0.125D);
        return List.copyOf(samples);
    }

    private static void addBoxSurface(List<SurfaceSample> out, double cx, double cy, double cz,
                                      double hx, double hy, double hz) {
        addFace(out, cx, cy, cz, hx, hy, hz, 0, -1.0D);
        addFace(out, cx, cy, cz, hx, hy, hz, 0, 1.0D);
        addFace(out, cx, cy, cz, hx, hy, hz, 1, -1.0D);
        addFace(out, cx, cy, cz, hx, hy, hz, 1, 1.0D);
        addFace(out, cx, cy, cz, hx, hy, hz, 2, -1.0D);
        addFace(out, cx, cy, cz, hx, hy, hz, 2, 1.0D);
    }

    private static void addFace(List<SurfaceSample> out, double cx, double cy, double cz,
                                double hx, double hy, double hz, int axis, double sign) {
        double spacing = 1.25D / 16.0D;
        double uHalf = axis == 0 ? hz : hx;
        double vHalf = axis == 1 ? hz : hy;
        int stepsU = class_3532.method_15340((int)Math.round(uHalf * 2.0D / spacing), 1, 24);
        int stepsV = class_3532.method_15340((int)Math.round(vHalf * 2.0D / spacing), 1, 24);
        class_243 normal = axis == 0 ? new class_243(sign, 0.0D, 0.0D)
                : axis == 1 ? new class_243(0.0D, sign, 0.0D) : new class_243(0.0D, 0.0D, sign);
        for (int u = 0; u < stepsU; u++) {
            double fu = ((u + 0.5D) / stepsU * 2.0D - 1.0D) * uHalf;
            for (int v = 0; v < stepsV; v++) {
                double fv = ((v + 0.5D) / stepsV * 2.0D - 1.0D) * vHalf;
                class_243 offset;
                if (axis == 0) offset = new class_243(cx + sign * hx, cy + fv, cz + fu);
                else if (axis == 1) offset = new class_243(cx + fu, cy + sign * hy, cz + fv);
                else offset = new class_243(cx + fu, cy + fv, cz + sign * hz);
                out.add(new SurfaceSample(offset.method_1019(normal.method_1021(0.02D)), normal));
            }
        }
    }

    private final class EnergyState {
        private static final int SAMPLE_COUNT = 20;
        private final EnergyRibbon[] ribbons = new EnergyRibbon[ENERGY_SURFACE.size()];
        private float smoothPower;
        private long lastSample;
        private long lastPower;

        private EnergyState() {
            for (int i = 0; i < this.ribbons.length; i++) {
                this.ribbons[i] = new EnergyRibbon(i);
            }
        }

        private void sample(class_1657 entity, class_243 position, long now, long lifetime) {
            double moveX = entity.method_23317() - entity.field_6038;
            double moveZ = entity.method_23321() - entity.field_5989;
            float speed = (float)Math.sqrt(moveX * moveX + moveZ * moveZ);
            float targetPower = class_3532.method_15363(speed / 0.25F, 0.0F, 1.0F);
            long elapsed = this.lastPower == 0L ? 0L : class_3532.method_53062(now - this.lastPower, 0L, 250L);
            this.lastPower = now;
            float rate = 1.0F - (float)Math.exp(-elapsed / 190.0D);
            this.smoothPower += (targetPower - this.smoothPower) * rate;
            boolean push = this.smoothPower > 0.01F && now - this.lastSample >= Math.max(8L, lifetime / SAMPLE_COUNT);
            if (push) this.lastSample = now;

            float yaw = (float)Math.toRadians(entity.field_6283);
            class_243 right = new class_243(Math.cos(yaw), 0.0D, Math.sin(yaw));
            class_243 forward = new class_243(-Math.sin(yaw), 0.0D, Math.cos(yaw));
            for (int i = 0; i < this.ribbons.length; i++) {
                SurfaceSample sample = ENERGY_SURFACE.get(i);
                class_243 offset = sample.offset;
                class_243 world = position.method_1019(right.method_1021(offset.field_1352)).method_1031(0.0D, offset.field_1351, 0.0D).method_1019(forward.method_1021(offset.field_1350));
                class_243 localNormal = sample.normal;
                class_243 normal = right.method_1021(localNormal.field_1352).method_1031(0.0D, localNormal.field_1351, 0.0D).method_1019(forward.method_1021(localNormal.field_1350));
                EnergyRibbon ribbon = this.ribbons[i];
                ribbon.livePosition = world;
                ribbon.liveColor = getTrailColor(entity, i * 7 + ribbon.points.size()).getRGB();
                if (!push) continue;
                double fx = Math.sin(world.field_1351 * 0.85D * 1.7D + world.field_1350 * 0.85D * 0.9D)
                        + 0.5D * Math.cos(world.field_1350 * 0.85D * 2.3D - world.field_1352 * 0.85D * 1.1D);
                double fy = Math.sin(world.field_1350 * 0.85D * 1.3D + world.field_1352 * 0.85D * 1.9D)
                        + 0.5D * Math.cos(world.field_1352 * 0.85D * 2.1D - world.field_1351 * 0.85D * 0.7D);
                double fz = Math.sin(world.field_1352 * 0.85D * 1.1D + world.field_1351 * 0.85D * 2.1D)
                        + 0.5D * Math.cos(world.field_1351 * 0.85D * 1.9D - world.field_1350 * 0.85D * 1.3D);
                class_243 drift = new class_243(fx, fy, fz).method_1021(0.9D).method_1019(normal.method_1021(0.65D));
                if (drift.method_1027() > 1.0E-6D) drift = drift.method_1029();
                ribbon.points.addLast(new EnergyPoint(world, now, ribbon.liveColor, drift, this.smoothPower));
                ribbon.prune(now, lifetime);
                while (ribbon.points.size() > SAMPLE_COUNT) ribbon.points.removeFirst();
            }
        }
    }

    private static final class EnergyRibbon {
        private final Deque<EnergyPoint> points = new ArrayDeque<>();
        private final float width;
        private final float brightness;
        private class_243 livePosition;
        private int liveColor;

        private EnergyRibbon(int index) {
            this.width = 0.15625F * (0.72F + hash01(index * 0x9E3779B9L, 2) * 0.56F);
            this.brightness = 0.72F + hash01(index * 0xC2B2AE35L, 5) * 0.56F;
        }

        private void prune(long now, long lifetime) {
            while (!this.points.isEmpty() && now - this.points.peekFirst().time > lifetime) {
                this.points.removeFirst();
            }
        }
    }

    private record SurfaceSample(class_243 offset, class_243 normal) {
    }

    private record EnergyPoint(class_243 pos, long time, int color, class_243 drift, float power) {
    }

    private static class TrailPoint {
        public final class_243 pos;
        public final int color;
        public final long time;

        public TrailPoint(class_243 pos, int color, long time) {
            this.pos = pos;
            this.color = color;
            this.time = time;
        }

        public boolean isExpired(long now, long trailLifetimeMs) {
            return (now - time) > trailLifetimeMs;
        }
    }
}
