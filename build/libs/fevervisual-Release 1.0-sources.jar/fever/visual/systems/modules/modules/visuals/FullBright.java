package fever.visual.systems.modules.modules.visuals;

import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

@ModuleInfo(name = "FullBright", category = ModuleCategory.VISUALS, desc = "modules.descriptions.fullbright")
public class FullBright extends BaseModule {
   private final ModeSetting mode = new ModeSetting(this, "modules.settings.fullbright.mode");
   private final ModeSetting.Value gamma = new ModeSetting.Value(this.mode, "modules.settings.fullbright.mode.gamma").select();
   private final ModeSetting.Value nightVision = new ModeSetting.Value(this.mode, "modules.settings.fullbright.mode.night_vision");
   private boolean appliedNightVision;

   @Override
   public void tick() {
      if (mc.field_1724 == null) {
         return;
      }

      if (this.isNightVisionMode() && !this.shouldKeepVisionEffect()) {
         mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
         this.appliedNightVision = true;
      } else if (this.appliedNightVision) {
         mc.field_1724.method_6016(class_1294.field_5925);
         this.appliedNightVision = false;
      }
   }

   @Override
   public void onDisable() {
      if (this.appliedNightVision && mc.field_1724 != null) {
         mc.field_1724.method_6016(class_1294.field_5925);
      }

      this.appliedNightVision = false;
   }

   public boolean isGammaMode() {
      return this.isEnabled() && this.gamma.isSelected() && !this.shouldKeepVisionEffect();
   }

   public boolean isNightVisionMode() {
      return this.isEnabled() && this.nightVision.isSelected();
   }

   private boolean shouldKeepVisionEffect() {
      return mc.field_1724 != null
              && (mc.field_1724.method_6059(class_1294.field_5919)
              || mc.field_1724.method_6059(class_1294.field_38092));
   }
}
