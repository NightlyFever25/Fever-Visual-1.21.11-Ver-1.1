//Да давай пасти бездарность :)
//Made by FeverVisuals (NightlyFever)
package fever.visual.systems.modules.modules.visuals;

import fever.visual.utility.render.compat.GlStateManager;
import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.render.RenderUtility;
import fever.visual.utility.render.Utils;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

@ModuleInfo(name = "Nimb", category = ModuleCategory.VISUALS, desc = "modules.descriptions.nimb")
public class Nimb extends BaseModule {


    private final SelectSetting targets = new SelectSetting(this, "modules.settings.model_changer.targets");
    private final SelectSetting.Value targetSelf = new SelectSetting.Value(targets, "modules.settings.chinahat.render_self").select();
    private final SelectSetting.Value targetFriends = new SelectSetting.Value(targets, "modules.settings.chinahat.render_others");

    private final SliderSetting speed3d = new SliderSetting(this, "modules.settings.nimb.speed_3d").min(1f).max(30f).step(1f).currentValue(3f);
    private final SliderSetting size3d = new SliderSetting(this, "modules.settings.nimb.size_3d").min(1f).max(7f).step(1f).currentValue(4f);
    private final SliderSetting distance3d = new SliderSetting(this, "modules.settings.nimb.distance_3d").min(5f).max(35f).step(1f).currentValue(15f);
    private final SliderSetting length3d = new SliderSetting(this, "modules.settings.nimb.length_3d").min(1f).max(50f).step(1f).currentValue(35f);
    private final SliderSetting length2_3d = new SliderSetting(this, "modules.settings.nimb.length2_3d").min(150f).max(255f).step(1f).currentValue(235f);
    private final SliderSetting alpha3d = new SliderSetting(this, "modules.settings.nimb.alpha_3d").min(1f).max(255f).step(1f).currentValue(255f);

    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.nimb.color_mode");
    private final ModeSetting.Value colorTheme = new ModeSetting.Value(colorMode, "modules.settings.nimb.color_mode.theme").select();
    private final ModeSetting.Value colorRainbow = new ModeSetting.Value(colorMode, "modules.settings.nimb.color_mode.rainbow", "", () -> true);
    private final ModeSetting.Value colorCustom = new ModeSetting.Value(colorMode, "modules.settings.nimb.color_mode.custom");
    private final ColorSetting customColorFirst = new ColorSetting(this, "modules.settings.nimb.custom_color", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(255, 100, 100, 255))
            .alpha(true);
    private final ColorSetting customColorSecond = new ColorSetting(this, "modules.settings.nimb.custom_color_second", () -> !this.colorCustom.isSelected())
            .color(new ColorRGBA(100, 160, 255, 255))
            .alpha(true);

    private final SliderSetting opacity = new SliderSetting(this, "modules.settings.nimb.opacity").min(0.1f).max(1.0f).step(0.05f).currentValue(0.7f);
    private final BooleanSetting firstPerson = new BooleanSetting(this, "modules.settings.nimb.first_person").enabled(false);
    private final SliderSetting height = new SliderSetting(this, "modules.settings.nimb.height").min(-0.5f).max(2.0f).step(0.05f).currentValue(0.4f);
    private final SliderSetting radius = new SliderSetting(this, "modules.settings.nimb.radius").min(0.1f).max(2.0f).step(0.05f).currentValue(0.5f);

    private final class_2960 fireflyTexture = FeverVisual.id("textures/particles/firefly.png");

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (!shouldRenderForPlayer(player)) continue;
            if (!shouldRenderForInvisible(player)) continue;
            if (player == mc.field_1724 && mc.field_1690.method_31044().method_31034() && !firstPerson.isEnabled()) continue;
            if (player != mc.field_1724) {
                class_4184 camera = mc.field_1773.method_19418();
                if (player.method_5707(camera.method_71156()) > 4096.0
                        || !Utils.isInViewHemisphere(camera, player.method_23317(), player.method_23318() + player.method_17682(), player.method_23321(), 3.0)) {
                    continue;
                }
            }

            class_243 playerPos = interpolatePlayerPosition(player, event.getTickDelta());
            float playerHeight = player.method_17682();
            double centerY = playerPos.field_1351 + playerHeight + height.getCurrentValue();
            class_243 center = new class_243(playerPos.field_1352, centerY, playerPos.field_1350);

            render3DEffect(player, event.getMatrices(), event.getTickDelta(), center);
        }
    };

    private boolean shouldRenderForPlayer(class_1657 player) {
        if (player == null || player.method_31481()) return false;
        if (player == mc.field_1724) {
            return targetSelf.isSelected();
        }
        boolean isFriend = FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString());
        return isFriend && targetFriends.isSelected();
    }

    private boolean shouldRenderForInvisible(class_1657 player) {
        if (player == mc.field_1724) return true;
        if (player.method_6059(class_1294.field_5905)) return false;
        return !player.method_5767() && !player.method_5756(mc.field_1724);
    }

    private int getColor(class_1657 player, int hue) {
        if (colorMode.is(colorCustom)) {
            return customColorFirst.getColor().mix(customColorSecond.getColor(), hue / 360.0F).getRGB();
        }

        return Colors.getAccentColor(hue).getRGB();
    }

    private void render3DEffect(class_1657 player, class_4587 matrices, float tickDelta, class_243 center) {
        class_4184 camera = mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();
        class_243 relativeCenter = center.method_1020(cameraPos);

        float speed = 31 - speed3d.getCurrentValue();
        float size = size3d.getCurrentValue() / 30f;
        double distance = distance3d.getCurrentValue();
        int length = (int) length3d.getCurrentValue();
        int maxAlpha = (int) alpha3d.getCurrentValue();
        int alphaFactor = 255 - (int) length2_3d.getCurrentValue();
        float actualRadius = radius.getCurrentValue();
        float actualOpacity = opacity.getCurrentValue();

        matrices.method_22903();
        RenderUtility.setupRender3D(true);
        RenderSystem.setShaderTexture(0, fireflyTexture);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);

        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
        long currentTime = System.currentTimeMillis();
        double angle = 0.15D * currentTime / speed;
        double angleStep = -0.15D * distance / speed;
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        double stepSin = Math.sin(angleStep);
        double stepCos = Math.cos(angleStep);
        Matrix4f baseMatrix = new Matrix4f(matrices.method_23760().method_23761());
        Matrix4f matrix = new Matrix4f();

        for (int i = 0; i < length; i++) {
            double s = cos * actualRadius;
            double c = sin * actualRadius;
            float alpha = class_3532.method_15340(maxAlpha - (i * alphaFactor), 0, maxAlpha) / 255f;
            alpha *= actualOpacity;
            int color = applyOpacity(getColor(player, i * 360 / length), alpha);

            matrix.set(baseMatrix)
                    .translate((float) (relativeCenter.field_1352 + s), (float) relativeCenter.field_1351, (float) (relativeCenter.field_1350 - c))
                    .rotate(camera.method_23767());
            drawParticle(buffer, matrix, size, color);

            color = applyOpacity(getColor(player, i * 360 / length + 180), alpha);
            matrix.set(baseMatrix)
                    .translate((float) (relativeCenter.field_1352 - s), (float) relativeCenter.field_1351, (float) (relativeCenter.field_1350 + c))
                    .rotate(camera.method_23767());
            drawParticle(buffer, matrix, size, color);

            double nextCos = cos * stepCos - sin * stepSin;
            sin = sin * stepCos + cos * stepSin;
            cos = nextCos;
        }

        RenderUtility.buildBuffer(buffer);
        RenderSystem.depthMask(true);
        RenderUtility.endRender3D();
        RenderSystem.disableDepthTest();
        RenderSystem.enableCull();
        matrices.method_22909();
    }

    private void drawParticle(class_287 buffer, Matrix4f matrix, float size, int color) {
        float r = ((color >> 16) & 0xFF) / 255.0F;
        float g = ((color >> 8) & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        float a = ((color >> 24) & 0xFF) / 255.0F;

        buffer.method_22918(matrix, -size, size, 0).method_22913(0f, 1f).method_22915(r, g, b, a);
        buffer.method_22918(matrix, size, size, 0).method_22913(1f, 1f).method_22915(r, g, b, a);
        buffer.method_22918(matrix, size, -size, 0).method_22913(1f, 0f).method_22915(r, g, b, a);
        buffer.method_22918(matrix, -size, -size, 0).method_22913(0f, 0f).method_22915(r, g, b, a);
    }

    private int applyOpacity(int color, float alpha) {
        int a = (int) (((color >> 24) & 0xFF) * alpha);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private class_243 interpolatePlayerPosition(class_1657 player, float tickDelta) {
        double x = player.field_6014 + (player.method_23317() - player.field_6014) * tickDelta;
        double y = player.field_6036 + (player.method_23318() - player.field_6036) * tickDelta;
        double z = player.field_5969 + (player.method_23321() - player.field_5969) * tickDelta;
        return new class_243(x, y, z);
    }
}
