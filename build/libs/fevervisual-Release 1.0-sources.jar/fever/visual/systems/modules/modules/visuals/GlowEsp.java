package fever.visual.systems.modules.modules.visuals;

import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SelectSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.render.pipeline.GlowEspCompositePipeline;
import fever.visual.utility.render.pipeline.KawaseBlurPipeline;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.game.EntityVisibility;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_5498;

@ModuleInfo(name = "Glow ESP", category = ModuleCategory.VISUALS, desc = "Entity glow")
public class GlowEsp extends BaseModule {
    private static GlowEsp instance;

    private final SelectSetting targets = new SelectSetting(this, "Targets").min(1);
    private final SelectSetting.Value players = new SelectSetting.Value(this.targets, "Players").select();
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targets, "Mobs").select();
    private final SelectSetting.Value self = new SelectSetting.Value(this.targets, "Self");
    private final SelectSetting.Value friends = new SelectSetting.Value(this.targets, "Friends").select();
    private final ModeSetting colorMode = new ModeSetting(this, "Color Mode");
    private final ModeSetting.Value theme = new ModeSetting.Value(this.colorMode, "Theme").select();
    private final ModeSetting.Value rainbow = new ModeSetting.Value(this.colorMode, "Rainbow");
    private final ModeSetting.Value custom = new ModeSetting.Value(this.colorMode, "Custom");
    private final ColorSetting firstColor = new ColorSetting(this, "Color 1", () -> !this.custom.isSelected())
            .color(new ColorRGBA(120, 170, 255, 255)).alpha(true);
    private final ColorSetting secondColor = new ColorSetting(this, "Color 2", () -> !this.custom.isSelected())
            .color(new ColorRGBA(255, 110, 205, 255)).alpha(true);
    private final SliderSetting glowStrength = new SliderSetting(this, "Glow Strength")
            .min(0.25F).max(2.5F).step(0.05F).currentValue(1.15F);
    private final ModeSetting renderMode = new ModeSetting(this, "Render Mode");
    private final ModeSetting.Value outer = new ModeSetting.Value(this.renderMode, "Outer").select();
    private final ModeSetting.Value inner = new ModeSetting.Value(this.renderMode, "Inner");
    private final ModeSetting.Value both = new ModeSetting.Value(this.renderMode, "Outer and Inner");
    private final SliderSetting blurPasses = new SliderSetting(this, "Iterations")
            .min(1.0F).max(5.0F).step(1.0F).currentValue(3.0F);
    private final SliderSetting divider = new SliderSetting(this, "Blur Divider")
            .min(1.0F).max(8.0F).step(0.1F).currentValue(8.0F);
    private final BooleanSetting chams = new BooleanSetting(this, "Chams");
    private final BooleanSetting outline = new BooleanSetting(this, "Outline").enable();

    private final Map<Integer, Boolean> previousGlow = new HashMap<>();
    private final Set<Integer> activeIds = new HashSet<>();
    private final KawaseBlurPipeline blur = new KawaseBlurPipeline();
    private final GlowEspCompositePipeline composite = new GlowEspCompositePipeline();

    public GlowEsp() {
        instance = this;
    }

    private final EventListener<Render3DEvent> onRender = event -> {
        this.renderGlowPost();
    };

    public static void prepareFrame(float tickDelta) {
        GlowEsp module = instance;
        if (module != null && module.isEnabled()) {
            module.updateGlowTargets(tickDelta);
        }
    }

    private void renderGlowPost() {
        if (this.activeIds.isEmpty() || mc.field_1769 == null || mc.method_1522() == null) return;
        net.minecraft.class_276 outline = mc.field_1769.method_22990();
        net.minecraft.class_276 main = mc.method_1522();
        if (outline == null || outline.method_30277() == null || outline.method_71639() == null
                || main.method_71639() == null) return;
        com.mojang.blaze3d.textures.GpuTextureView glow = this.blur.blur(
                outline.method_30277(), outline.method_71639(),
                outline.field_1482, outline.field_1481,
                Math.round(this.blurPasses.getCurrentValue()), 1.25F
        );
        this.composite.composite(
                main.method_71639(), outline.method_71639(), glow,
                this.glowStrength.getCurrentValue(), this.renderModeId(), this.divider.getCurrentValue(),
                this.chams.isEnabled(), this.outline.isEnabled()
        );
    }

    private int renderModeId() {
        if (this.inner.isSelected()) return 1;
        if (this.both.isSelected()) return 2;
        return 0;
    }

    private void updateGlowTargets(float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            this.restoreAll();
            return;
        }
        Set<Integer> next = new HashSet<>();
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living) || !this.shouldRender(living)
                    || !EntityVisibility.isRenderedAndVisible(living, tickDelta)) continue;
            next.add(entity.method_5628());
            this.previousGlow.putIfAbsent(entity.method_5628(), entity.method_5851());
            entity.method_5834(true);
        }
        for (Integer id : new HashSet<>(this.activeIds)) {
            if (!next.contains(id)) this.restore(id);
        }
        this.activeIds.clear();
        this.activeIds.addAll(next);
    }

    private boolean shouldRender(class_1309 entity) {
        if (!entity.method_5805() || entity.method_31481() || isInvisible(entity)) return false;
        if (entity == mc.field_1724) {
            return this.self.isSelected() && mc.field_1690.method_31044() != class_5498.field_26664;
        }
        if (entity instanceof class_1657 player) {
            boolean friend = FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString());
            return friend ? this.friends.isSelected() : this.players.isSelected();
        }
        return entity instanceof class_1308 && this.mobs.isSelected() && !entity.method_7325();
    }

    private static boolean isInvisible(class_1309 entity) {
        return entity.method_6059(class_1294.field_5905) || entity.method_5767()
                || mc.field_1724 != null && entity.method_5756(mc.field_1724);
    }

    private void restore(int id) {
        if (mc.field_1687 != null) {
            class_1297 entity = mc.field_1687.method_8469(id);
            if (entity != null) entity.method_5834(this.previousGlow.getOrDefault(id, false));
        }
        this.previousGlow.remove(id);
        this.activeIds.remove(id);
    }

    private void restoreAll() {
        for (Integer id : new HashSet<>(this.activeIds)) this.restore(id);
        this.previousGlow.clear();
        this.activeIds.clear();
    }

    @Override
    public void onDisable() {
        this.restoreAll();
    }

    public static Integer outlineColorFor(class_1297 entity) {
        GlowEsp module = instance;
        float tickDelta = mc.method_61966().method_60637(false);
        if (module == null || !module.isEnabled() || !(entity instanceof class_1309 living)
                || !module.shouldRender(living) || !EntityVisibility.isRenderedAndVisible(living, tickDelta)) {
            return null;
        }
        float phase = (System.currentTimeMillis() % 3500L) / 3500.0F * 360.0F
                + entity.method_5628() * 31.0F + (float)entity.method_23318() * 12.0F;
        ColorRGBA color;
        if (module.custom.isSelected()) {
            float mix = (float)(Math.sin(Math.toRadians(phase)) * 0.5D + 0.5D);
            color = module.firstColor.getColorSafe().mix(module.secondColor.getColorSafe(), mix);
        } else if (module.rainbow.isSelected()) {
            color = java.awt.Color.getHSBColor((phase % 360.0F) / 360.0F, 0.82F, 1.0F) == null
                    ? ColorRGBA.WHITE : ColorRGBA.fromInt(java.awt.Color.HSBtoRGB((phase % 360.0F) / 360.0F, 0.82F, 1.0F));
        } else {
            color = Colors.getAccentColor(phase);
        }
        if (entity instanceof class_1657 player
                && FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
            color = new ColorRGBA(70, 235, 120, 255);
        }
        if (living.field_6235 > 0) {
            color = color.mix(new ColorRGBA(255, 60, 60, 255), Math.min(1.0F, living.field_6235 / 10.0F));
        }
        return color.getRGB();
    }
}
