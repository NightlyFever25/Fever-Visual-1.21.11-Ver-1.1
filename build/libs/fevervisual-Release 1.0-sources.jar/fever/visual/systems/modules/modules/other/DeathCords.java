package fever.visual.systems.modules.modules.other;

import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.waypoints.WayPointsManager;
import fever.visual.utility.game.MessageUtility;
import net.minecraft.class_2561;
import net.minecraft.class_418;

@ModuleInfo(name = "Death Cords", category = ModuleCategory.MISC, desc = "modules.descriptions.death_cords")
public class DeathCords extends BaseModule {
   private boolean death;
   private final BooleanSetting wayDeath = new BooleanSetting(this, "modules.settings.death_cords.way_death");
   private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
      if (!(mc.field_1755 instanceof class_418) || mc.field_1724 == null) {
         this.death = true;
      } else if (this.death) {
         int xCord = (int)mc.field_1724.method_23317();
         int yCord = (int)mc.field_1724.method_23318();
         int zCord = (int)mc.field_1724.method_23321();
         MessageUtility.info(class_2561.method_30163("modules.death_cords.message " + xCord + " " + yCord + " " + zCord));
         if (this.wayDeath.isEnabled()) {
            WayPointsManager wayPointsManager = FeverVisual.getInstance().getWayPointsManager();
            if (wayPointsManager.contains("Death")) {
               wayPointsManager.del("Death");
            }

            wayPointsManager.add("Death", xCord, yCord, zCord);
         }

         this.death = false;
      }
   };
}