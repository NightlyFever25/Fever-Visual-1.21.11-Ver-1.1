package fever.visual.systems.modules.modules.visuals;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.modules.modules.visuals.littlePet.TaksaBrain;
import fever.visual.systems.modules.modules.visuals.littlePet.TaksaModel;
import fever.visual.utility.interfaces.IMinecraft;
import net.minecraft.class_12249;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;

@ModuleInfo(name = "Taksa", category = ModuleCategory.VISUALS, desc = "modules.descriptions.taksa")
public class Taksa extends BaseModule implements IMinecraft {

    private final TaksaBrain brain = new TaksaBrain();
    private final TaksaModel model = new TaksaModel();

    private final EventListener<AttackEvent> onAttack = event -> {
        if (event.getEntity() instanceof class_1309 living) {
            this.brain.setAttackTarget(living);
        }
    };

    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        this.brain.setEntity(mc.field_1724);
        this.brain.tick();
    };

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_243 petPos = this.brain.getPos();
        class_243 cam = event.getCamera().method_71156();
        class_4587 matrices = event.getMatrices();

        matrices.method_22903();
        matrices.method_22904(petPos.field_1352 - cam.field_1352, petPos.field_1351 - cam.field_1351, petPos.field_1350 - cam.field_1350);
        int light = class_765.method_23687(
                mc.field_1687.method_8314(net.minecraft.class_1944.field_9282, class_2338.method_49638(petPos)),
                mc.field_1687.method_8314(net.minecraft.class_1944.field_9284,   class_2338.method_49638(petPos))
        );
        int overlay = net.minecraft.class_4608.field_21444;
        class_1921 layer = class_12249.method_75994(TaksaModel.TEXTURE);
        class_4597.class_4598 immediate = mc.method_22940().method_23000();
        var vc = immediate.method_73477(layer);

        this.model.render(matrices, vc, light, overlay, this.brain,
                (float) mc.field_1724.field_6012 + event.getTickDelta());

        immediate.method_22994(layer);
        matrices.method_22909();
    };

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.field_1724 != null) this.brain.setEntity(mc.field_1724);
    }

    @Override
    public void onDisable() {
        this.brain.setEntity(null);
        this.brain.setAttackTarget(null);
        super.onDisable();
    }
}
