package fever.visual.systems.modules.modules.visuals;

import lombok.Generated;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import fever.visual.FeverVisual;
import fever.visual.framework.msdf.Fonts;
import fever.visual.framework.objects.BorderRadius;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.PreHudRenderEvent;
import fever.visual.systems.event.impl.window.KeyPressEvent;
import fever.visual.systems.localization.Localizator;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.game.MessageUtility;
import fever.visual.utility.render.Utils;
import fever.visual.utility.sounds.ClientSounds;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@ModuleInfo(name = "Waypoints", category = ModuleCategory.VISUALS, enabledByDefault = false)
public class Waypoints extends BaseModule {
   private final Map<String, Waypoint> waypoints = new HashMap<>();
   private final EventListener<KeyPressEvent> onClientPlayerTickEvent = event -> {
      if (event.getKey() == 86 && event.getAction() == 1 && mc.field_1755 == null && mc.field_1724 != null && mc.field_1687 != null) {
         class_243 start = mc.field_1724.method_33571();
         class_243 direction = mc.field_1724.method_5828(mc.method_61966().method_60637(true));
         class_243 end = start.method_1019(direction.method_1021(200.0));
         class_1657 targetPlayer = null;
         double closestDistance = Double.MAX_VALUE;

         for (class_1657 player : mc.field_1687.method_18456()) {
            if (player != mc.field_1724 && !this.isInvisible(player)) {
               class_238 hitbox = player.method_5829().method_1014(0.3);
               class_243 hit = (class_243)hitbox.method_992(start, end).orElse(null);
               if (hit != null) {
                  double distance = start.method_1022(hit);
                  if (distance < closestDistance && distance <= 200.0) {
                     closestDistance = distance;
                     targetPlayer = player;
                  }
               }
            }
         }

         if (targetPlayer != null) {
            UUID playerUUID = targetPlayer.method_5667();
            if (this.waypoints.values().stream().anyMatch(w -> playerUUID.equals(w.playerUUID))) {
               return;
            }

            String name = targetPlayer.method_5477().getString();
            class_243 pos = targetPlayer.method_73189();
            this.add(name, pos.field_1352, pos.field_1351, pos.field_1350, true, playerUUID);
            return;
         }

         class_239 raycastResult = mc.field_1724.method_5745(200.0, mc.method_61966().method_60637(true), false);
         if (raycastResult.method_17783() == class_240.field_1332 && raycastResult instanceof class_3965 blockHit) {
            class_243 pos = blockHit.method_17784();
            String baseName = Localizator.translate("modules.waypoints.base_name");
            String name = baseName;
            int counter = 1;

            while (this.waypoints.containsKey(name)) {
               name = baseName + " " + counter++;
            }

            this.add(name, pos.field_1352, pos.field_1351, pos.field_1350, true, null);
         }
      }
   };
   private final EventListener<PreHudRenderEvent> onHudRenderEvent = event -> {
      class_4587 matrices = event.getContext().getMatrices();
      float tickDelta = event.getTickDelta();
      long currentTime = System.currentTimeMillis();
      this.waypoints.entrySet().removeIf(entry -> {
         Waypoint waypointx = entry.getValue();
         if (waypointx.temp && currentTime - waypointx.creationTime > 5000L) {
            return true;
         } else {
            if (waypointx.playerUUID != null) {
               class_1657 player = mc.field_1687.method_18470(waypointx.playerUUID);
               if (player == null || this.isInvisible(player)) {
                  MessageUtility.info(class_2561.method_30163(Localizator.translate("modules.waypoints.player_removed", waypointx.name)));
                  return true;
               }

               class_243 targetPos = Utils.getInterpolatedPos(player, tickDelta);
               float alpha = 0.2F * tickDelta;
               waypointx.pos = waypointx.pos.method_35590(targetPos, class_3532.method_15363(alpha, 0.0F, 1.0F));
            }

            return false;
         }
      });

      for (Waypoint waypoint : this.waypoints.values()) {
         class_243 renderPos = waypoint.pos;
         class_243 renderPosAdjusted = renderPos.method_1031(0.0, 0.5, 0.0);
         class_241 screenPos = Utils.worldToScreen(renderPosAdjusted);
         if (screenPos != null) {
            float distance = (float)mc.field_1724.method_73189().method_1022(renderPos);
            float scale = class_3532.method_15363(1.0F - distance / 20.0F, 0.5F, 1.0F);
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0F);
            matrices.method_22905(scale, scale, 1.0F);
            String text = waypoint.name + " (" + String.format("%.1f", distance) + "m)";
            int width = (int)Fonts.MEDIUM.getFont(11.0F).width(text);
            int x = -width / 2;
            int iconSize = 32;
            event.getContext()
                    .drawRoundedRect(
                            (float)(x - 3),
                            2.0F,
                            (float)(width + 8),
                            Fonts.MEDIUM.getFont(11.0F).height() + 6.0F,
                            BorderRadius.all(3.0F),
                            new ColorRGBA(0.0F, 0.0F, 0.0F, 100.0F)
                    );
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0F), text, x, 5.0F, ColorRGBA.WHITE);
            if (waypoint.playerUUID != null) {
               int iconY = (int)(-22.0F + (Fonts.MEDIUM.getFont(11.0F).height() - iconSize) / 2.0F);
               event.getContext().drawTexture(FeverVisual.id("icons/target2.png"), -15.0F, iconY, iconSize, iconSize, ColorRGBA.WHITE);
            }

            matrices.method_22909();
         }
      }
   };

   private void add(String name, double x, double y, double z, boolean isTemp, UUID playerUUID) {
      class_243 pos = new class_243(x, y, z);
      if (this.waypoints.containsKey(name)) {
         MessageUtility.error(class_2561.method_30163(Localizator.translate("modules.waypoints.exists", name)));
      } else {
         this.waypoints.put(name, new Waypoint(name, pos, isTemp, System.currentTimeMillis(), playerUUID));
         ClientSounds.MODULE.play(0.5F);
      }
   }

   private boolean isInvisible(class_1657 player) {
      if (player.method_6059(class_1294.field_5905)) return true;
      if (player.method_5767()) return true;
      if (mc.field_1724 != null && player.method_5756(mc.field_1724)) return true;
      return false;
   }

   private static class Waypoint {
      public String name;
      public class_243 pos;
      public boolean temp;
      public long creationTime;
      public UUID playerUUID;

      @Generated
      public Waypoint(String name, class_243 pos, boolean temp, long creationTime, UUID playerUUID) {
         this.name = name;
         this.pos = pos;
         this.temp = temp;
         this.creationTime = creationTime;
         this.playerUUID = playerUUID;
      }
   }
}
