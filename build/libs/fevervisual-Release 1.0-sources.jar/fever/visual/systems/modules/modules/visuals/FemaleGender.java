package fever.visual.systems.modules.modules.visuals;

import fever.visual.FeverVisual;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.SliderSetting;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@ModuleInfo(name = "Female Gender", category = ModuleCategory.VISUALS, desc = "modules.descriptions.female_gender")
public class FemaleGender extends BaseModule {
   private static FemaleGender INSTANCE;

   public final SliderSetting selfSize = new SliderSetting(this, "female_gender.self_size")
      .min(0.0F)
      .max(1.6F)
      .step(0.05F)
      .currentValue(1.0F);

   public final SliderSetting friendsSize = new SliderSetting(this, "female_gender.friends_size")
      .min(0.0F)
      .max(1.6F)
      .step(0.05F)
      .currentValue(1.0F);

   public final SliderSetting othersSize = new SliderSetting(this, "female_gender.others_size")
      .min(0.0F)
      .max(1.6F)
      .step(0.05F)
      .currentValue(0.85F);

   public FemaleGender() {
      INSTANCE = this;
   }

   public static FemaleGender getInstance() {
      return INSTANCE;
   }

   public float getSizeFor(class_1657 player) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null && player == client.field_1724) {
         return Math.clamp(this.selfSize.getCurrentValue(), 0.0F, 1.6F);
      }

      if (isInvisible(player, client.field_1724)) {
         return 0.0F;
      }

      if (FeverVisual.getInstance().getFriendManager() != null && FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
         return Math.clamp(this.friendsSize.getCurrentValue(), 0.0F, 1.6F);
      }

      return Math.clamp(this.othersSize.getCurrentValue(), 0.0F, 1.6F);
   }

   private boolean isInvisible(class_1657 player, class_1657 viewer) {
      if (player.method_6059(class_1294.field_5905)) return true;
      if (player.method_5767()) return true;
      if (viewer != null && player.method_5756(viewer)) return true;
      return false;
   }
}
