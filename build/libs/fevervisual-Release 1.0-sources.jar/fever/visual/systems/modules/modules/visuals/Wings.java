package fever.visual.systems.modules.modules.visuals;

import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import fever.visual.FeverVisual;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.Render3DEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.setting.settings.BooleanSetting;
import fever.visual.systems.setting.settings.ColorSetting;
import fever.visual.systems.setting.settings.ModeSetting;
import fever.visual.systems.setting.settings.SliderSetting;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.colors.Colors;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.compat.BufferRenderer;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import fever.visual.utility.render.TestikRender3D;
import fever.visual.utility.render.Utils;
import org.joml.Matrix4f;

@ModuleInfo(name = "Wings", category = ModuleCategory.VISUALS, desc = "modules.descriptions.wings")
public class Wings extends BaseModule implements IMinecraft {
   private static final float DEFAULT_SPREAD = 8.0F;
   private static final int[] RIB_INDICES = new int[] {2, 4, 7, 9, 11};
   private static final WingPoint[] SHAPE = new WingPoint[] {
           new WingPoint(0.08F, 0.10F, 0.88F),
           new WingPoint(0.28F, 0.34F, 0.78F),
           new WingPoint(0.56F, 0.82F, 0.62F),
           new WingPoint(0.86F, 0.30F, 0.52F),
           new WingPoint(1.14F, 0.46F, 0.40F),
           new WingPoint(1.24F, 0.04F, 0.30F),
           new WingPoint(1.02F, -0.18F, 0.28F),
           new WingPoint(1.18F, -0.64F, 0.22F),
           new WingPoint(0.86F, -0.46F, 0.20F),
           new WingPoint(0.80F, -0.98F, 0.14F),
           new WingPoint(0.54F, -0.74F, 0.16F),
           new WingPoint(0.30F, -1.16F, 0.12F),
           new WingPoint(0.10F, -0.54F, 0.18F)
   };

   private final BooleanSetting self = new BooleanSetting(this, "modules.settings.wings.self", "modules.settings.wings.self.description").enabled(true);
   private final BooleanSetting friends = new BooleanSetting(this, "modules.settings.wings.friends", "modules.settings.wings.friends.description").enabled(false);
   private final SliderSetting size = new SliderSetting(this, "modules.settings.wings.size", "modules.settings.wings.size.description")
           .min(0.65F).max(1.35F).step(0.05F).currentValue(1.0F);
   private final SliderSetting transparency = new SliderSetting(this, "modules.settings.wings.alpha", "modules.settings.wings.alpha.description")
           .min(0.25F).max(1.0F).step(0.05F).currentValue(0.86F);
   private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.wings.color_mode");
   private final ModeSetting.Value colorTheme = new ModeSetting.Value(this.colorMode, "modules.settings.wings.color_mode.theme").select();
   private final ModeSetting.Value colorCustom = new ModeSetting.Value(this.colorMode, "modules.settings.wings.color_mode.custom");
   private final ColorSetting colorFirst = new ColorSetting(this, "modules.settings.wings.color", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(160, 115, 255, 255));
   private final ColorSetting colorSecond = new ColorSetting(this, "modules.settings.wings.color_second", () -> !this.colorCustom.isSelected())
           .color(new ColorRGBA(100, 160, 255, 255));

   private float selfBodyYaw;
   private boolean selfBodyYawInitialized;

   private final EventListener<Render3DEvent> onRender3D = new EventListener<>() {
      @Override
      public void onEvent(Render3DEvent event) {
         if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
         }

         class_4587 matrices = event.getMatrices();
         class_243 cameraPos = event.getCamera().method_71156();
         float tickDelta = event.getTickDelta();
         TestikRender3D.setup(false);
         try {
            if (self.isEnabled()
                    && !mc.field_1690.method_31044().method_31034()
                    && mc.field_1724.method_5805()
                    && !hasElytra(mc.field_1724)) {
               renderWings(matrices, mc.field_1724, tickDelta, cameraPos);
            }

            if (friends.isEnabled()) {
               for (class_1657 player : mc.field_1687.method_18456()) {
                  if (player != mc.field_1724 && player.method_5805() && isVisibleFriend(player) && !hasElytra(player)) {
                     class_243 pos = player.method_30950(tickDelta);
                     if (pos.method_1025(cameraPos) <= 4096.0
                             && Utils.isInViewHemisphere(event.getCamera(), pos.field_1352, pos.field_1351 + 1.0, pos.field_1350, 3.0)) {
                        renderWings(matrices, player, tickDelta, cameraPos);
                     }
                  }
               }
            }
         } finally {
            TestikRender3D.reset();
         }
      }

      @Override
      public int getPriority() {
         return -100;
      }
   };

   @Override
   public void onDisable() {
      this.selfBodyYawInitialized = false;
   }

   private void renderWings(class_4587 matrices, class_1657 player, float tickDelta, class_243 cameraPos) {
      WingPose pose = resolvePose(player, tickDelta);
      if (pose == null) {
         return;
      }

      class_243 origin = player.method_30950(tickDelta).method_1020(cameraPos);
      float bodyYaw = resolveBodyYaw(player, tickDelta);
      float move = class_3532.method_15363(player.field_42108.method_48570(tickDelta), 0.0F, 1.0F);
      float flap = class_3532.method_15374((player.field_6012 + tickDelta) * pose.flapSpeed) * pose.flapAmplitude;
      float open = (DEFAULT_SPREAD + flap + move * pose.motionSpreadBoost) * pose.openMultiplier;
      float wingScale = this.size.getCurrentValue() * pose.scaleMultiplier * (player.method_6109() ? 0.55F : 1.0F);

      ColorRGBA base = this.getWingColor(0);
      ColorRGBA edge = this.getWingColor(20);
      ColorRGBA glow = edge.mix(ColorRGBA.WHITE, 0.28F);
      ColorRGBA core = base.mix(edge, 0.5F).mix(ColorRGBA.WHITE, 0.45F);
      Matrix4f matrix = matrices.method_23760().method_23761();
      class_287 triangles = class_289.method_1348().method_60827(class_5596.field_27379, class_290.field_1576);
      renderWingLayers(triangles, matrix, origin, bodyYaw, -1.0F, open, wingScale, pose, glow, core, base);
      renderWingLayers(triangles, matrix, origin, bodyYaw, 1.0F, open, wingScale, pose, glow, core, base);
      BufferRenderer.drawWithGlobalProgram(triangles.method_60800());

      class_287 lines = class_289.method_1348().method_60827(class_5596.field_27377, class_290.field_1576);
      renderWingLines(lines, matrix, origin, bodyYaw, -1.0F, open, wingScale, pose, glow, base);
      renderWingLines(lines, matrix, origin, bodyYaw, 1.0F, open, wingScale, pose, glow, base);
      BufferRenderer.drawWithGlobalProgram(lines.method_60800());
   }

   private ColorRGBA getWingColor(float index) {
      if (this.colorCustom.isSelected()) {
         return this.colorFirst.getColorSafe().mix(this.colorSecond.getColorSafe(), (index % 40.0F) / 39.0F);
      }

      return Colors.getAccentColor(index * 6.0F);
   }

   private void renderWingLayers(class_287 buffer, Matrix4f matrix, class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, ColorRGBA glow, ColorRGBA core, ColorRGBA base) {
      drawWingLayer(buffer, matrix, origin, bodyYaw, side, open, wingScale, pose, 1.22F, withAlpha(glow, 0.24F), withAlpha(glow, 0.08F));
      drawWingLayer(buffer, matrix, origin, bodyYaw, side, open, wingScale, pose, 0.84F, withAlpha(core, 0.28F), withAlpha(core, 0.10F));
      drawWingLayer(buffer, matrix, origin, bodyYaw, side, open, wingScale, pose, 1.0F, withAlpha(base, 0.76F), withAlpha(base, 0.16F));
   }

   private void renderWingLines(class_287 buffer, Matrix4f matrix, class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, ColorRGBA glow, ColorRGBA base) {
      drawWingOutline(buffer, matrix, origin, bodyYaw, side, open, wingScale, pose, withAlpha(base, 0.72F));
      drawWingRibs(buffer, matrix, origin, bodyYaw, side, open, wingScale, pose, withAlpha(glow, 0.42F));
   }

   private void drawWingLayer(class_287 buffer, Matrix4f matrix, class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, float layerScale, ColorRGBA rootColor, ColorRGBA edgeColor) {
      class_243 root = wingPoint(origin, bodyYaw, side, open, wingScale, pose, 0.0F, 0.0F, layerScale, 0.0F);

      for (int i = 0; i < SHAPE.length; i++) {
         WingPoint current = SHAPE[i];
         WingPoint next = SHAPE[(i + 1) % SHAPE.length];
         class_243 currentPoint = wingPoint(origin, bodyYaw, side, open, wingScale, pose, current.x, current.y, layerScale, 0.012F * (1.22F - layerScale));
         class_243 nextPoint = wingPoint(origin, bodyYaw, side, open, wingScale, pose, next.x, next.y, layerScale, 0.012F * (1.22F - layerScale));
         ColorRGBA currentColor = applyPointAlpha(edgeColor, current.alphaMul);
         ColorRGBA nextColor = applyPointAlpha(edgeColor, next.alphaMul);
         if (side > 0.0F) {
            TestikRender3D.drawTriangle(buffer, matrix, root, nextPoint, currentPoint, rootColor, nextColor, currentColor);
         } else {
            TestikRender3D.drawTriangle(buffer, matrix, root, currentPoint, nextPoint, rootColor, currentColor, nextColor);
         }
      }

   }

   private void drawWingOutline(class_287 buffer, Matrix4f matrix, class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, ColorRGBA outlineColor) {
      class_243 previous = wingPoint(origin, bodyYaw, side, open, wingScale, pose, SHAPE[SHAPE.length - 1].x, SHAPE[SHAPE.length - 1].y, 1.0F, 0.018F);
      for (WingPoint point : SHAPE) {
         class_243 current = wingPoint(origin, bodyYaw, side, open, wingScale, pose, point.x, point.y, 1.0F, 0.018F);
         TestikRender3D.drawGradientLine(buffer, matrix, previous, current, outlineColor, applyPointAlpha(outlineColor, point.alphaMul));
         previous = current;
      }
   }

   private void drawWingRibs(class_287 buffer, Matrix4f matrix, class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, ColorRGBA ribColor) {
      class_243 root = wingPoint(origin, bodyYaw, side, open, wingScale, pose, 0.0F, 0.0F, 0.96F, 0.02F);
      for (int index : RIB_INDICES) {
         WingPoint point = SHAPE[index];
         class_243 end = wingPoint(origin, bodyYaw, side, open, wingScale, pose, point.x, point.y, 0.96F, 0.02F);
         TestikRender3D.drawGradientLine(buffer, matrix, root, end, withAlpha(ribColor, 0.18F), applyPointAlpha(ribColor, point.alphaMul));
      }
   }

   private class_243 wingPoint(class_243 origin, float bodyYaw, float side, float open, float wingScale, WingPose pose, float x, float y, float layerScale, float layerBackOffset) {
      float roll = (float)Math.toRadians(side * pose.sideRoll);
      float pitch = (float)Math.toRadians(pose.sidePitch);
      float openRad = (float)Math.toRadians(open);
      float scaledX = x * layerScale;
      float scaledY = y * layerScale;
      float rolledX = scaledX * class_3532.method_15362(roll) - scaledY * class_3532.method_15374(roll) * 0.22F;
      float rolledY = scaledX * class_3532.method_15374(roll) * 0.34F + scaledY * class_3532.method_15362(roll);
      float localSide = side * (pose.sideOffset + rolledX * class_3532.method_15362(openRad));
      float localUp = pose.anchorY + pose.sideYOffset + rolledY * class_3532.method_15362(pitch);
      float localBack = pose.anchorBack + pose.sideBackOffset
              + Math.abs(rolledX) * class_3532.method_15374(openRad) * 0.35F
              - rolledY * class_3532.method_15374(pitch) * 0.12F
              + layerBackOffset;
      float posePitch = (float)Math.toRadians(pose.pitchRotation);
      float poseRoll = (float)Math.toRadians(pose.rollRotation);
      float pitchedUp = localUp * class_3532.method_15362(posePitch) - localBack * class_3532.method_15374(posePitch);
      float pitchedBack = localUp * class_3532.method_15374(posePitch) + localBack * class_3532.method_15362(posePitch);
      float rolledSide = localSide * class_3532.method_15362(poseRoll) - pitchedUp * class_3532.method_15374(poseRoll);
      float rolledUp = localSide * class_3532.method_15374(poseRoll) + pitchedUp * class_3532.method_15362(poseRoll);
      return transformLocal(origin, bodyYaw, rolledSide * wingScale, (pose.preTranslateY + rolledUp) * wingScale, (pose.preTranslateBack + pitchedBack) * wingScale);
   }

   private class_243 transformLocal(class_243 origin, float bodyYaw, float side, float up, float back) {
      float yawRad = (float)Math.toRadians(-bodyYaw + 90.0F);
      double rightX = Math.sin(yawRad);
      double rightZ = Math.cos(yawRad);
      double forwardX = Math.sin(yawRad + Math.PI / 2.0D);
      double forwardZ = Math.cos(yawRad + Math.PI / 2.0D);
      return origin.method_1031(rightX * side + forwardX * back, up, rightZ * side + forwardZ * back);
   }

   private boolean hasElytra(class_1657 player) {
      return player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
   }

   private boolean isVisibleFriend(class_1657 player) {
      return FeverVisual.getInstance().getFriendManager().isFriend(player.method_5477().getString())
              && !player.method_6059(class_1294.field_5905)
              && !player.method_5767()
              && (mc.field_1724 == null || !player.method_5756(mc.field_1724));
   }

   private WingPose resolvePose(class_1657 player, float tickDelta) {
      float pitch = player.method_5695(tickDelta);
      if (player.method_6128()) {
         float flightProgress = class_3532.method_15363((player.field_6012 + tickDelta) / 10.0F, 0.0F, 1.0F);
         float pitchRotation = flightProgress * (-90.0F - pitch);
         return new WingPose(0.34F, 0.46F, 0.0F, 0.0F, pitchRotation, 0.0F, 0.76F, 0.92F, 0.10F, 0.58F, 0.05F, 0.06F, -0.05F, -5.0F, -2.0F, 0.13F);
      }
      if (player.method_5715()) {
         return new WingPose(0.0F, 0.0F, 0.96F, 0.10F, 18.0F, 0.0F, 1.0F, 1.0F, 0.18F, 4.5F, 0.06F, 0.0F, 0.02F, -11.0F, -4.0F, 0.12F);
      }
      return new WingPose(0.0F, 0.0F, 1.38F, 0.10F, 0.0F, 0.0F, 1.0F, 1.0F, 0.18F, 4.5F, 0.06F, 0.0F, 0.02F, -11.0F, -4.0F, 0.12F);
   }

   private float resolveBodyYaw(class_1657 player, float tickDelta) {
      float target = class_3532.method_17821(tickDelta, player.field_6220, player.field_6283);
      if (player != mc.field_1724) {
         return target;
      }

      if (!this.selfBodyYawInitialized || player.field_6012 < 2) {
         this.selfBodyYaw = target;
         this.selfBodyYawInitialized = true;
         return this.selfBodyYaw;
      }

      this.selfBodyYaw = approachDegrees(this.selfBodyYaw, target, 14.0F);
      return this.selfBodyYaw;
   }

   private float approachDegrees(float current, float target, float maxDelta) {
      float delta = class_3532.method_15393(target - current);
      delta = class_3532.method_15363(delta, -maxDelta, maxDelta);
      return current + delta;
   }

   private ColorRGBA applyPointAlpha(ColorRGBA color, float multiplier) {
      return color.withAlpha(color.getAlpha() * class_3532.method_15363(multiplier, 0.28F, 1.0F));
   }

   private ColorRGBA withAlpha(ColorRGBA color, float multiplier) {
      return color.withAlpha(class_3532.method_15363(multiplier * this.transparency.getCurrentValue(), 0.0F, 1.0F) * 255.0F);
   }

   private record WingPoint(float x, float y, float alphaMul) {
   }

   private record WingPose(
           float preTranslateY,
           float preTranslateBack,
           float anchorY,
           float anchorBack,
           float pitchRotation,
           float rollRotation,
           float openMultiplier,
           float scaleMultiplier,
           float motionSpreadBoost,
           float flapAmplitude,
           float sideOffset,
           float sideYOffset,
           float sideBackOffset,
           float sideRoll,
           float sidePitch,
           float flapSpeed
   ) {
   }
}
