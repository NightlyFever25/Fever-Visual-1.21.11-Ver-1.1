package fever.visual.systems.modules.modules.visuals.littlePet;

import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.client.model.*;

public class TaksaModel {

    public static final class_2960 TEXTURE = class_2960.method_60655("fevervisual", "textures/taksa.png");

    private final class_630 head;
    private final class_630 neck;
    private final class_630 body;
    private final class_630 chest;
    private final class_630 back;
    private final class_630 frontLeftLeg;
    private final class_630 frontRightLeg;
    private final class_630 leftBackLeg;
    private final class_630 rightBackLeg;
    private final class_630 tail;
    private final class_630 leftEar;
    private final class_630 rightEar;

    public TaksaModel() {
        class_5609 modelData = getModelData();
        class_630 root = class_5607.method_32110(modelData, 60, 36).method_32109();

        this.head = root.method_32086("head");
        this.neck = root.method_32086("neck");
        this.body = root.method_32086("body");
        this.chest = this.body.method_32086("chest");
        this.back  = this.body.method_32086("back");
        this.frontLeftLeg  = root.method_32086("frontLeftLeg");
        this.frontRightLeg = root.method_32086("frontRightLeg");
        this.leftBackLeg   = root.method_32086("leftBackLeg");
        this.rightBackLeg  = root.method_32086("rightBackLeg");
        this.tail     = root.method_32086("tail");
        this.leftEar  = this.head.method_32086("leftEar");
        this.rightEar = this.head.method_32086("rightEar");
    }

    public static class_5609 getModelData() {
        class_5609 data = new class_5609();
        class_5610 root = data.method_32111();
        class_5610 headData = root.method_32117("head",
                class_5606.method_32108()
                        .method_32101(0, 0).method_32097(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F)
                        .method_32101(21, 0).method_32097(-1.5F, 0.0F, -7.0F, 3.0F, 3.0F, 3.0F),
                class_5603.method_32090(0.0F, 10.5F, -6.8F));

        headData.method_32117("leftEar",
                class_5606.method_32108()
                        .method_32101(32, 4).method_32097(0.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F)
                        .method_32101(34, 1).method_32097(0.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.0F),
                class_5603.method_32090(3.0F, 3.0F, -2.0F));

        headData.method_32117("rightEar",
                class_5606.method_32108()
                        .method_32101(32, 4).method_32097(-1.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F)
                        .method_32101(34, 1).method_32097(-1.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.0F),
                class_5603.method_32090(-3.0F, 3.0F, -2.0F));

        root.method_32117("neck",
                class_5606.method_32108()
                        .method_32101(15, 7).method_32097(-2.95F, -1.0F, -4.0F, 5.9F, 5.0F, 6.0F),
                class_5603.method_32091(0.0F, 10.5F, -5.0F, -0.43633232F, 0.0F, 0.0F));

        class_5610 bodyData = root.method_32117("body",
                class_5606.method_32108(),
                class_5603.method_32090(0.0F, 13.5F, -5.0F));

        bodyData.method_32117("chest",
                class_5606.method_32108()
                        .method_32101(32, 13).method_32097(-4.0F, -3.5F, -3.0F, 8.0F, 7.0F, 6.0F),
                class_5603.method_32090(0.0F, 0.0F, 3.0F));

        bodyData.method_32117("back",
                class_5606.method_32108()
                        .method_32101(3, 19).method_32097(-3.0F, -3.0F, -0.5F, 6.0F, 6.0F, 11.0F),
                class_5603.method_32090(0.0F, -0.5F, 5.5F));

        root.method_32117("frontLeftLeg",
                class_5606.method_32108()
                        .method_32101(42, 0).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                class_5603.method_32090(1.5F, 16.0F, -3.0F));

        root.method_32117("frontRightLeg",
                class_5606.method_32108()
                        .method_32101(42, 0).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                class_5603.method_32090(-1.5F, 16.0F, -3.0F));

        root.method_32117("leftBackLeg",
                class_5606.method_32108()
                        .method_32101(52, 0).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                class_5603.method_32090(1.5F, 16.0F, 9.0F));

        root.method_32117("rightBackLeg",
                class_5606.method_32108()
                        .method_32101(52, 0).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                class_5603.method_32090(-1.5F, 16.0F, 9.0F));

        root.method_32117("tail",
                class_5606.method_32108()
                        .method_32101(2, 12).method_32097(-1.0F, 2.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                class_5603.method_32091(0.0F, 9.0F, 10.0F, 0.3926991F, 0.0F, 0.0F));

        return data;
    }

    public void setAngles(float ageInTicks, TaksaBrain brain) {
        this.head.field_3675   = brain.getYaw()   * ((float) Math.PI / 180);
        this.head.field_3654 = brain.getPitch() * ((float) Math.PI / 180);

        float swing    = brain.limbSwing;
        float swingAmt = brain.limbSwingAmount;

        this.frontLeftLeg.field_3654  = class_3532.method_15362(swing * 0.6662F) * 1.4F * swingAmt;
        this.frontRightLeg.field_3654 = class_3532.method_15362((float)(swing * 0.6662F + Math.PI)) * 1.4F * swingAmt;
        this.leftBackLeg.field_3654   = class_3532.method_15362((float)(swing * 0.6662F + Math.PI)) * 1.4F * swingAmt;
        this.rightBackLeg.field_3654  = class_3532.method_15362(swing * 0.6662F) * 1.4F * swingAmt;

        if (brain.isLay()) {
            this.frontLeftLeg.field_3654  = (float) Math.toRadians(-90.0);
            this.frontRightLeg.field_3654 = (float) Math.toRadians(-90.0);
            this.leftBackLeg.field_3654   = (float) Math.toRadians(90.0);
            this.rightBackLeg.field_3654  = (float) Math.toRadians(90.0);
            this.frontLeftLeg.field_3675    = (float) Math.toRadians(-22.0);
            this.frontRightLeg.field_3675   = (float) Math.toRadians(22.0);
            this.leftBackLeg.field_3675     = (float) Math.toRadians(22.0);
            this.rightBackLeg.field_3675    = (float) Math.toRadians(-22.0);
        } else {
            this.frontLeftLeg.field_3675  = 0.0F;
            this.frontRightLeg.field_3675 = 0.0F;
            this.leftBackLeg.field_3675   = 0.0F;
            this.rightBackLeg.field_3675  = 0.0F;
        }

        this.tail.field_3654 = (float) Math.toRadians(brain.isLay() ? 45.0 : 22.0);
        this.tail.field_3674  = (float) (Math.toRadians(-22.5) + 0.39269908169872414 + Math.cos(ageInTicks * 0.15F) * 0.3);

        if (brain.isLay()) {
            this.leftEar.field_3654  = (float) Math.toRadians(-30.0);
            this.rightEar.field_3654 = (float) Math.toRadians(-30.0);
        } else {
            this.leftEar.field_3654  = 0.0F;
            this.rightEar.field_3654 = 0.0F;
        }
    }

    public void render(class_4587 matrices, class_4588 vertexConsumer, int light, int overlay, TaksaBrain brain, float ageInTicks) {
        matrices.method_22903();
        matrices.method_46416(0.0F, 1.2F - (brain.isLay() ? 0.3F : 0.0F), 0.0F);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(180.0F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(brain.getBody()));

        this.setAngles(ageInTicks, brain);

        this.head.method_22698(matrices, vertexConsumer, light, overlay);
        this.neck.method_22698(matrices, vertexConsumer, light, overlay);
        this.body.method_22698(matrices, vertexConsumer, light, overlay);
        this.frontLeftLeg.method_22698(matrices, vertexConsumer, light, overlay);
        this.frontRightLeg.method_22698(matrices, vertexConsumer, light, overlay);
        this.leftBackLeg.method_22698(matrices, vertexConsumer, light, overlay);
        this.rightBackLeg.method_22698(matrices, vertexConsumer, light, overlay);
        this.tail.method_22698(matrices, vertexConsumer, light, overlay);

        matrices.method_22909();
    }
}
