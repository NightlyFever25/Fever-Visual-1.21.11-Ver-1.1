package fever.visual.systems.modules.modules.visuals;

import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import fever.visual.systems.modules.modules.visuals.littlePet.GhostWolfEntity;
import fever.visual.systems.setting.settings.BooleanSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1321;
import net.minecraft.class_1493;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

@ModuleInfo(name = "Little Pet", category = ModuleCategory.VISUALS, desc = "Пёс за вами")
@Environment(EnvType.CLIENT)
public class LittleSnickers extends BaseModule {

    private class_1309 fakeEntity = null;
    private boolean active = false;
    private class_1937 lastWorld = null;

    private final BooleanSetting bumbum = new BooleanSetting(this, "modules.settings.bumbum", "Бегать за таргетом").enabled(false);

    private int ticksAway = 0;
    private int stuckTicks = 0;

    private class_1309 currentTarget = null;

    private final EventListener<AttackEvent> onAttack = event -> {
        if (!bumbum.isEnabled()) return;

        class_1297 attacked = event.getEntity();
        if (attacked instanceof class_1309 living &&
                living != mc.field_1724 &&
                !this.isInvisible(living)) {
            currentTarget = living;
        }
    };


    private class_1309 createEntity() {
        var entity = new GhostWolfEntity(class_1299.field_6055, mc.field_1687);
        if (entity == null) return null;

        entity.method_5808(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_36454(), mc.field_1724.method_36455());
        entity.method_5648(false);
        entity.method_5880(false);
        entity.method_6033(20.0F);

        if (entity instanceof class_1321 tameable) {
            tameable.method_6173(true, false);
            tameable.method_6174(mc.field_1724);
        }

        return entity;
    }

    private boolean isSolid(class_2338 pos) {
        if (mc.field_1687 == null) return false;
        class_2680 blockState = mc.field_1687.method_8320(pos);
        return !blockState.method_26215() && !blockState.method_26220(mc.field_1687, pos).method_1110();
    }

    private void moveEntityTowardsTarget(class_243 targetPos) {
        if (fakeEntity == null) return;

        class_243 entityPos = fakeEntity.method_73189();
        double dx = targetPos.field_1352 - entityPos.field_1352;
        double dz = targetPos.field_1350 - entityPos.field_1350;
        double distanceXZ = Math.sqrt(dx * dx + dz * dz);
        double dy = targetPos.field_1351 - entityPos.field_1351;

        boolean isMoving = false;
        boolean isJumping = false;

        class_2338 entityBlockPos = new class_2338(
                (int) Math.floor(entityPos.field_1352),
                (int) Math.floor(entityPos.field_1351 - 0.1),
                (int) Math.floor(entityPos.field_1350)
        );
        boolean onGround = isSolid(entityBlockPos);

        if (Math.abs(dy) >= 12 || distanceXZ > 20) {
            fakeEntity.method_5808(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350, fakeEntity.method_36454(), fakeEntity.method_36455());
            fakeEntity.method_18799(class_243.field_1353);
            stuckTicks = 0;
            return;
        }

        if (distanceXZ > 1.2) {
            double speed = 0.21;
            double normX = dx / distanceXZ;
            double normZ = dz / distanceXZ;

            class_2338 frontPos = new class_2338(
                    (int) Math.floor(entityPos.field_1352 + normX * 0.6),
                    (int) Math.floor(entityPos.field_1351),
                    (int) Math.floor(entityPos.field_1350 + normZ * 0.6)
            );
            class_2338 aboveFrontPos = frontPos.method_10084();
            class_2338 blockBelowFront = frontPos.method_10074();
            class_2338 blockBelow = entityBlockPos.method_10074();

            boolean frontSolid = isSolid(frontPos);
            boolean aboveClear = !isSolid(aboveFrontPos);
            boolean belowSolid = isSolid(blockBelow);
            boolean belowFrontSolid = isSolid(blockBelowFront);

            if (frontSolid && aboveClear && onGround) {
                int blockHeight = frontPos.method_10264() - entityBlockPos.method_10264();
                if (blockHeight <= 1) {
                    class_243 vel = fakeEntity.method_18798();
                    fakeEntity.method_18800(vel.field_1352, 0.5, vel.field_1350);
                    isJumping = true;
                    onGround = false;
                } else {
                    stuckTicks++;
                    return;
                }
            }

            if (!frontSolid && !belowFrontSolid) {
                boolean foundGround = false;
                for (int drop = 1; drop <= 3; drop++) {
                    class_2338 check = frontPos.method_10087(drop);
                    if (isSolid(check)) {
                        class_243 vel = fakeEntity.method_18798();
                        fakeEntity.method_18800(vel.field_1352, -0.1, vel.field_1350);
                        foundGround = true;
                        break;
                    }
                }
                if (!foundGround) {
                    stuckTicks++;
                    return;
                }
            }

            if (!isJumping && (belowSolid || onGround)) {
                fakeEntity.method_5784(class_1313.field_6308, new class_243(normX * speed, 0, normZ * speed));
                isMoving = true;
                stuckTicks = 0;
            } else if (!isJumping) {
                stuckTicks++;
            }

            if (isMoving) {
                float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
                fakeEntity.method_36456(yaw);
                fakeEntity.method_5636(yaw);
                if (fakeEntity instanceof class_1308 mob) mob.method_5847(yaw);
            }
        }

        if (!onGround) {
            class_243 velocity = fakeEntity.method_18798();
            fakeEntity.method_18800(
                    velocity.field_1352 * 0.91,
                    Math.max(velocity.field_1351 - 0.08, -0.5),
                    velocity.field_1350 * 0.91
            );
            fakeEntity.method_5784(class_1313.field_6308, fakeEntity.method_18798());
        }

        if (!isMoving && onGround) {
            fakeEntity.method_18799(class_243.field_1353);
        }

        if (fakeEntity instanceof class_1493 wolf) {
            wolf.method_5728(isMoving && !isJumping);
            wolf.method_24346(!isMoving && onGround);
        }
    }

    private void updateEntityRotation(class_1297 target) {
        if (fakeEntity == null || target == null) return;

        class_243 entityEyes = fakeEntity.method_73189().method_1031(0, fakeEntity.method_5751(), 0);
        class_243 targetEyes = target.method_73189().method_1031(0, target.method_5751(), 0);
        class_243 diff = targetEyes.method_1020(entityEyes);

        double flatDist = Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350);
        float yaw = (float) Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
        float pitch = (float) Math.toDegrees(-Math.atan2(diff.field_1351, flatDist));

        fakeEntity.method_36456(yaw);
        fakeEntity.method_36457(pitch);
        fakeEntity.method_5636(yaw);

        if (fakeEntity instanceof class_1308 mob) {
            mob.method_5847(yaw);
        }
    }

    private void updateEntityRotationSafe(Object target) {
        if (target instanceof class_1297 entity) {
            updateEntityRotation(entity);
        }
    }

    private final ClientTickEvents.EndTick tickListener = client -> {
        if (!active || mc.field_1724 == null || mc.field_1687 == null) return;

        if (fakeEntity == null) {
            fakeEntity = createEntity();
            if (fakeEntity != null) {
                mc.field_1687.method_53875(fakeEntity);
                lastWorld = mc.field_1687;
            }
            return;
        }

        if (mc.field_1687 != lastWorld) {
            if (fakeEntity != null)
                mc.field_1687.method_2945(fakeEntity.method_5628(), class_1297.class_5529.field_26999);
            fakeEntity = createEntity();
            if (fakeEntity == null) return;
            mc.field_1687.method_53875(fakeEntity);
            lastWorld = mc.field_1687;
        }

        class_243 playerPos = mc.field_1724.method_73189();
        class_243 entityPos = fakeEntity.method_73189();
        double distToPlayer = playerPos.method_1022(entityPos);

        if (distToPlayer > 10.0 || stuckTicks > 40) {
            ticksAway++;

            if (ticksAway >= 60 || stuckTicks > 40) {
                double targetX = playerPos.field_1352;
                double targetY = playerPos.field_1351;
                double targetZ = playerPos.field_1350;

                if (mc.field_1724.method_6128() || !mc.field_1724.method_24828()) {
                    class_2338.class_2339 posBelow = new class_2338.class_2339(
                            (int) Math.floor(playerPos.field_1352),
                            (int) Math.floor(playerPos.field_1351),
                            (int) Math.floor(playerPos.field_1350)
                    );

                    for (int yOffset = 0; yOffset < 64; yOffset++) {
                        if (isSolid(posBelow)) {
                            targetY = posBelow.method_10264() + 1.0;
                            break;
                        }
                        posBelow.method_10100(0, -1, 0);
                    }
                }

                fakeEntity.method_5808(
                        targetX, targetY, targetZ,
                        fakeEntity.method_36454(), fakeEntity.method_36455()
                );
                fakeEntity.method_18799(class_243.field_1353);
                ticksAway = 0;
                stuckTicks = 0;
            }
        } else {
            ticksAway = 0;
        }

        if (currentTarget != null &&
                (currentTarget.method_31481() ||
                        currentTarget.method_29504() ||
                        this.isInvisible(currentTarget))) {
            currentTarget = null;
        }

        class_243 moveTo = playerPos;
        Object lookTarget = mc.field_1724;

        if (bumbum.isEnabled() && currentTarget != null) {
            double distToTarget = currentTarget.method_73189().method_1022(entityPos);

            if (distToTarget <= 12) {
                moveTo = currentTarget.method_73189();
                lookTarget = currentTarget;
            } else {
                currentTarget = null;
                moveTo = playerPos;
                lookTarget = mc.field_1724;
            }
        }

        moveEntityTowardsTarget(moveTo);
        fakeEntity.method_6007();
        updateEntityRotationSafe(lookTarget);
    };

    private boolean isInvisible(class_1309 entity) {
        if (entity.method_6059(class_1294.field_5905)) return true;
        if (entity.method_5767()) return true;
        if (mc.field_1724 != null && entity.method_5756(mc.field_1724)) return true;
        return false;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ClientTickEvents.END_CLIENT_TICK.register(tickListener);
        active = true;
        lastWorld = mc.field_1687;

        if (mc.field_1724 != null && mc.field_1687 != null) {
            fakeEntity = createEntity();
            if (fakeEntity != null) {
                mc.field_1687.method_53875(fakeEntity);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (!active) return;

        if (mc.field_1687 != null && fakeEntity != null) {
            mc.field_1687.method_2945(fakeEntity.method_5628(), class_1297.class_5529.field_26999);
            fakeEntity = null;
        }

        active = false;
        ticksAway = 0;
        stuckTicks = 0;
        currentTarget = null;
    }
}
