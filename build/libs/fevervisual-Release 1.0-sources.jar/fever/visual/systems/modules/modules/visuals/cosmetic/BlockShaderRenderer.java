package fever.visual.systems.modules.modules.visuals.cosmetic;

import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.FeverVisual;
import fever.visual.framework.shader.GlProgram;
import fever.visual.systems.modules.modules.visuals.Zoom;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.render.compat.BufferRenderer;
import fever.visual.utility.render.compat.ShaderProgramKeys;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

public class BlockShaderRenderer {
    public static void renderShaderBox(Matrix4f matrix, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, ColorRGBA color, ShaderMode mode, int fillAlpha, float speed) {
        if (!mode.hasShader()) {
            renderNormalBox(matrix, minX, minY, minZ, maxX, maxY, maxZ, color, fillAlpha);
        } else {
            renderWithShader(matrix, minX, minY, minZ, maxX, maxY, maxZ, color, mode, fillAlpha, speed);
        }
    }

    private static void renderNormalBox(Matrix4f matrix, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, ColorRGBA color, int fillAlpha) {
        int c = replaceAlpha(color.getRGB(), fillAlpha);
        int r = c >> 16 & 0xFF;
        int g = c >> 8 & 0xFF;
        int b = c & 0xFF;
        int a = c >> 24 & 0xFF;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1576);

        buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_1336(r, g, b, a);


        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_1336(r, g, b, a);


        buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);

        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_1336(r, g, b, a);

        buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_1336(r, g, b, a);

        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_1336(r, g, b, a);
        buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_1336(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
    }

    private static void renderWithShader(Matrix4f matrix, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, ColorRGBA color, ShaderMode mode, int fillAlpha, float speed) {
        try {
            GlProgram shader = mode.getShader();
            if (shader == null) {
                FeverVisual.LOGGER.warn("Shader key is null for mode: {}", mode.getShaderName());
                renderNormalBox(matrix, minX, minY, minZ, maxX, maxY, maxZ, color, fillAlpha);
                return;
            }

            shader.use();
            shader.findUniform("time").set((float) (System.currentTimeMillis() % 100000L) / 1000.0f * speed);
            net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
            shader.findUniform("screenSize").set((float) mc.method_22683().method_4480(), (float) mc.method_22683().method_4507());
            shader.findUniform("baseColor").set(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
            shader.findUniform("alpha").set((float) fillAlpha / 255.0f);
            if (mode.usesZoom()) {
                Zoom zoomModule = FeverVisual.getInstance().getModuleManager().getModule(Zoom.class);
                float zoomFactor = 1.0f;
                if (zoomModule != null && zoomModule.isEnabled()) {
                    zoomFactor = zoomModule.getZoomMultiplier();
                }
                shader.findUniform("zoomFactor").set(zoomFactor);
            }

            class_287 buffer = class_289.method_1348().method_60827(com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382, class_290.field_1575);
            int c = replaceAlpha(color.getRGB(), fillAlpha);
            int r = c >> 16 & 0xFF;
            int g = c >> 8 & 0xFF;
            int b = c & 0xFF;
            int a = c >> 24 & 0xFF;


            buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);


            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);


            buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);


            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);


            buffer.method_22918(matrix, (float) minX, (float) minY, (float) minZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) minY, (float) maxZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) maxZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) minX, (float) maxY, (float) minZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);


            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) maxZ).method_22913(0.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) minY, (float) minZ).method_22913(1.0f, 0.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) minZ).method_22913(1.0f, 1.0f).method_1336(r, g, b, a);
            buffer.method_22918(matrix, (float) maxX, (float) maxY, (float) maxZ).method_22913(0.0f, 1.0f).method_1336(r, g, b, a);

            BufferRenderer.drawWithGlobalProgram(buffer.method_60800());
        } catch (Exception e) {
            FeverVisual.LOGGER.error("Failed to render with shader: {}", mode.getShaderName(), e);
            renderNormalBox(matrix, minX, minY, minZ, maxX, maxY, maxZ, color, fillAlpha);
        }
    }

    private static int replaceAlpha(int color, int alpha) {
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;
        return alpha << 24 | r << 16 | g << 8 | b;
    }

    public enum ShaderMode {
        COBWEB("Паутина", "block_cobweb"),
        NEBULA("Туманность", "block_nebula"),
        PLASMA("Плазма", "block_plasma"),
        STARFIELD("Звёздное поле", "block_starfield"),
        FIREWORKS("Геометрия", "block_fireworks"),
        GALAXY("Галактика", "block_galaxy"),
        STARS("Аква", "block_stars");

        private final String displayName;
        private final String shaderName;
        private final GlProgram shader;

        ShaderMode(String displayName, String shaderName) {
            this.displayName = displayName;
            this.shaderName = shaderName;
            if (shaderName != null) {
                this.shader = new GlProgram(
                    class_2960.method_60655("fevervisual", "shadersblock/shadersforblock/" + shaderName),
                    class_290.field_1575
                );
            } else {
                this.shader = null;
            }
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getShaderName() {
            return shaderName;
        }

        public GlProgram getShader() {
            return shader;
        }

        public boolean usesZoom() {
            return this == FIREWORKS || this == GALAXY || this == STARS;
        }

        public boolean hasShader() {
            return shaderName != null;
        }
    }
}
