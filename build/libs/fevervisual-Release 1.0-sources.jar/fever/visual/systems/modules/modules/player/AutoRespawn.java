package fever.visual.systems.modules.modules.player;

import fever.visual.systems.modules.api.ModuleCategory;
import fever.visual.systems.modules.api.ModuleInfo;
import fever.visual.systems.modules.impl.BaseModule;
import net.minecraft.class_418;

@ModuleInfo(name = "Auto Respawn", category = ModuleCategory.MISC, desc = "Автоматически возрождает при смерти")
public class AutoRespawn extends BaseModule {

    @Override
    public void tick() {
        if (mc.field_1755 instanceof class_418 && mc.field_1724 != null) {
            mc.field_1724.method_7331();
            mc.method_1507(null);
        }

        super.tick();
    }

    @Override
    public void onDisable() {
    }
}