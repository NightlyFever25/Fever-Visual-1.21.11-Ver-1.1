package fever.visual.systems.commands;

import fever.visual.utility.game.MessageUtility;
import net.minecraft.class_2561;

public sealed interface ValidationResult permits ValidationResult.Ok, ValidationResult.Error {
   static <T> ValidationResult.Ok<T> ok(T value) {
      return new ValidationResult.Ok<>(value);
   }

   static ValidationResult.Error error(String msg) {
      MessageUtility.error(class_2561.method_30163(msg));
      return new ValidationResult.Error(msg);
   }

   public record Error(String message) implements ValidationResult {
   }

   public record Ok<T>(T value) implements ValidationResult {
   }
}
