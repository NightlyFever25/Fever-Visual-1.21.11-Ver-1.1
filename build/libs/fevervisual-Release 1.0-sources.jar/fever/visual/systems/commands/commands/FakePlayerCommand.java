package fever.visual.systems.commands.commands;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_2663;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_745;
import fever.visual.FeverVisual;
import fever.visual.systems.commands.Command;
import fever.visual.systems.commands.CommandBuilder;
import fever.visual.systems.commands.CommandContext;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.game.AttackEvent;
import fever.visual.systems.event.impl.player.ClientPlayerTickEvent;
import fever.visual.systems.event.impl.window.KeyPressEvent;
import fever.visual.systems.localization.Localizator;
import fever.visual.systems.notifications.NotificationType;
import fever.visual.utility.interfaces.IMinecraft;

public class FakePlayerCommand implements IMinecraft {
   private class_745 fakePlayer;
   private float moveForward = 0.0F;
   private float moveStrafe = 0.0F;
   private final EventListener<AttackEvent> onAttackEvent = event -> {
      if (this.fakePlayer != null && event.getEntity() == this.fakePlayer && this.fakePlayer.field_6235 == 0) {
         mc.field_1687
            .method_43128(
               mc.field_1724,
               this.fakePlayer.method_23317(),
               this.fakePlayer.method_23318(),
               this.fakePlayer.method_23321(),
               class_3417.field_15115,
               class_3419.field_15248,
               1.0F,
               1.0F
            );
         if (mc.field_1724.field_6017 > 0.0F) {
            mc.field_1687
               .method_43128(
                  mc.field_1724,
                  this.fakePlayer.method_23317(),
                  this.fakePlayer.method_23318(),
                  this.fakePlayer.method_23321(),
                  class_3417.field_15016,
                  class_3419.field_15248,
                  1.0F,
                  1.0F
               );
         } else {
            mc.field_1687
               .method_43128(
                  mc.field_1724,
                  this.fakePlayer.method_23317(),
                  this.fakePlayer.method_23318(),
                  this.fakePlayer.method_23321(),
                  class_3417.field_14706,
                  class_3419.field_15248,
                  1.0F,
                  1.0F
               );
         }

         this.fakePlayer.method_48922(mc.field_1687.method_48963().method_48830());
         this.fakePlayer.method_6033(this.fakePlayer.method_6032() + this.fakePlayer.method_6067() - 1.0F);
         if (this.fakePlayer.method_29504()) {
            this.fakePlayer.method_6033(10.0F);
            new class_2663(this.fakePlayer, (byte)35).method_11471(mc.field_1724.field_3944);
         }
      }
   };
   private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
      if (this.fakePlayer != null && mc.field_1755 == null) {
         int key = event.getKey();
         int action = event.getAction();
         if (key == 265) {
            this.moveForward = action != 1 && action != 2 ? 0.0F : 1.0F;
         } else if (key == 264) {
            this.moveForward = action != 1 && action != 2 ? 0.0F : -1.0F;
         } else if (key == 263) {
            this.moveStrafe = action != 1 && action != 2 ? 0.0F : 1.0F;
         } else if (key == 262) {
            this.moveStrafe = action != 1 && action != 2 ? 0.0F : -1.0F;
         }
      }
   };
   private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
      if (this.fakePlayer != null && mc.field_1724 != null) {
         if (this.moveForward == 0.0F && this.moveStrafe == 0.0F) {
            this.fakePlayer.method_5728(false);
            this.fakePlayer.method_18800(0.0, this.fakePlayer.method_18798().field_1351, 0.0);
            this.fakePlayer.field_42108.method_48567(0.0F);
         } else {
            float yaw = mc.field_1724.method_36454();
            double speed = 0.2;
            double motionX = this.moveStrafe * Math.cos(Math.toRadians(yaw)) - this.moveForward * Math.sin(Math.toRadians(yaw));
            double motionZ = this.moveForward * Math.cos(Math.toRadians(yaw)) + this.moveStrafe * Math.sin(Math.toRadians(yaw));
            class_243 velocity = new class_243(motionX * speed, this.fakePlayer.method_18798().field_1351, motionZ * speed);
            this.fakePlayer.method_18799(velocity);
            this.fakePlayer.method_5784(class_1313.field_6308, velocity);
            this.fakePlayer.method_5728(true);
         }
      }
   };

   public FakePlayerCommand() {
      FeverVisual.getInstance().getEventManager().subscribe(this);
   }

   public Command command() {
      return CommandBuilder.begin("fakeplayer")
         .aliases("fp")
         .desc("commands.fakeplayer.description")
         .param("action", p -> p.literal("add", "del"))
         .handler(this::handle)
         .build();
   }

   private void handle(CommandContext ctx) {
      String action = (String)ctx.arguments().getFirst();
      String var3 = action.toLowerCase();
      switch (var3) {
         case "add":
            this.add();
            break;
         case "del":
            this.del();
      }
   }

   public void add() {
      if (this.fakePlayer != null) {
         this.fakePlayer.method_31472();
         this.fakePlayer = null;
      }

      this.fakePlayer = new class_745(mc.field_1687, new GameProfile(UUID.fromString("66123666-6666-6666-6666-666666666600"), "FakePlayer"));
      this.fakePlayer.method_5719(mc.field_1724);
      this.fakePlayer.method_6122(class_1268.field_5808, mc.field_1724.method_6047().method_7972());
      this.fakePlayer.method_6122(class_1268.field_5810, mc.field_1724.method_6079().method_7972());
      this.fakePlayer.method_6092(new class_1293(class_1294.field_5924, 9999, 2));
      this.fakePlayer.method_6092(new class_1293(class_1294.field_5898, 9999, 4));
      this.fakePlayer.method_6092(new class_1293(class_1294.field_5907, 9999, 1));
      mc.field_1687.method_53875(this.fakePlayer);
      FeverVisual.getInstance()
         .getNotificationManager()
         .addNotificationOther(
            NotificationType.SUCCESS, Localizator.translate("commands.fakeplayer.success"), Localizator.translate("commands.fakeplayer.added")
         );
   }

   public void del() {
      if (this.fakePlayer == null) {
         FeverVisual.getInstance()
            .getNotificationManager()
            .addNotificationOther(
               NotificationType.ERROR, Localizator.translate("commands.fakeplayer.error"), Localizator.translate("commands.fakeplayer.not_exists")
            );
      } else {
         this.fakePlayer.method_31472();
         this.fakePlayer = null;
         FeverVisual.getInstance()
            .getNotificationManager()
            .addNotificationOther(
               NotificationType.SUCCESS, Localizator.translate("commands.fakeplayer.success"), Localizator.translate("commands.fakeplayer.removed")
            );
      }
   }
}
