package fever.visual.systems.commands.commands;

import fever.visual.FeverVisual;
import fever.visual.framework.msdf.Font;
import fever.visual.framework.msdf.Fonts;
import fever.visual.systems.commands.Command;
import fever.visual.systems.commands.CommandBuilder;
import fever.visual.systems.commands.CommandContext;
import fever.visual.systems.commands.ParameterValidator;
import fever.visual.systems.commands.ValidationResult;
import fever.visual.systems.event.EventListener;
import fever.visual.systems.event.impl.render.HudRenderEvent;
import fever.visual.utility.colors.ColorRGBA;
import fever.visual.utility.game.MessageUtility;
import fever.visual.utility.interfaces.IMinecraft;
import fever.visual.utility.render.Utils;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class GPSCommand implements IMinecraft {
   private static final float RADIUS = 80.0F;
   private static final float ARROW_SIZE = 18.0F;
   private static final float MARKER_SCREEN_SIZE = 48.0F;
   private static final class_2960 ARROW_TEXTURE = FeverVisual.id("textures/particles/triangle.png");
   private static final class_2960 MARKER_TEXTURE = FeverVisual.id("textures/gps.png");
   private static final ParameterValidator<String> ARGUMENT = new ParameterValidator<>() {
      @Override
      public ValidationResult validate(String text) {
         return ValidationResult.ok(text);
      }

      @Override
      public List<String> suggestions(String partial) {
         String lower = partial.toLowerCase();
         return List.of("add", "off").stream().filter(suggestion -> suggestion.startsWith(lower)).toList();
      }
   };

   private boolean active;
   private int targetX;
   private int targetY;
   private int targetZ;

   private final EventListener<HudRenderEvent> onHudRender = event -> {
      if (!this.active || mc.field_1724 == null || mc.field_1687 == null) {
         return;
      }

      float centerX = event.getContext().getScaledWindowWidth() / 2.0F;
      float centerY = event.getContext().getScaledWindowHeight() / 2.0F;
      double dx = this.targetX + 0.5 - mc.field_1724.method_23317();
      double dz = this.targetZ + 0.5 - mc.field_1724.method_23321();
      double distance = Math.sqrt(dx * dx + dz * dz);
      class_241 markerScreenPos = Utils.worldToScreen(new class_243(this.targetX + 0.5, this.targetY + 0.5, this.targetZ + 0.5));
      float targetYaw = (float)(class_3532.method_15349(dz, dx) * 180.0F / Math.PI) - 90.0F;
      float relativeYaw = class_3532.method_15393(targetYaw - mc.field_1773.method_19418().method_19330());
      double radians = Math.toRadians(relativeYaw);
      float arrowX = centerX + (float)Math.sin(radians) * RADIUS;
      float arrowY = centerY - (float)Math.cos(radians) * RADIUS;
      String distanceText = Integer.toString((int)Math.round(distance));
      Font font = Fonts.MEDIUM.getFont(7.0F);

      class_4587 matrices = event.getContext().getMatrices();
      matrices.method_22903();
      if (markerScreenPos != null) {
         matrices.method_22903();
         matrices.method_46416(markerScreenPos.field_1343, markerScreenPos.field_1342, 0.0F);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(90.0F));
         event.getContext().drawTexture(
                 MARKER_TEXTURE,
                 -MARKER_SCREEN_SIZE / 2.0F,
                 -MARKER_SCREEN_SIZE / 2.0F,
                 MARKER_SCREEN_SIZE,
                 MARKER_SCREEN_SIZE,
                 ColorRGBA.WHITE
         );
         matrices.method_22909();
      }
      event.getContext().drawText(font, distanceText, arrowX - font.width(distanceText) / 2.0F, arrowY - 17.0F, ColorRGBA.WHITE);
      matrices.method_46416(arrowX, arrowY, 0.0F);
      matrices.method_22907(class_7833.field_40718.rotationDegrees(relativeYaw));
      event.getContext().drawTexture(
              ARROW_TEXTURE,
              -ARROW_SIZE / 2.0F,
              -ARROW_SIZE / 2.0F,
              ARROW_SIZE,
              ARROW_SIZE,
              ColorRGBA.WHITE.withAlpha(180.0F)
      );
      matrices.method_22909();
   };

   public GPSCommand() {
      FeverVisual.getInstance().getEventManager().subscribe(this);
   }

   public Command command() {
      return CommandBuilder.begin("gps")
              .desc(".gps <x> <z> / .gps <x> <y> <z> / .gps off")
              .<String>param("args", p -> p.vararg().validator(ARGUMENT))
              .handler(this::handle)
              .build();
   }

   @SuppressWarnings("unchecked")
   private void handle(CommandContext context) {
      List<String> args = (List<String>)context.arguments().get(0);
      if (args.isEmpty()) {
         this.sendUsage();
         return;
      }

      String first = args.getFirst();
      if (first.equalsIgnoreCase("off")) {
         this.removeGPS();
         return;
      }

      if (first.equalsIgnoreCase("add")) {
         args = args.subList(1, args.size());
      }

      if (args.size() == 2) {
         Integer x = this.parseCoordinate(args.get(0));
         Integer z = this.parseCoordinate(args.get(1));
         if (x == null || z == null) {
            return;
         }

         this.addGPS(x, mc.field_1724 == null ? 64 : mc.field_1724.method_31478(), z);
         return;
      }

      if (args.size() == 3) {
         Integer x = this.parseCoordinate(args.get(0));
         Integer y = this.parseCoordinate(args.get(1));
         Integer z = this.parseCoordinate(args.get(2));
         if (x == null || y == null || z == null) {
            return;
         }

         this.addGPS(x, y, z);
         return;
      }

      this.sendUsage();
   }

   private void addGPS(int x, int y, int z) {
      this.targetX = x;
      this.targetY = y;
      this.targetZ = z;
      this.active = true;
      MessageUtility.info(class_2561.method_30163("GPS enabled: X " + this.targetX + ", Y " + this.targetY + ", Z " + this.targetZ));
   }

   private Integer parseCoordinate(String text) {
      try {
         return Integer.parseInt(text);
      } catch (NumberFormatException ignored) {
         MessageUtility.error(class_2561.method_30163("'" + text + "' is not a number"));
         return null;
      }
   }

   private void removeGPS() {
      this.active = false;
      MessageUtility.info(class_2561.method_30163("GPS disabled"));
   }

   private void sendUsage() {
      MessageUtility.info(class_2561.method_30163("Usage: .gps <x> <z> / .gps <x> <y> <z> / .gps off"));
   }
}
