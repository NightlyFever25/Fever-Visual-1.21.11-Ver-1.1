package fever.visual.framework.base;

import lombok.Generated;
import net.minecraft.class_332;

public class UIContext extends CustomDrawContext {
   private final int mouseX;
   private final int mouseY;
   private final float delta;

   protected UIContext(class_332 originalContext, int mouseX, int mouseY, float delta) {
      super(originalContext);
      this.mouseX = mouseX;
      this.mouseY = mouseY;
      this.delta = delta;
   }

   protected UIContext(CustomDrawContext context, int mouseX, int mouseY, float delta) {
      super(context);
      this.mouseX = mouseX;
      this.mouseY = mouseY;
      this.delta = delta;
   }

   public static UIContext of(class_332 originalContext, int mouseX, int mouseY, float delta) {
      return new UIContext(originalContext, mouseX, mouseY, delta);
   }

   public static UIContext of(CustomDrawContext context, int mouseX, int mouseY, float delta) {
      return new UIContext(context, mouseX, mouseY, delta);
   }

   @Generated
   public int getMouseX() {
      return this.mouseX;
   }

   @Generated
   public int getMouseY() {
      return this.mouseY;
   }

   @Generated
   public float getDelta() {
      return this.delta;
   }
}
