package fever.visual.framework.base;

import fever.visual.framework.objects.MouseButton;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public abstract class CustomScreen extends class_437 {
   protected CustomScreen() {
      super(class_2561.method_43473());
   }

   public abstract void render(UIContext var1);

   public final void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      super.method_25394(context, mouseX, mouseY, delta);
      UIContext uiContext = UIContext.of(context, mouseX, mouseY, delta);
      this.render(uiContext);
   }

   public final boolean method_25402(class_11909 click, boolean doubled) {
      MouseButton mouseButton = MouseButton.fromButtonIndex(click.method_74245());
      this.onMouseClicked(click.comp_4798(), click.comp_4799(), mouseButton);
      return super.method_25402(click, doubled);
   }

   public final boolean method_25406(class_11909 click) {
      MouseButton mouseButton = MouseButton.fromButtonIndex(click.method_74245());
      this.onMouseReleased(click.comp_4798(), click.comp_4799(), mouseButton);
      return super.method_25406(click);
   }

   public final boolean method_25403(class_11909 click, double deltaX, double deltaY) {
      MouseButton mouseButton = MouseButton.fromButtonIndex(click.method_74245());
      this.onMouseDragged(click.comp_4798(), click.comp_4799(), mouseButton, deltaX, deltaY);
      return super.method_25403(click, deltaX, deltaY);
   }

   public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
   }

   public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
   }

   public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {
   }
}
