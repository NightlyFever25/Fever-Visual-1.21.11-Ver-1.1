package fever.visual.framework.base;

import fever.visual.utility.render.compat.RenderSystem;
import fever.visual.framework.msdf.MsdfFont;
import fever.visual.utility.render.batching.impl.FontBatching;
import fever.visual.utility.render.batching.impl.GuiShapeBatching;
import fever.visual.utility.render.batching.impl.IconBatching;
import fever.visual.utility.render.batching.impl.SdfShapeBatching;
import net.fabricmc.fabric.api.client.rendering.v1.SpecialGuiElementRegistry;
import net.minecraft.class_11239;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import java.util.List;
import java.util.function.Consumer;

public final class FeverGuiElementRenderer<T extends FeverGuiElementRenderState> extends class_11239<T> {
   private static boolean registered;
   private final Class<T> elementClass;

   private FeverGuiElementRenderer(class_4597.class_4598 vertexConsumers, Class<T> elementClass) {
      super(vertexConsumers);
      this.elementClass = elementClass;
   }

   public static void register() {
      if (!registered) {
         SpecialGuiElementRegistry.register(
            context -> new FeverGuiElementRenderer<>(context.vertexConsumers(), FeverGuiElementRenderState.Pre.class)
         );
         SpecialGuiElementRegistry.register(
            context -> new FeverGuiElementRenderer<>(context.vertexConsumers(), FeverGuiElementRenderState.Main.class)
         );
         SpecialGuiElementRegistry.register(
            context -> new FeverGuiElementRenderer<>(context.vertexConsumers(), FeverGuiElementRenderState.Post.class)
         );
         registered = true;
      }
   }

   @Override
   public Class<T> method_70903() {
      return this.elementClass;
   }

   @Override
   protected void render(T state, class_4587 matrices) {
      matrices.method_46416(-state.comp_4124() / 2.0F, -state.comp_4125(), 0.0F);
      for (FeverGuiElementRenderState.CommandBatch batch : state.batches()) {
         matrices.method_22903();
         matrices.method_34425(batch.transform());
         RenderSystem.setScissor(batch.scissor());
         try {
            this.renderBatch(batch.draws(), matrices);
         } finally {
            RenderSystem.setScissor(null);
            matrices.method_22909();
         }
      }
   }

   private void renderBatch(List<Consumer<class_4587>> draws, class_4587 matrices) {
      for (int i = 0; i < draws.size();) {
         Consumer<class_4587> draw = draws.get(i);
         if (draw instanceof CustomDrawContext.SolidShapeDraw) {
            SdfShapeBatching batching = SdfShapeBatching.begin();
            do {
               CustomDrawContext.SolidShapeDraw shape = (CustomDrawContext.SolidShapeDraw)draws.get(i++);
               shape.add(batching, matrices.method_23760().method_23761());
            } while (i < draws.size() && draws.get(i) instanceof CustomDrawContext.SolidShapeDraw);
            batching.draw();
            continue;
         }

         if (draw instanceof CustomDrawContext.MsdfStringDraw textDraw) {
            MsdfFont font = textDraw.font();
            FontBatching batching = new FontBatching(class_290.field_1575, font);
            do {
               draws.get(i++).accept(matrices);
            } while (i < draws.size()
               && draws.get(i) instanceof CustomDrawContext.MsdfStringDraw next
               && next.font() == font);
            batching.draw();
            continue;
         }

         if (draw instanceof CustomDrawContext.TextureDraw textureDraw) {
            net.minecraft.class_2960 texture = textureDraw.identifier();
            IconBatching batching = new IconBatching(class_290.field_1575, matrices);
            do {
               draws.get(i++).accept(matrices);
            } while (i < draws.size()
               && draws.get(i) instanceof CustomDrawContext.TextureDraw next
               && next.identifier().equals(texture));
            batching.draw();
            continue;
         }

         draw.accept(matrices);
         i++;
      }
   }

   @Override
   protected String method_70906() {
      return "Fever Visual";
   }
}
