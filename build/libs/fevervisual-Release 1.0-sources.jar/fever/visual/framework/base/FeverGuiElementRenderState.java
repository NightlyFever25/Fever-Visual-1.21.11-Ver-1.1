package fever.visual.framework.base;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11256;
import net.minecraft.class_4587;
import net.minecraft.class_8030;
import org.joml.Matrix4f;
import org.jspecify.annotations.Nullable;

public class FeverGuiElementRenderState implements class_11256 {
   private final int width;
   private final int height;
   private final class_8030 bounds;
   private final List<CommandBatch> batches = new ArrayList<>();

   FeverGuiElementRenderState(int width, int height) {
      this.width = width;
      this.height = height;
      this.bounds = new class_8030(0, 0, width, height);
   }

   void add(Matrix4f transform, @Nullable class_8030 scissor, Consumer<class_4587> draw) {
      int size = this.batches.size();
      if (size != 0) {
         CommandBatch last = this.batches.get(size - 1);
         if (last.matches(transform, scissor)) {
            last.add(draw);
            return;
         }
      }

      this.batches.add(new CommandBatch(new Matrix4f(transform), scissor, draw));
   }

   List<CommandBatch> batches() {
      return this.batches;
   }

   @Override
   public int comp_4122() {
      return 0;
   }

   @Override
   public int comp_4124() {
      return this.width;
   }

   @Override
   public int comp_4123() {
      return 0;
   }

   @Override
   public int comp_4125() {
      return this.height;
   }

   @Override
   public float comp_4133() {
      return 1.0F;
   }

   @Override
   public class_8030 comp_4128() {
      return null;
   }

   @Override
   public class_8030 comp_4274() {
      return this.bounds;
   }

   static final class CommandBatch {
      private final Matrix4f transform;
      private final @Nullable class_8030 scissor;
      private final List<Consumer<class_4587>> draws = new ArrayList<>();

      CommandBatch(Matrix4f transform, @Nullable class_8030 scissor, Consumer<class_4587> draw) {
         this.transform = transform;
         this.scissor = scissor;
         this.draws.add(draw);
      }

      boolean matches(Matrix4f transform, @Nullable class_8030 scissor) {
         return this.transform.equals(transform) && java.util.Objects.equals(this.scissor, scissor);
      }

      void add(Consumer<class_4587> draw) {
         this.draws.add(draw);
      }

      Matrix4f transform() {
         return this.transform;
      }

      @Nullable class_8030 scissor() {
         return this.scissor;
      }

      List<Consumer<class_4587>> draws() {
         return this.draws;
      }
   }

   public static final class Pre extends FeverGuiElementRenderState {
      Pre(int width, int height) {
         super(width, height);
      }
   }

   public static final class Main extends FeverGuiElementRenderState {
      Main(int width, int height) {
         super(width, height);
      }
   }

   public static final class Post extends FeverGuiElementRenderState {
      Post(int width, int height) {
         super(width, height);
      }
   }
}
